package com.example.goatstalker;

import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A player held by the bipedal stalker cannot jump off its hands. */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class MobEvents {
    @SubscribeEvent
    public static void onMount(EntityMountEvent event) {
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof BipedalMobEntity mob
                && mob.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof TormentorEntity t
                && t.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
    }
}
