package com.example.goatstalker;

import java.util.List;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

/**
 * The real bipedal stalker (200 health, it can be killed).
 * - It hunts players. It can squeeze through narrow gaps (hunched, then crawling), break glass, climb walls and
 *   crawl along ceilings, but it cannot walk through walls.
 * - When it sees a Goat Stalker it fights it and tears it in two.
 * - When it catches a player it lifts him, roars at him, throws him on the floor and kicks him: the player dies.
 */
public class BipedalMobEntity extends Monster {
    public static final int A_IDLE = 0;
    public static final int A_RUN = 1;
    public static final int A_CROUCH = 2;
    public static final int A_CRAWL = 3;
    public static final int A_CLIMB = 4;
    public static final int A_ROAR = 5;
    public static final int A_LIFT = 6;
    public static final int A_KICK = 7;
    public static final int A_CRACK = 8;
    /** Animation names in assets/goatstalker/stalker/animations.json, by the numbers above. */
    public static final String[] ANIM_NAMES = {"espera", "terror", "encorvar", "gateo", "escalar", "grito", "lift", "kick", "crack"};

    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_ROAR =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_CLIMBING =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_CEILING =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.BOOLEAN);
    /** Parts torn off by the Tormentor (bits below) and whether it lies on the ground. */
    private static final EntityDataAccessor<Integer> DATA_LOST =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_FALLEN =
            SynchedEntityData.defineId(BipedalMobEntity.class, EntityDataSerializers.BOOLEAN);
    public static final int LOST_ARM = 1;
    public static final int LOST_LEG = 2;
    public static final int LOST_HEAD = 4;

    // fighting the Tormentor (the Tormentor leads the fight)
    private UUID tormentorId;
    private int corpseTicks = -1;

    private int forcedAnim = -1;
    /** Client only: the client's own tick when the current animation started (server ticks differ from client ticks). */
    private int clientAnimStart;

    // noticing a player: a bone crack, then it stares at him for 5 seconds before it attacks
    private static final int STARE_TICKS = 100;
    private int stareTicks = 0;
    private UUID noticedId;
    private int lostTicks = 0;
    private int lifetime = -1;
    private int cooldown = 0;

    // catching a player
    private UUID capturedId;
    private int capturePhase = 0;
    private int captureTick = 0;
    private boolean releasing = false;

    // fighting the Goat Stalker
    private UUID fightGoat;
    private int fightPhase = 0; // 1 = running at the goat, 2 = the fight itself
    private int fightTick = 0;
    private Vec3 goatBase = Vec3.ZERO;

    public BipedalMobEntity(EntityType<? extends BipedalMobEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_ROAR, false);
        this.entityData.define(DATA_CLIMBING, false);
        this.entityData.define(DATA_CEILING, false);
        this.entityData.define(DATA_LOST, 0);
        this.entityData.define(DATA_FALLEN, false);
    }

    // ------------------------------ getters for the renderer ------------------------------
    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getAnimStart() {
        return this.entityData.get(DATA_ANIM_START);
    }

    /** The tick (counted on the client) when the animation the renderer must play began. */
    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    public boolean isRoaring() {
        return this.entityData.get(DATA_ROAR);
    }

    public boolean isCeiling() {
        return this.entityData.get(DATA_CEILING);
    }

    public int getLost() {
        return this.entityData.get(DATA_LOST);
    }

    public boolean isFallen() {
        return this.entityData.get(DATA_FALLEN);
    }

    // ------------------------------ the fight with the Tormentor ------------------------------
    public boolean canStartTormentorFight() {
        return this.tormentorId == null && this.capturePhase == 0 && this.fightPhase == 0 && !isCeiling();
    }

    public void joinTormentorFight(TormentorEntity t) {
        this.tormentorId = t.getUUID();
        this.stareTicks = 0;
        setTarget(null);
        getNavigation().stop();
        if (getPose() != Pose.STANDING && canFit(Pose.STANDING)) {
            setPose(Pose.STANDING);
        }
        forceAnim(A_ROAR);
    }

    public void leaveTormentorFight() {
        this.tormentorId = null;
        this.forcedAnim = -1;
        setRoar(false);
    }

    public boolean isDeadByTormentor() {
        return this.corpseTicks >= 0;
    }

    public void faceTowards(Entity e) {
        faceTo(e.getX() - getX(), e.getZ() - getZ());
    }

    public void fightRoar() {
        forceAnim(A_ROAR);
        setRoar(true);
        roarSound();
    }

    public void fightAnim(int anim, boolean roarTexture) {
        forceAnim(anim);
        setRoar(roarTexture);
    }

    public void losePart(int bit) {
        this.entityData.set(DATA_LOST, getLost() | bit);
    }

    public void fallDown() {
        this.entityData.set(DATA_FALLEN, true);
        setRoar(false);
        forceAnim(A_IDLE);
    }

    /** Its head has burst: it lies there for 10 seconds and is gone (nothing drops). */
    public void dieByTormentor() {
        this.corpseTicks = 0;
        setRoar(false);
        forceAnim(A_IDLE);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.corpseTicks >= 0) {
            return false;
        }
        return super.hurt(source, amount);
    }

    /** Attacks this player at once, without the 5 seconds of staring (it has already stared at him). */
    public void huntNow(Player p) {
        setTarget(p);
        this.noticedId = p.getUUID();
    }

    public void setTimedLife(int ticks) {
        this.lifetime = ticks;
    }

    /** True while this entity holds the given player (he must not be able to dismount). */
    public boolean isHolding(Entity entity) {
        return !this.releasing && this.capturePhase != 0 && this.capturedId != null
                && this.capturedId.equals(entity.getUUID());
    }

    // ------------------------------ size and movement ------------------------------
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return switch (pose) {
            case CROUCHING -> EntityDimensions.scalable(1.2F, 3.0F);
            case SWIMMING -> EntityDimensions.scalable(1.2F, 1.6F); // the crawling pose
            default -> EntityDimensions.scalable(1.2F, 5.2F);
        };
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) {
        return dims.height * 0.92F;
    }

    @Override
    public float maxUpStep() {
        return 1.25F;
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WallClimberNavigation(this, level); // like a spider: it can climb walls
    }

    @Override
    public boolean onClimbable() {
        return this.entityData.get(DATA_CLIMBING);
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.capturePhase != 0 || this.fightPhase == 2 || isCeiling() || this.stareTicks > 0
                || this.tormentorId != null;
    }

    private boolean busy() {
        return this.capturePhase != 0 || this.fightPhase == 2 || isCeiling() || this.stareTicks > 0
                || this.tormentorId != null;
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true) {
            @Override
            public boolean canUse() {
                return !BipedalMobEntity.this.busy() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !BipedalMobEntity.this.busy() && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 12.0D; // about 3.5 blocks
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (target instanceof ServerPlayer sp && distSqr <= getAttackReachSqr(target)) {
                    BipedalMobEntity.this.startCapture(sp);
                }
            }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false,
                e -> this.fightPhase == 0 && this.tormentorId == null
                        && e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ main tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.lifetime >= 0 && this.tickCount > this.lifetime && this.capturePhase == 0) {
            this.discard();
            return;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        this.entityData.set(DATA_CLIMBING, this.horizontalCollision && !isCeiling() && this.tormentorId == null);
        if (this.tormentorId != null) { // the Tormentor leads; this one only waits, reacts and suffers
            if (this.corpseTicks >= 0) {
                if (++this.corpseTicks > 200) {
                    this.discard();
                }
                return;
            }
            if (!(sl.getEntity(this.tormentorId) instanceof TormentorEntity t) || !t.isAlive()) {
                leaveTormentorFight();
            }
            getNavigation().stop();
            updateAnim();
            return;
        }

        if (this.capturePhase == 0 && this.fightPhase == 0 && !isCeiling()) {
            checkNotice(sl);
        }
        if (this.stareTicks > 0) {
            tickStare();
        } else if (this.capturePhase != 0) {
            tickCapture(sl);
        } else if (this.fightPhase != 0) {
            tickFight(sl);
        } else if (isCeiling()) {
            tickCeiling();
        } else if (this.tickCount % 10 == 0) {
            adaptPose();
            breakGlass();
            lookForGoat();
            lookForCeiling();
        }
        updateAnim();
    }

    private void updateAnim() {
        int anim;
        if (this.forcedAnim >= 0) {
            anim = this.forcedAnim;
        } else if (isCeiling()) {
            anim = A_CRAWL;
        } else if (this.entityData.get(DATA_CLIMBING)) {
            anim = A_CLIMB;
        } else if (getPose() == Pose.SWIMMING) {
            anim = A_CRAWL;
        } else if (getPose() == Pose.CROUCHING) {
            anim = A_CROUCH;
        } else {
            Vec3 v = getDeltaMovement();
            anim = (v.x * v.x + v.z * v.z > 0.002D) ? A_RUN : A_IDLE;
        }
        if (anim != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void forceAnim(int anim) {
        this.forcedAnim = anim;
        this.entityData.set(DATA_ANIM, anim);
        this.entityData.set(DATA_ANIM_START, this.tickCount);
    }

    private void setRoar(boolean roar) {
        this.entityData.set(DATA_ROAR, roar);
    }

    private void roarSound() {
        this.level().playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.STALKER_ROAR.get(),
                SoundSource.HOSTILE, 4.0F, 1.0F);
    }

    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        this.setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private Vec3 forward() {
        double r = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(r), 0.0D, Math.cos(r));
    }

    // ------------------------------ noticing a player ------------------------------
    /** The first time it sees its target: bone crack, and it stands and stares at him for 5 seconds. */
    private void checkNotice(ServerLevel sl) {
        LivingEntity t = getTarget();
        if (!(t instanceof Player)) {
            if (++this.lostTicks > 400) { // lost him for 20 seconds: next time it stares again
                this.noticedId = null;
            }
            return;
        }
        this.lostTicks = 0;
        if (this.stareTicks > 0 || t.getUUID().equals(this.noticedId)) {
            return;
        }
        if (t == getLastHurtByMob()) { // he hit it first: no time for staring
            this.noticedId = t.getUUID();
            return;
        }
        if (!hasLineOfSight(t)) {
            return;
        }
        this.noticedId = t.getUUID();
        this.stareTicks = STARE_TICKS;
        getNavigation().stop();
        setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
        if (getPose() != Pose.STANDING && canFit(Pose.STANDING)) {
            setPose(Pose.STANDING);
        }
        forceAnim(A_IDLE);
        sl.playSound(null, getX(), getY() + 4.0D, getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
    }

    private void tickStare() {
        LivingEntity t = getTarget();
        this.stareTicks--;
        if (t == null || !t.isAlive()) {
            this.stareTicks = 0;
        } else {
            getNavigation().stop();
            faceTo(t.getX() - getX(), t.getZ() - getZ());
            getLookControl().setLookAt(t, 30.0F, 30.0F);
        }
        if (this.stareTicks == 0) {
            this.forcedAnim = -1; // the 5 seconds are over: it attacks
        }
    }

    // ------------------------------ squeezing through narrow places ------------------------------
    private boolean canFit(Pose pose) {
        return this.level().noCollision(this, getDimensions(pose).makeBoundingBox(position()));
    }

    /** Stands, hunches or crawls, whichever lets it reach the target. */
    private void adaptPose() {
        LivingEntity t = getTarget();
        if (t == null) {
            if (getPose() != Pose.STANDING && canFit(Pose.STANDING)) {
                setPose(Pose.STANDING);
            }
            return;
        }
        Pose old = getPose();
        Pose[] order = {Pose.STANDING, Pose.CROUCHING, Pose.SWIMMING};
        for (Pose want : order) {
            if (want != old && !canFit(want)) {
                continue;
            }
            setPose(want);
            Path path = getNavigation().createPath(t, 0);
            if (path != null && path.canReach()) {
                if (want != old) {
                    getNavigation().stop();
                }
                return;
            }
        }
        setPose(old);
    }

    private void fitBestPose() {
        for (Pose p : new Pose[] {Pose.STANDING, Pose.CROUCHING, Pose.SWIMMING}) {
            if (canFit(p)) {
                setPose(p);
                return;
            }
        }
        setPose(Pose.SWIMMING);
    }

    // ------------------------------ breaking glass ------------------------------
    private void breakGlass() {
        LivingEntity t = getTarget();
        if (t == null) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5D) {
            return;
        }
        dx /= len;
        dz /= len;
        int minY = Mth.floor(getY());
        int maxY = Mth.floor(getY() + Math.min(getBbHeight(), 4.0D));
        for (int dist = 1; dist <= 3; dist++) {
            int bx = Mth.floor(getX() + dx * (0.8D + dist));
            int bz = Mth.floor(getZ() + dz * (0.8D + dist));
            for (int y = minY; y <= maxY; y++) {
                BlockPos pos = new BlockPos(bx, y, bz);
                BlockState s = this.level().getBlockState(pos);
                if (s.is(Tags.Blocks.GLASS) || s.is(Tags.Blocks.GLASS_PANES)) {
                    this.level().destroyBlock(pos, false, this);
                    return;
                }
            }
        }
    }

    // ------------------------------ ceilings ------------------------------
    private void lookForCeiling() {
        LivingEntity t = getTarget();
        if (t == null || !this.entityData.get(DATA_CLIMBING)) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        if (dx * dx + dz * dz < 36.0D) {
            return; // close enough: no need for the ceiling
        }
        BlockPos above = BlockPos.containing(getX(), getY() + getBbHeight() + 0.2D, getZ());
        if (this.level().getBlockState(above).isFaceSturdy(this.level(), above, Direction.DOWN)) {
            enterCeiling(above);
        }
    }

    private void enterCeiling(BlockPos ceilingBlock) {
        setPose(Pose.SWIMMING);
        this.entityData.set(DATA_CEILING, true);
        setNoGravity(true);
        getNavigation().stop();
        setPos(getX(), ceilingBlock.getY() - getBbHeight(), getZ());
    }

    private void exitCeiling() {
        this.entityData.set(DATA_CEILING, false);
        setNoGravity(false);
        fitBestPose();
    }

    private void tickCeiling() {
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) {
            exitCeiling();
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        BlockPos above = BlockPos.containing(getX(), getY() + getBbHeight() + 0.15D, getZ());
        if (d < 4.0D || !this.level().getBlockState(above).isFaceSturdy(this.level(), above, Direction.DOWN)) {
            exitCeiling(); // it drops on its prey, or the ceiling has ended
            return;
        }
        faceTo(dx, dz);
        this.move(MoverType.SELF, new Vec3(dx / d * 0.22D, 0.0D, dz / d * 0.22D));
        if (this.horizontalCollision) {
            exitCeiling();
            return;
        }
        setPos(getX(), above.getY() - getBbHeight(), getZ());
        this.fallDistance = 0.0F;
    }

    // ------------------------------ catching a player ------------------------------
    private void startCapture(ServerPlayer sp) {
        if (this.capturePhase != 0 || this.cooldown > 0 || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            return;
        }
        if (getPose() != Pose.STANDING && canFit(Pose.STANDING)) {
            setPose(Pose.STANDING);
        }
        this.capturePhase = 1;
        this.captureTick = 0;
        this.capturedId = sp.getUUID();
        getNavigation().stop();
        sp.startRiding(this, true);
        forceAnim(A_LIFT);
    }

    /** The held player hangs in front of the creature, high up in its hands. */
    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) {
            return;
        }
        Vec3 f = forward();
        callback.accept(passenger, getX() + f.x * 1.8D, getY() + 4.1D, getZ() + f.z * 1.8D);
    }

    private ServerPlayer captured(ServerLevel sl) {
        return this.capturedId == null ? null : sl.getServer().getPlayerList().getPlayer(this.capturedId);
    }

    private void tickCapture(ServerLevel sl) {
        ServerPlayer sp = captured(sl);
        if (sp == null || !sp.isAlive() || sp.level() != this.level()) {
            endCapture(sl);
            return;
        }
        this.captureTick++;
        getNavigation().stop();
        faceTo(sp.getX() - getX(), sp.getZ() - getZ());
        Vec3 f = forward();

        if (this.captureTick < 65 && sp.getVehicle() != this) {
            sp.startRiding(this, true); // he cannot get away
        }
        switch (this.captureTick) {
            case 15 -> { // screams at the player
                forceAnim(A_ROAR);
                setRoar(true);
                sl.playSound(null, getX(), getY() + 3.0D, getZ(), ModSounds.SCREAM_ALT.get(),
                        SoundSource.HOSTILE, 4.0F, 1.0F);
            }
            case 65 -> { // throws him on the floor
                this.releasing = true;
                sp.stopRiding();
                this.releasing = false;
                sp.setDeltaMovement(f.x * 0.55D, -0.9D, f.z * 0.55D);
                sp.hurtMarked = true;
                setRoar(false);
                this.forcedAnim = -1;
                this.capturePhase = 3;
            }
            case 80 -> forceAnim(A_KICK); // lifts the leg
            case 88 -> { // the kick
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK,
                        SoundSource.HOSTILE, 2.0F, 0.7F);
                sp.setDeltaMovement(f.x * 0.9D, 0.4D, f.z * 0.9D);
                sp.hurtMarked = true;
                sp.hurt(this.level().damageSources().mobAttack(this), 10000.0F);
            }
            case 110 -> endCapture(sl);
            default -> { }
        }
    }

    private void endCapture(ServerLevel sl) {
        releaseCaptured();
        this.capturePhase = 0;
        this.capturedId = null;
        this.forcedAnim = -1;
        setRoar(false);
        this.cooldown = 200;
    }

    private void releaseCaptured() {
        if (this.capturedId != null && this.level() instanceof ServerLevel sl) {
            ServerPlayer sp = captured(sl);
            if (sp != null && sp.getVehicle() == this) {
                this.releasing = true;
                sp.stopRiding();
                this.releasing = false;
            }
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        releaseCaptured();
        super.remove(reason);
    }

    // ------------------------------ fighting the Goat Stalker ------------------------------
    private void lookForGoat() {
        if (this.fightPhase != 0 || this.cooldown > 0 || this.capturePhase != 0) {
            return;
        }
        List<StalkerEntity> goats = this.level().getEntitiesOfClass(StalkerEntity.class,
                getBoundingBox().inflate(32.0D), g -> g.isAlive() && !g.isInFight() && hasLineOfSight(g));
        if (goats.isEmpty()) {
            return;
        }
        StalkerEntity nearest = goats.get(0);
        for (StalkerEntity g : goats) {
            if (distanceToSqr(g) < distanceToSqr(nearest)) {
                nearest = g;
            }
        }
        this.fightGoat = nearest.getUUID();
        this.fightPhase = 1;
        this.fightTick = 0;
        setTarget(null);
    }

    private void endFight() {
        this.fightPhase = 0;
        this.fightGoat = null;
        this.forcedAnim = -1;
        setRoar(false);
        this.cooldown = 400;
    }

    private void tickFight(ServerLevel sl) {
        Entity ge = this.fightGoat == null ? null : sl.getEntity(this.fightGoat);
        if (!(ge instanceof StalkerEntity goat) || !goat.isAlive()) {
            endFight();
            return;
        }
        this.fightTick++;
        double dx = goat.getX() - getX();
        double dz = goat.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);

        if (this.fightPhase == 1) { // runs at the goat
            if (this.fightTick > 400) {
                endFight();
                return;
            }
            if (this.fightTick % 10 == 1) {
                getNavigation().moveTo(goat, 1.5D);
            }
            getLookControl().setLookAt(goat);
            if (d <= 5.0D) {
                this.fightPhase = 2;
                this.fightTick = 0;
                getNavigation().stop();
                goat.setInFight(true);
                goat.setNoGravity(true);
                goat.setTarget(null);
                this.goatBase = new Vec3(goat.getX(), goat.getY(), goat.getZ());
            }
            return;
        }

        // the fight itself: the goat is held in front of the stalker, shakes, is lifted and torn in two
        double len = Math.max(0.001D, d);
        double fx = dx / len;
        double fz = dz / len;
        faceTo(dx, dz);
        double shake = this.fightTick < 30 ? 0.06D : 0.12D;
        double lift = this.fightTick < 30 ? 0.0D : Math.min(1.8D, (this.fightTick - 30) * 0.09D);
        if (this.fightTick < 76) {
            double jx = (this.random.nextDouble() - 0.5D) * shake * 2.0D;
            double jz = (this.random.nextDouble() - 0.5D) * shake * 2.0D;
            goat.setPos(getX() + fx * 3.2D + jx, this.goatBase.y + lift, getZ() + fz * 3.2D + jz);
            goat.setDeltaMovement(Vec3.ZERO);
            if (this.fightTick > 30 && this.fightTick % 2 == 0) {
                sl.sendParticles(ParticleTypes.CRIT, goat.getX(), goat.getY() + 1.6D, goat.getZ(), 6, 0.4D, 0.6D, 0.4D, 0.2D);
            }
        }
        switch (this.fightTick) {
            case 1 -> {
                forceAnim(A_ROAR);
                setRoar(true);
                roarSound();
            }
            case 30 -> {
                setRoar(false);
                forceAnim(A_LIFT);
            }
            case 70 -> forceAnim(A_CRACK);
            case 76 -> { // torn in two
                tearGoat(sl, goat, fx, fz);
                goat.discard();
            }
            case 110 -> {
                forceAnim(A_ROAR);
                setRoar(true);
                roarSound();
            }
            case 150 -> endFight();
            default -> { }
        }
    }

    private void tearGoat(ServerLevel sl, StalkerEntity goat, double fx, double fz) {
        double px = -fz; // sideways
        double pz = fx;
        BipedalEntity top = ModEntities.BIPEDAL.get().create(sl);
        BipedalEntity bottom = ModEntities.BIPEDAL.get().create(sl);
        if (top != null) {
            top.setup(BipedalEntity.GOAT_TOP, null);
            top.setPos(goat.getX(), goat.getY() + 1.39D, goat.getZ());
            top.setVelocity(px * 0.2D, 0.32D, pz * 0.2D);
            sl.addFreshEntity(top);
        }
        if (bottom != null) {
            bottom.setup(BipedalEntity.GOAT_BOTTOM, null);
            bottom.setPos(goat.getX(), goat.getY(), goat.getZ());
            bottom.setVelocity(-px * 0.2D, 0.12D, -pz * 0.2D);
            sl.addFreshEntity(bottom);
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, goat.getX(), goat.getY() + 1.6D, goat.getZ(), 3, 0.5D, 0.5D, 0.5D, 0.0D);
        sl.sendParticles(ParticleTypes.CRIT, goat.getX(), goat.getY() + 1.6D, goat.getZ(), 40, 0.6D, 0.8D, 0.6D, 0.4D);
        sl.playSound(null, goat.getX(), goat.getY(), goat.getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.8F, 0.6F);
    }

    // ------------------------------ sounds ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 5, getY() - 1, getZ() - 5, getX() + 5, getY() + 9, getZ() + 5);
    }
}
