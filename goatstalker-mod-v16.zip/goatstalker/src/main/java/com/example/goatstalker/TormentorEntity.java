package com.example.goatstalker;

import java.util.List;
import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The Tormentor (model StalkerGoat). It hunts players like the bipedal stalker does.
 * - When it and a bipedal stalker see each other they fight: the Tormentor tears off the bipedal's arm, the bipedal
 *   tears off one of the Tormentor's horns, the Tormentor kicks it in the belly, the bipedal falls, the Tormentor tears
 *   off its leg and stamps on its head (the head bursts). Then "you next", and it goes for the player.
 * - When it catches a player it lifts him, throws him on the floor, screams at him and beats him to death.
 */
public class TormentorEntity extends Monster {
    public static final int A_IDLE = 0;
    public static final int A_RUN = 1;
    public static final int A_GRAB = 2;
    public static final int A_HOLD = 3;
    public static final int A_KICK = 4;
    public static final int A_STOMP = 5;
    public static final int A_BEAT = 6;
    public static final int A_SCREAM = 7;
    public static final int A_HURT = 8;
    public static final int A_LUNGE = 9;
    /** Animation names in assets/goatstalker/tormentor/animations.json, by the numbers above. */
    public static final String[] ANIM_NAMES = {"idle", "run", "grab", "hold", "kick", "stomp", "beat", "scream", "hurt", "lunge"};

    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(TormentorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(TormentorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_ONE_HORN =
            SynchedEntityData.defineId(TormentorEntity.class, EntityDataSerializers.BOOLEAN);

    private int clientAnimStart;
    private int forcedAnim = -1;
    private int cooldown = 0;

    // catching a player
    private UUID capturedId;
    private int captureTick = 0;
    private boolean onFloor = false;
    private boolean releasing = false;

    // fighting the bipedal stalker
    private UUID enemyId;
    private int fightPhase = 0; // 1 = going to it, 2 = the fight
    private int fightTick = 0;
    private Vec3 stompSpot;

    public TormentorEntity(EntityType<? extends TormentorEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 250.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.31D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_ONE_HORN, false);
    }

    // ------------------------------ for the renderer ------------------------------
    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    public boolean hasOneHorn() {
        return this.entityData.get(DATA_ONE_HORN);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    @Override
    public float maxUpStep() {
        return 1.25F;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.capturedId != null || this.fightPhase == 2;
    }

    private boolean busy() {
        return this.capturedId != null || this.fightPhase != 0;
    }

    /** True while this entity holds the given player (he must not be able to get off). */
    public boolean isHolding(Entity entity) {
        return !this.releasing && this.capturedId != null && this.capturedId.equals(entity.getUUID());
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25D, true) {
            @Override
            public boolean canUse() {
                return !TormentorEntity.this.busy() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !TormentorEntity.this.busy() && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 12.0D;
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (target instanceof ServerPlayer sp && distSqr <= getAttackReachSqr(target)) {
                    TormentorEntity.this.startCapture(sp);
                }
            }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false,
                e -> this.fightPhase == 0 && e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ main tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        if (this.capturedId != null) {
            tickCapture(sl);
        } else if (this.fightPhase != 0) {
            tickFight(sl);
        } else if (this.tickCount % 10 == 0) {
            lookForBipedal(sl);
        }
        updateAnim();
    }

    private void updateAnim() {
        int anim;
        if (this.forcedAnim >= 0) {
            anim = this.forcedAnim;
        } else {
            Vec3 v = getDeltaMovement();
            anim = (v.x * v.x + v.z * v.z > 0.002D) ? A_RUN : A_IDLE;
        }
        if (anim != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void forceAnim(int anim) {
        this.forcedAnim = anim;
        this.entityData.set(DATA_ANIM, anim);
        this.entityData.set(DATA_ANIM_START, this.tickCount);
    }

    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        this.setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private Vec3 forward() {
        double r = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(r), 0.0D, Math.cos(r));
    }

    private void scream(ServerLevel sl) {
        sl.playSound(null, getX(), getY() + 4.5D, getZ(), ModSounds.SCREAM.get(), SoundSource.HOSTILE, 4.0F, 0.75F);
    }

    // ------------------------------ catching a player ------------------------------
    private void startCapture(ServerPlayer sp) {
        if (this.capturedId != null || this.cooldown > 0 || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            return;
        }
        this.capturedId = sp.getUUID();
        this.captureTick = 0;
        this.onFloor = false;
        getNavigation().stop();
        sp.startRiding(this, true);
        forceAnim(A_GRAB);
    }

    /** Lifted high in its hand, then lying on the floor in front of it. */
    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) {
            return;
        }
        Vec3 f = forward();
        if (this.onFloor) {
            callback.accept(passenger, getX() + f.x * 1.9D, getY() + 0.05D, getZ() + f.z * 1.9D);
        } else {
            callback.accept(passenger, getX() + f.x * 1.3D, getY() + 4.3D, getZ() + f.z * 1.3D);
        }
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.0D;
    }

    private ServerPlayer captured(ServerLevel sl) {
        return this.capturedId == null ? null : sl.getServer().getPlayerList().getPlayer(this.capturedId);
    }

    private void tickCapture(ServerLevel sl) {
        ServerPlayer sp = captured(sl);
        if (sp == null || !sp.isAlive() || sp.level() != this.level()) {
            endCapture();
            return;
        }
        this.captureTick++;
        getNavigation().stop();
        if (sp.getVehicle() != this) {
            sp.startRiding(this, true); // there is no getting away
        }
        Vec3 f = forward();
        int t = this.captureTick;
        if (t == 30) { // throws him on the floor
            this.onFloor = true;
            forceAnim(A_HOLD);
            sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_BIG_FALL, SoundSource.HOSTILE, 2.0F, 0.8F);
            sp.hurt(this.level().damageSources().mobAttack(this), 2.0F);
        } else if (t == 40) { // screams at him
            forceAnim(A_SCREAM);
            scream(sl);
        } else if (t == 75) {
            forceAnim(A_BEAT);
        } else if (t > 75 && (t - 75) % 11 == 4) { // beats him with its hands until he is dead
            sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.5F, 0.6F);
            Blood.spray(sl, sp.getX(), sp.getY() + 0.4D, sp.getZ(), 14, 0.35D);
            sp.invulnerableTime = 0;
            sp.hurt(this.level().damageSources().mobAttack(this), 3.0F);
        }
        if (t > 700) { // nobody survives this
            sp.hurt(this.level().damageSources().mobAttack(this), 10000.0F);
        }
        faceTo(sp.getX() - getX() + f.x * 0.001D, sp.getZ() - getZ() + f.z * 0.001D);
    }

    private void endCapture() {
        if (this.level() instanceof ServerLevel sl) {
            ServerPlayer sp = captured(sl);
            if (sp != null && sp.getVehicle() == this) {
                this.releasing = true;
                sp.stopRiding();
                this.releasing = false;
            }
        }
        this.capturedId = null;
        this.onFloor = false;
        this.forcedAnim = -1;
        this.cooldown = 100;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (this.capturedId != null) {
            endCapture();
        }
        super.remove(reason);
    }

    // ------------------------------ fighting the bipedal stalker ------------------------------
    private void lookForBipedal(ServerLevel sl) {
        if (this.cooldown > 0) {
            return;
        }
        List<BipedalMobEntity> list = sl.getEntitiesOfClass(BipedalMobEntity.class, getBoundingBox().inflate(32.0D),
                b -> b.isAlive() && b.canStartTormentorFight() && hasLineOfSight(b));
        if (list.isEmpty()) {
            return;
        }
        BipedalMobEntity nearest = list.get(0);
        for (BipedalMobEntity b : list) {
            if (distanceToSqr(b) < distanceToSqr(nearest)) {
                nearest = b;
            }
        }
        startFight(nearest);
    }

    public void startFight(BipedalMobEntity b) {
        this.enemyId = b.getUUID();
        this.fightPhase = 1;
        this.fightTick = 0;
        setTarget(null);
        b.joinTormentorFight(this);
    }

    private void endFight() {
        BipedalMobEntity b = enemy();
        if (b != null && !b.isDeadByTormentor()) {
            b.leaveTormentorFight();
        }
        this.enemyId = null;
        this.fightPhase = 0;
        this.forcedAnim = -1;
        this.cooldown = 200;
        this.stompSpot = null;
    }

    private BipedalMobEntity enemy() {
        if (this.enemyId == null || !(this.level() instanceof ServerLevel sl)) {
            return null;
        }
        return sl.getEntity(this.enemyId) instanceof BipedalMobEntity b ? b : null;
    }

    private void crack(ServerLevel sl, double x, double y, double z) {
        sl.playSound(null, x, y, z, ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
    }

    private void tickFight(ServerLevel sl) {
        BipedalMobEntity b = enemy();
        this.fightTick++;
        if (b == null || (!b.isAlive() && !b.isDeadByTormentor())) {
            endFight();
            return;
        }
        double dx = b.getX() - getX();
        double dz = b.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);

        if (this.fightPhase == 1) { // walks up to it
            if (this.fightTick > 600) {
                endFight();
                return;
            }
            if (this.fightTick % 10 == 1) {
                getNavigation().moveTo(b, 1.4D);
            }
            getLookControl().setLookAt(b);
            if (d <= 4.2D) {
                this.fightPhase = 2;
                this.fightTick = 0;
                getNavigation().stop();
            }
            return;
        }

        int t = this.fightTick;
        Vec3 bf = new Vec3(-dx / Math.max(d, 0.01D), 0.0D, -dz / Math.max(d, 0.01D)); // from the bipedal to me
        if (t < 240) {
            faceTo(dx, dz);
            b.faceTowards(this);
        }
        switch (t) {
            case 1 -> { // they meet: the Tormentor screams, the bipedal roars back
                forceAnim(A_SCREAM);
                scream(sl);
            }
            case 22 -> b.fightRoar();
            case 45 -> forceAnim(A_GRAB);
            case 75 -> { // tears off the bipedal's arm
                b.losePart(BipedalMobEntity.LOST_ARM);
                crack(sl, b.getX(), b.getY() + 4.0D, b.getZ());
                Blood.spray(sl, b.getX() + bf.x * 0.5D, b.getY() + 4.0D, b.getZ() + bf.z * 0.5D, 40, 0.5D);
                b.fightAnim(BipedalMobEntity.A_ROAR, true);
            }
            case 95 -> forceAnim(A_HOLD);
            case 112 -> b.fightAnim(BipedalMobEntity.A_LIFT, false); // reaches for the Tormentor's head
            case 135 -> { // tears off one of the Tormentor's horns
                this.entityData.set(DATA_ONE_HORN, true);
                crack(sl, getX(), getY() + 6.0D, getZ());
                Blood.spray(sl, getX(), getY() + 6.0D, getZ(), 30, 0.4D);
                forceAnim(A_HURT);
                b.fightAnim(BipedalMobEntity.A_IDLE, false);
            }
            case 165 -> forceAnim(A_KICK);
            case 173 -> { // the kick in the belly: the bipedal falls
                sl.playSound(null, b.getX(), b.getY() + 2.0D, b.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 3.0F, 0.5F);
                sl.playSound(null, b.getX(), b.getY(), b.getZ(), SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 3.0F, 0.6F);
                b.fallDown();
                Blood.spray(sl, b.getX(), b.getY() + 2.4D, b.getZ(), 12, 0.4D);
            }
            case 200 -> forceAnim(A_GRAB);
            case 228 -> { // tears off its leg
                b.losePart(BipedalMobEntity.LOST_LEG);
                crack(sl, b.getX(), b.getY() + 0.5D, b.getZ());
                Blood.spray(sl, b.getX(), b.getY() + 0.5D, b.getZ(), 40, 0.5D);
            }
            case 240 -> { // goes to the head (the bipedal lies on its back, its head away from the Tormentor)
                forceAnim(A_RUN);
                Vec3 head = b.position().add(bf.scale(-4.4D));
                Vec3 side = new Vec3(-bf.z, 0.0D, bf.x);
                this.stompSpot = head.add(side.scale(1.4D));
            }
            case 268 -> {
                if (this.stompSpot != null) {
                    Vec3 head = b.position().add(bf.scale(-4.4D));
                    faceTo(head.x - getX(), head.z - getZ());
                }
                forceAnim(A_STOMP);
            }
            case 281 -> { // stamps on the head: it bursts
                Vec3 head = b.position().add(bf.scale(-4.4D));
                b.losePart(BipedalMobEntity.LOST_HEAD);
                sl.playSound(null, head.x, head.y, head.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0F, 1.5F);
                crack(sl, head.x, head.y, head.z);
                Blood.spray(sl, head.x, head.y + 0.4D, head.z, 90, 0.8D);
                b.dieByTormentor();
            }
            case 320 -> { // "you next"
                forceAnim(A_IDLE);
                sl.playSound(null, getX(), getY() + 5.0D, getZ(), ModSounds.YOU_NEXT.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
            }
            case 360 -> {
                endFight();
                Player p = sl.getNearestPlayer(this, 64.0D);
                if (p != null && !p.isCreative() && !p.isSpectator()) {
                    setTarget(p);
                }
            }
            default -> { }
        }
        if (t > 240 && t < 268 && this.stompSpot != null) { // walk to the head
            Vec3 to = this.stompSpot.subtract(position());
            double len = Math.sqrt(to.x * to.x + to.z * to.z);
            if (len > 0.2D) {
                faceTo(to.x, to.z);
                move(MoverType.SELF, new Vec3(to.x / len * 0.25D, -0.08D, to.z / len * 0.25D));
            }
        }
    }

    // ------------------------------ misc ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 6, getY() - 1, getZ() - 6, getX() + 6, getY() + 9, getZ() + 6);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("OneHorn", hasOneHorn());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_ONE_HORN, tag.getBoolean("OneHorn"));
    }
}
