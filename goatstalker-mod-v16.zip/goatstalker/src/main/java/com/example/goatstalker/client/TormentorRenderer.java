package com.example.goatstalker.client;

import java.util.Set;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.TormentorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * The Tormentor: the StalkerGoat model (a flat figure in the YZ plane, its front is +X) with its animations.
 * The second head ("crawl_head") belongs to the crawling animations only and is never drawn.
 */
public class TormentorRenderer extends EntityRenderer<TormentorEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/tormentor.png");
    private static final ResourceLocation TEXTURE_ONE_HORN =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/tormentor_one_horn.png");
    private static final SkeletalModel MODEL = new SkeletalModel("tormentor/model.json", "tormentor/animations.json");
    private static final Set<String> HIDDEN = Set.of("crawl_head");

    /** The model is 6.8 blocks tall in Blockbench; 0.8 makes it about 5.4 blocks. */
    private static final float MODEL_SCALE = 0.8F;

    public TormentorRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(TormentorEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the model's front (+X) looks where the entity looks
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.XP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        int index = Mth.clamp(entity.getAnim(), 0, TormentorEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, TormentorEntity.ANIM_NAMES[index], seconds, light, overlay, HIDDEN);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(TormentorEntity entity) {
        return entity.hasOneHorn() ? TEXTURE_ONE_HORN : TEXTURE;
    }
}
