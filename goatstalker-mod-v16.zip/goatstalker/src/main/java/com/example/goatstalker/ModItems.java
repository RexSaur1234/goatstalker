package com.example.goatstalker;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GoatStalkerMod.MODID);

    public static final RegistryObject<Item> STALKER_EGG = ITEMS.register("goat_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.STALKER, 0x0A0A0A, 0x35507A, new Item.Properties()));

    public static final RegistryObject<Item> EXIT_ITEM = ITEMS.register("nullspace_exit",
            () -> new BlockItem(ModBlocks.EXIT.get(), new Item.Properties()));

    public static final RegistryObject<Item> GLITCH_GRASS_ITEM = ITEMS.register("glitch_grass",
            () -> new BlockItem(ModBlocks.GLITCH_GRASS.get(), new Item.Properties()));

    public static final RegistryObject<Item> GLITCH_STONE_ITEM = ITEMS.register("glitch_stone",
            () -> new BlockItem(ModBlocks.GLITCH_STONE.get(), new Item.Properties()));

    public static final RegistryObject<Item> BIPEDAL_EGG = ITEMS.register("bipedal_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BIPEDAL_MOB, 0x101018, 0xC8C8A0, new Item.Properties()));

    public static final RegistryObject<Item> TORMENTOR_EGG = ITEMS.register("tormentor_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TORMENTOR, 0x0A0A0A, 0xB8A890, new Item.Properties()));
}
