package com.example.goatstalker;

import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * Scripted appearances of the tall creature and its helpers (not a real mob, it cannot be hit):
 * TREE       - leans out from behind a tree, hits for half of your health if you come close, then slides left.
 * ROOF       - head and shoulders on a roof in Nullspace 2, then it sinks down and the chase starts.
 * RUNNER     - the 3D model (StalkerRun) runs after the player; when it catches him it roars and he is sent back.
 * ONLOOKER   - stands in the distance and calls "hey"; when you look at it: "look this", then "hey", and it vanishes.
 * CAVE       - in a mine it leans out from behind a corner, exactly like TREE does behind a tree.
 * SHAFT_GOAT / SHAFT_FACE - a head over the top of the shaft you dug; "hi" when you see it; touch it and it hits you.
 * GOAT_TOP / GOAT_BOTTOM - the two halves of the Goat Stalker torn apart by the bipedal stalker.
 */
public class BipedalEntity extends Entity {
    public static final int TREE = 0;
    public static final int ROOF = 1;
    public static final int RUNNER = 2;
    public static final int ONLOOKER = 3;
    public static final int GOAT_TOP = 4;
    public static final int GOAT_BOTTOM = 5;
    public static final int CAVE = 6;        // leans out from behind a corner in a mine (works like TREE)
    public static final int SHAFT_GOAT = 7;  // the goat head at the top of a shaft
    public static final int SHAFT_FACE = 8;  // the little stalker's face at the top of a shaft
    public static final int DOOR = 9;        // stands in a doorway (double-door event); removed by DoorEvents
    public static final int WINDOW = 10;
    public static final int HOUSE = 11;
    public static final int PEEKER = 12;
    public static final int DARK_DOOR = 13;
    public static final int KNOCKER = 14;    // hits a window from outside until the glass breaks (then the Tormentor comes)

    public static final float KNOCKER_H = 3.2F, KNOCKER_W = 1.8625F;  // picture ratio 0.582
    public static final float KNOCKER_ANCHOR = 0.34F;                 // the face is at 34 % of the width
    public static final float KNOCKER_FACE = KNOCKER_H * 0.55F;       // and 55 % of the height (middle of the window)
    public static final double WINDOW_GAP = 1.6D;                     // the pictures stand this far behind the glass  // black doorway with a head and two arms; removed by DarkDoorEvents     // tall creature looking in through a window; calls until you look at it

    public static final float PEEKER_H = 4.6F, PEEKER_W = 1.709F;  // picture ratio 0.3716
    public static final float PEEKER_FACE = 0.925F;                // the face is at 92.5 % of the height      // stands behind a house in a village; stare at it 10 s and it becomes the bipedal stalker

    public static final float HOUSE_H = 3.4F, HOUSE_W = 2.889F;    // picture ratio 0.8498     // behind a window glass (double-door event); removed by DoorEvents

    // the door creature is as big as the wall: body in the doorway, head ~1.8 blocks above the door, arm along the wall
    public static final float DOOR_H = 3.9F, DOOR_W = 4.143F;      // picture ratio 1.0622
    public static final float DOOR_ANCHOR = 0.16F;                 // the body is at 16 % of the picture width
    public static final float WINDOW_H = 3.2F, WINDOW_W = 2.0F;    // picture ratio 0.625
    public static final float WINDOW_ANCHOR = 0.35F;               // the face is at 35 % of the picture width

    /** Size of the cave-corner picture in blocks (width = height * ratio 1.136). */
    public static final float CAVE_H = 3.0F;
    public static final float CAVE_W = 3.408F;

    /** Size of the tree picture in blocks (height * ratio 0.4521); the renderer and the spawn code both use it. */
    public static final float TREE_H = 4.2F;
    public static final float TREE_W = 1.899F;

    /** Runner animations: 0 = terror (running), 1 = grito (roaring, when it has caught you). */
    public static final int ANIM_RUN = 0;
    public static final int ANIM_SCREAM = 1;

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);
    /** Knocker: crack stage of the glass (0-3) plus 16 if the window is a thin glass pane. */
    private static final EntityDataAccessor<Integer> DATA_EXTRA =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);

    private UUID target;
    private double slideX;
    private double slideZ;
    private boolean hit;
    private int caughtAt = -1;
    // goat halves
    private double vx;
    private double vy;
    private double vz;
    private boolean landed;
    // onlooker
    private int olPhase = 0;
    private int olNext = 0;
    private int olTimer = 0;
    // shaft heads
    private boolean seen = false;
    // the creature behind a house
    private int lookTicks = 0;
    private int awayTicks = 0;
    // the window peeker
    private int lookedAt = -1;
    private int nextCall = 0;

    public BipedalEntity(EntityType<? extends BipedalEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_KIND, TREE);
        this.entityData.define(DATA_ANIM, ANIM_RUN);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_EXTRA, 0);
    }

    public int getCrack() {
        return this.entityData.get(DATA_EXTRA) & 15;
    }

    public boolean isPaneWindow() {
        return (this.entityData.get(DATA_EXTRA) & 16) != 0;
    }

    private BlockPos windowPos;

    /** The knocker's window (server side). */
    public void setWindow(BlockPos glass, boolean pane) {
        this.windowPos = glass.immutable();
        this.entityData.set(DATA_EXTRA, pane ? 16 : 0);
    }

    public int getKind() {
        return this.entityData.get(DATA_KIND);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getAnimStart() {
        return this.entityData.get(DATA_ANIM_START);
    }

    /** Client only: the client's own tick when the current animation started. */
    private int clientAnimStart;

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    public void setup(int kind, UUID target) {
        this.entityData.set(DATA_KIND, kind);
        this.target = target;
    }

    public void setSlide(double x, double z) {
        this.slideX = x;
        this.slideZ = z;
    }

    public void setVelocity(double x, double y, double z) {
        this.vx = x;
        this.vy = y;
        this.vz = z;
    }

    /** The pictures and the model are bigger than the entity box, so make the culling box big enough. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 5, getY() - 1, getZ() - 5, getX() + 5, getY() + 9, getZ() + 5);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        int kind = getKind();
        if (kind == GOAT_TOP || kind == GOAT_BOTTOM) {
            tickHalf();
            return;
        }
        ServerPlayer p = this.target == null ? null : sl.getServer().getPlayerList().getPlayer(this.target);
        if (p == null || p.level() != this.level() || !p.isAlive()) {
            this.discard();
            return;
        }
        switch (kind) {
            case TREE, CAVE -> tickTree(p);
            case SHAFT_GOAT, SHAFT_FACE -> tickShaft(sl, p);
            case HOUSE -> tickHouse(sl, p);
            case PEEKER -> tickPeeker(sl, p);
            case KNOCKER -> tickKnocker(sl, p);
            case DARK_DOOR -> {
                if (this.tickCount > StalkerConfig.DARK_DOOR_SECONDS.get() * 20 + 400) { // safety
                    this.discard();
                } else if (this.tickCount % 5 == 0) {
                    DoorEvents.keepOpen(sl, p.getUUID());
                }
            }
            case DOOR, WINDOW -> {
                if (this.tickCount > 3000) { // safety: DoorEvents normally removes it much sooner
                    this.discard();
                    return;
                }
                if (kind == DOOR && this.tickCount % 5 == 0) {
                    DoorEvents.keepOpen(sl, p.getUUID());
                }
                if (kind == DOOR && StalkerConfig.DOOR_KILLS.get() && !p.isCreative() && !p.isSpectator()) {
                    double dx = p.getX() - getX();
                    double dz = p.getZ() - getZ();
                    if (dx * dx + dz * dz < 4.0D && Math.abs(p.getY() - getY()) < 3.0D) { // closer than 2 blocks
                        DoorEvents.killedByDoor(p);
                        p.hurt(this.level().damageSources().magic(), Float.MAX_VALUE);
                        this.discard();
                    }
                }
            }
            case ROOF -> tickRoof(sl, p);
            case ONLOOKER -> tickOnlooker(sl, p);
            default -> tickRunner(sl, p);
        }
    }

    // ------------------------------ goat halves ------------------------------
    private void tickHalf() {
        if (this.tickCount > 80) {
            this.discard();
            return;
        }
        if (this.landed) {
            return;
        }
        this.vy -= 0.05D;
        double nx = getX() + this.vx;
        double ny = getY() + this.vy;
        double nz = getZ() + this.vz;
        BlockPos pos = BlockPos.containing(nx, ny, nz);
        if (this.vy < 0.0D && !this.level().getBlockState(pos).getCollisionShape(this.level(), pos).isEmpty()) {
            this.landed = true;
            ny = Mth.floor(ny) + 1.0D;
        }
        setPos(nx, ny, nz);
    }

    // ------------------------------ onlooker ------------------------------
    private boolean isLookedAtBy(ServerPlayer p) {
        return isLookedAt(p, 3.0D);
    }

    private boolean isLookedAt(ServerPlayer p, double aimHeight) {
        Vec3 eye = p.getEyePosition();
        Vec3 aim = new Vec3(getX(), getY() + aimHeight, getZ());
        Vec3 to = aim.subtract(eye);
        double d = to.length();
        if (d > 70.0D || d < 0.5D) {
            return false;
        }
        if (p.getViewVector(1.0F).dot(to.scale(1.0D / d)) < 0.9D) {
            return false;
        }
        return this.level().clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    private void tickOnlooker(ServerLevel sl, ServerPlayer p) {
        switch (this.olPhase) {
            case 0 -> { // it keeps calling "hey" until somebody looks at it
                if (this.tickCount >= this.olNext) {
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.GOAT_HEY.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olNext = this.tickCount + ModSounds.GOAT_HEY_TICKS + 15;
                }
                if (isLookedAtBy(p)) {
                    p.connection.send(new ClientboundStopSoundPacket(
                            new ResourceLocation(GoatStalkerMod.MODID, "goat_hey"), SoundSource.HOSTILE));
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.LOOK_THIS.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olPhase = 1;
                    this.olTimer = this.tickCount;
                } else if (this.tickCount > 2400) { // nobody looked for 2 minutes
                    this.discard();
                }
            }
            case 1 -> { // "look this", then "hey"
                if (this.tickCount - this.olTimer >= ModSounds.LOOK_THIS_TICKS) {
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.HEY_VOICE.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olPhase = 2;
                    this.olTimer = this.tickCount;
                }
            }
            default -> {
                if (this.tickCount - this.olTimer >= ModSounds.HEY_VOICE_TICKS + 40) {
                    this.discard();
                }
            }
        }
    }

    // ------------------------------ shaft heads ------------------------------
    public boolean isShaftHeadOf(ServerPlayer p) {
        int k = getKind();
        return (k == SHAFT_GOAT || k == SHAFT_FACE) && this.target != null && this.target.equals(p.getUUID());
    }

    /** The head is touched or dug toward: it vanishes and takes half of the player's health. */
    public void strike(ServerPlayer p) {
        halveHealth(p);
        this.discard();
    }

    private void tickShaft(ServerLevel sl, ServerPlayer p) {
        int life = getKind() == SHAFT_GOAT ? 200 : 170; // the goat head stays 10 seconds
        if (this.tickCount > life) {
            this.discard();
            return;
        }
        if (!this.seen && isLookedAt(p, 0.0D)) { // the entity position is the centre of the picture
            this.seen = true;
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.PEEK_HI.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
        }
        double dx = p.getX() - getX();
        double dy = p.getEyeY() - getY();
        double dz = p.getZ() - getZ();
        if (dx * dx + dy * dy + dz * dz < 12.25D) { // closer than 3.5 blocks
            strike(p);
        }
    }

    // ------------------------------ window peeker ------------------------------
    /** Looking at its face through the window: the glass in between does not count as a wall. */
    private boolean seenThroughWindow(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 aim = new Vec3(getX(), getY() + PEEKER_H * PEEKER_FACE, getZ());
        Vec3 to = aim.subtract(eye);
        double d = to.length();
        if (d > 64.0D || d < 0.5D || p.getViewVector(1.0F).dot(to.scale(1.0D / d)) < 0.95D) {
            return false;
        }
        HitResult hit = this.level().clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceTo(aim) < 2.6D; // hit the window glass
    }

    private static final ResourceLocation PEEKER_MUSIC_ID = new ResourceLocation(GoatStalkerMod.MODID, "peeker_music");
    private int nextMusic = 0;

    // ------------------------------ knocker ------------------------------
    /** Wind-up (picture 1), hit (picture 2) every 2 seconds: 3 hits crack the glass more and more, the 4th breaks it. */
    private void tickKnocker(ServerLevel sl, ServerPlayer p) {
        if (this.windowPos == null || this.tickCount > 1200
                || sl.getBlockState(this.windowPos).getCollisionShape(sl, this.windowPos).isEmpty()) {
            this.discard(); // the glass is gone (or something went wrong)
            return;
        }
        int c = this.tickCount - 20;
        if (c < 0) {
            return;
        }
        int phase = c % 40;
        int frame = phase >= 28 ? 1 : 0;
        if (frame != getAnim()) {
            this.entityData.set(DATA_ANIM, frame);
        }
        if (phase != 30) {
            return;
        }
        double gx = this.windowPos.getX() + 0.5D;
        double gy = this.windowPos.getY() + 0.5D;
        double gz = this.windowPos.getZ() + 0.5D;
        sl.playSound(null, gx, gy, gz, ModSounds.WINDOW_HIT.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
        int stage = getCrack() + 1;
        if (stage <= 3) {
            this.entityData.set(DATA_EXTRA, (this.entityData.get(DATA_EXTRA) & 16) | stage);
            return;
        }
        KnockerEvents.windowBroken(sl, p, this.windowPos, position());
        this.discard();
    }

    private void tickPeeker(ServerLevel sl, ServerPlayer p) {
        if (this.tickCount >= this.nextMusic) { // its music plays (and repeats) for as long as it stands at the window
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.PEEKER_MUSIC.get(), SoundSource.MASTER, 1.0F, 1.0F);
            this.nextMusic = this.tickCount + ModSounds.PEEKER_MUSIC_TICKS;
        }
        int stay = StalkerConfig.PEEKER_STAY_MINUTES.get() * 1200;
        if (p.distanceToSqr(this) > 120.0D * 120.0D) {
            this.discard();
            return;
        }
        if (this.lookedAt < 0) {
            if (this.tickCount > stay) { // nobody looked at it
                this.discard();
                return;
            }
            if (this.tickCount >= this.nextCall) { // it keeps calling (peek_hi)
                sl.playSound(null, getX(), getY() + PEEKER_H * PEEKER_FACE, getZ(), ModSounds.PEEK_HI.get(),
                        SoundSource.HOSTILE, 2.5F, 1.0F);
                this.nextCall = this.tickCount + 32 + 30;
            }
            if (seenThroughWindow(p)) {
                this.lookedAt = this.tickCount;
                p.connection.send(new ClientboundStopSoundPacket(
                        new ResourceLocation(GoatStalkerMod.MODID, "peek_hi"), SoundSource.HOSTILE));
                sl.playSound(null, getX(), getY() + PEEKER_H * PEEKER_FACE, getZ(), ModSounds.GOAT_WINDOW_VOICE.get(),
                        SoundSource.HOSTILE, 3.0F, 1.0F);
            }
            return;
        }
        if (this.tickCount - this.lookedAt > stay) { // 10 minutes after you saw it
            this.discard();
        }
    }

    // ------------------------------ behind a house ------------------------------
    private void tickHouse(ServerLevel sl, ServerPlayer p) {
        if (this.tickCount > 3600 || p.distanceToSqr(this) > 100.0D * 100.0D) { // 3 minutes, or the player went away
            this.discard();
            return;
        }
        if (isLookedAt(p, HOUSE_H * 0.55D)) {
            this.lookTicks++;
            this.awayTicks = 0;
        } else if (++this.awayTicks > 20) { // looked away for more than a second: start again
            this.lookTicks = 0;
        }
        if (this.lookTicks < StalkerConfig.HOUSE_LOOK_SECONDS.get() * 20) {
            return;
        }
        // it turns into the bipedal stalker, with the sound of cracking bones, and attacks
        sl.playSound(null, getX(), getY() + 2.5D, getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.9F);
        BipedalMobEntity mob = ModEntities.BIPEDAL_MOB.get().create(sl);
        if (mob != null) {
            double dx = p.getX() - getX();
            double dz = p.getZ() - getZ();
            mob.moveTo(getX(), getY(), getZ(), (float) (Mth.atan2(-dx, dz) * 57.29577951308232D), 0.0F);
            mob.setTimedLife(9600);
            sl.addFreshEntity(mob);
            if (!p.isCreative() && !p.isSpectator()) {
                mob.huntNow(p);
            }
        }
        this.discard();
    }

    // ------------------------------ tree ------------------------------
    private void tickTree(ServerPlayer p) {
        if (this.tickCount < 200) {
            if (!this.hit) {
                double dx = p.getX() - getX();
                double dz = p.getZ() - getZ();
                if (dx * dx + dz * dz < 25.0D) { // the player came closer than 5 blocks
                    this.hit = true;
                    halveHealth(p);
                    this.tickCount = 200;        // and it leaves right away
                }
            }
            return;
        }
        if (this.tickCount < 214) {
            setPos(getX() + this.slideX * 0.07D, getY(), getZ() + this.slideZ * 0.07D);
            return;
        }
        this.discard();
    }

    private void halveHealth(ServerPlayer p) {
        float cur = p.getHealth();
        float dmg = cur / 2.0F;
        if (cur - dmg < 1.0F) {
            dmg = cur - 1.0F;
        }
        if (dmg > 0.0F) {
            p.hurt(this.level().damageSources().magic(), dmg);
        }
    }

    // ------------------------------ roof ------------------------------
    private void tickRoof(ServerLevel sl, ServerPlayer p) {
        if (this.tickCount >= 60 && this.tickCount < 82) {
            setPos(getX(), getY() - 0.13D, getZ()); // head and shoulders go down behind the roof
        } else if (this.tickCount >= 82) {
            // the runner starts on the ground beside the house, on the side facing the player
            double dx = p.getX() - getX();
            double dz = p.getZ() - getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 1.0D) {
                dx = 1.0D;
                dz = 0.0D;
                len = 1.0D;
            }
            BipedalEntity runner = ModEntities.BIPEDAL.get().create(sl);
            if (runner != null) {
                runner.setup(RUNNER, p.getUUID());
                runner.setPos(getX() + dx / len * 6.0D, Nullspace.GROUND_TOP, getZ() + dz / len * 6.0D);
                runner.faceTo(dx, dz);
                sl.addFreshEntity(runner);
                NullspaceEvents.startVillageChase(p);
            }
            this.discard();
        }
    }

    // ------------------------------ runner ------------------------------
    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        this.setYRot(yaw);
        this.setXRot(0.0F);
    }

    private void tickRunner(ServerLevel sl, ServerPlayer p) {
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        faceTo(dx, dz);

        if (this.caughtAt >= 0) { // it has caught the player: it roars, then he is sent back
            if (this.tickCount - this.caughtAt > 45) {
                this.discard();
            }
            return;
        }
        if (d < 2.6D) {
            this.caughtAt = this.tickCount;
            this.entityData.set(DATA_ANIM, ANIM_SCREAM);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
            NullspaceEvents.stopMusic(p);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.SCREAM.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
            NullspaceEvents.schedule(sl.getServer(), 38, () -> NullspaceEvents.returnPlayerIfInNullspace(p));
            return;
        }
        setPos(getX() + dx / d * 0.42D, Nullspace.GROUND_TOP, getZ() + dz / d * 0.42D);
        if (this.tickCount % 4 == 0) {
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GRAVEL_STEP, SoundSource.HOSTILE, 1.5F, 0.6F);
        }
        if (this.tickCount > 900) {
            this.discard();
        }
    }

    /** When the window creature goes away (for any reason) its music stops. */
    @Override
    public void remove(RemovalReason reason) {
        if (getKind() == PEEKER && this.level() instanceof ServerLevel sl && this.target != null) {
            ServerPlayer p = sl.getServer().getPlayerList().getPlayer(this.target);
            if (p != null) {
                p.connection.send(new ClientboundStopSoundPacket(PEEKER_MUSIC_ID, SoundSource.MASTER));
            }
        }
        super.remove(reason);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
