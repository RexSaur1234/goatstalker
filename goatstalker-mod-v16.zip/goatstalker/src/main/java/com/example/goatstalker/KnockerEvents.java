package com.example.goatstalker;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Every 20 minutes, while the player is indoors, the creature comes to a window and hits it (wind-up, hit): the glass
 * cracks more with every hit and the 4th hit breaks it. The player is blinded for 4 seconds, "bipedal stalker wait"
 * plays for 20 seconds, and outside the Tormentor appears.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class KnockerEvents {
    private static final Map<UUID, Long> NEXT = new HashMap<>();
    private static final ResourceLocation WAIT_MUSIC = new ResourceLocation(GoatStalkerMod.MODID, "peeker_music");

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.KNOCKER_ENABLED.get()) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long now = level.getGameTime();
        long every = StalkerConfig.KNOCKER_MINUTES.get() * 1200L;
        long next = NEXT.computeIfAbsent(p.getUUID(), k -> now + every);
        if (now < next || level.canSeeSky(p.blockPosition())) {
            return; // not yet, or the player is not indoors
        }
        NEXT.put(p.getUUID(), now + (start(p, level) ? every : 600L));
    }

    public static boolean start(ServerPlayer p, ServerLevel level) {
        for (BipedalEntity e : level.getEntitiesOfClass(BipedalEntity.class, p.getBoundingBox().inflate(64.0D))) {
            if (e.getKind() == BipedalEntity.KNOCKER) {
                return false;
            }
        }
        List<BlockPos> windows = DoorEvents.windowsNear(level, p, 16);
        for (int i = 0; i < windows.size() && i < 64; i++) {
            BlockPos g = windows.get(i);
            BlockState st = level.getBlockState(g);
            if (st.getBlock() instanceof FenceBlock) {
                continue; // only real glass
            }
            BipedalEntity e = DoorEvents.spawnAtWindow(level, p, g, BipedalEntity.KNOCKER, BipedalEntity.KNOCKER_FACE);
            if (e != null) {
                e.setWindow(g, st.getBlock() instanceof IronBarsBlock);
                return true;
            }
        }
        return false;
    }

    /** The 4th hit: the glass breaks, blindness, music, and the Tormentor outside. */
    static void windowBroken(ServerLevel level, ServerPlayer p, BlockPos glass, Vec3 knockerPos) {
        level.destroyBlock(glass, false);
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0, false, false));

        level.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.PEEKER_MUSIC.get(), SoundSource.MASTER, 1.0F, 1.0F);
        NullspaceEvents.schedule(level.getServer(), 400,
                () -> p.connection.send(new ClientboundStopSoundPacket(WAIT_MUSIC, SoundSource.MASTER)));

        // the Tormentor stands outside, a few blocks from the window, on the ground
        double ox = knockerPos.x - (glass.getX() + 0.5D);
        double oz = knockerPos.z - (glass.getZ() + 0.5D);
        double len = Math.max(0.01D, Math.sqrt(ox * ox + oz * oz));
        ox /= len;
        oz /= len;
        double x = glass.getX() + 0.5D + ox * 3.5D;
        double z = glass.getZ() + 0.5D + oz * 3.5D;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
        if (Math.abs(y - glass.getY()) > 6) {
            y = glass.getY() - 1;
        }
        TormentorEntity t = ModEntities.TORMENTOR.get().create(level);
        if (t == null) {
            return;
        }
        float yaw = (float) (Mth.atan2(ox, -oz) * 57.29577951308232D); // looks at the window
        t.moveTo(x, y, z, yaw, 0.0F);
        t.setPersistenceRequired();
        if (!p.isCreative() && !p.isSpectator()) {
            t.setTarget(p);
        }
        level.addFreshEntity(t);
    }

    // ------------------------------ commands ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var knocker = Commands.literal("knocker").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!start(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No glass window with free room behind it within 16 blocks."));
                return 0;
            }
            return 1;
        });
        var tormentor = Commands.literal("tormentor").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            Vec3 at = ahead(p, 14.0D);
            TormentorEntity t = ModEntities.TORMENTOR.get().create(p.serverLevel());
            if (t == null) {
                return 0;
            }
            t.moveTo(at.x, at.y, at.z, p.getYRot() + 180.0F, 0.0F);
            p.serverLevel().addFreshEntity(t);
            return 1;
        });
        var battle = Commands.literal("tormentorBattle").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            Vec3 a = ahead(p, 12.0D);
            Vec3 b = ahead(p, 26.0D);
            TormentorEntity t = ModEntities.TORMENTOR.get().create(level);
            BipedalMobEntity m = ModEntities.BIPEDAL_MOB.get().create(level);
            if (t == null || m == null) {
                return 0;
            }
            t.moveTo(a.x, a.y, a.z, p.getYRot(), 0.0F);
            m.moveTo(b.x, b.y, b.z, p.getYRot() + 180.0F, 0.0F);
            level.addFreshEntity(t);
            level.addFreshEntity(m);
            t.startFight(m);
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(knocker).then(tormentor).then(battle));
    }

    private static Vec3 ahead(ServerPlayer p, double dist) {
        double a = Math.toRadians(p.getYRot());
        double x = p.getX() - Math.sin(a) * dist;
        double z = p.getZ() + Math.cos(a) * dist;
        int y = p.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
        return new Vec3(x, y, z);
    }
}
