GOAT STALKER (Forge 1.20.1)

КАК СОБРАТЬ JAR
1. Скачай Forge MDK 1.20.1 (47.x): files.minecraftforge.net -> 1.20.1 -> Mdk. Распакуй.
2. В MDK удали папку src и файлы build.gradle, gradle.properties, settings.gradle.
3. Скопируй сюда всё из этого архива (src, build.gradle, gradle.properties, settings.gradle).
   Папки gradle/ и файлы gradlew, gradlew.bat остаются из MDK.
4. Нужна Java 17. Запусти в этой папке:  gradlew build
5. Готовый jar: build/libs/goatstalker-1.0.0.jar -> положи в папку mods.

ТЕСТ БЕЗ ОЖИДАНИЯ
В игре: /summon goatstalker:goat_stalker  или яйцо в творческом инвентаре (вкладка яиц).
Настройки: config/goatstalker-common.toml

НОВОЕ: ДВУНОГИЙ СТАЛКЕР И NULLSPACE 2
Команды (нужны права оператора):
  /goatstalker bipedalStalkerTree    - существо выглядывает из-за ближайшего дерева (нужен лес рядом)
  /goatstalker bipedalStalkerhouse   - телепорт в Nullspace 2 (деревня)
  /goatstalker bipedalStalkerRoof    - (в Nullspace 2) вызвать существо на крыше
  /goatstalker nullspaceReturn       - вернуться обратно
Блок выхода: "Nullspace Exit" (творческий режим, вкладка функциональных блоков).

ЦЕПОЧКА: трава -> Island -> Village -> назад
  Сбойная трава (светится, проходимая) иногда появляется рядом: коснулся -> Nullspace 1 (Island).
  Island: плоский мир, вдали башня. Подойдёшь ближе - "RUN, IT'S BEHIND YOU" и двуногий бежит за тобой.
  В башне по центру светящийся сбойный камень: наступил -> Nullspace 2 (Village).
  Из Village выход: блок Nullspace Exit (или тебя догонит двуногий).
Команды: /goatstalker island | glitchGrass | bipedalStalkerhouse | bipedalStalkerTree | bipedalStalkerRoof | nullspaceReturn

МУЗЫКА: когда убегаешь на Island, играет island_chase.ogg (повторяется, пока идёт погоня; громкость - ползунок "Музыка").

ОБНОВЛЕНИЕ: 3D-МОДЕЛЬ, МУЗЫКА, ДЕРЕВНЯ-ПЛЮС
- Бегущий двуногий (Island и Village) - модель StalkerRun, анимация terror (бег), grito (крик, когда догнал).
  Модель и анимации: src/main/resources/assets/goatstalker/stalker/ (остальные анимации уже внутри:
  crack, grabbed, hanging, gateo, escalar, salto, espera, acercar, encorvar).
- Размер модели: константа MODEL_SCALE в client/BipedalRenderer.java.
- Музыка (стерео, слышна на всю карту, ползунок "Музыка"):
    island_chase.ogg   - побег на Island
    village_arrive.ogg - при входе в Village (watcher_chase.ogg, 17 с, повторяется до начала погони)
    village_chase.ogg  - побег от двуногого в Village (прежняя песня)
- Надпись RUN, IT'S BEHIND YOU трясётся и висит, пока двуногий бежит на Island (рисует клиент).
- Village: два пересекающихся проспекта (плюс), 100 домов во всех четырёх сторонах и в углах, мир ограничен
  (граница мира 150x150). Один дом с выходом стоит сбоку, на восточном конце. Измерение называется goatstalker:village.
- Двуногий появляется на случайном далёком доме (45-95 блоков от игрока).

ВЕРСИЯ 1.2.0: Onlooker, настоящий двуногий сталкер, битва с козлом
- Onlooker (картинка onlooker.png): появляется в 22-34 блоках впереди, пока ты не смотришь - зовёт "hey" (goat_hey).
  Посмотрел -> "look this", потом "hey" (hey_voice), потом исчезает. Не посмотрел 2 минуты - исчезает.
- Настоящий двуногий (яйцо в творческом режиме, /goatstalker bipedalMob): 200 здоровья, убивается.
  Приседает и ползёт в узких местах, ломает стёкла, лазит по стенам и ползёт по потолку, не проходит сквозь стены.
  Увидел Goat Stalker - бежит к нему, бьётся и разрывает пополам (/goatstalker battle - проверка).
  Поймал игрока - поднимает, орёт (stalker_scream_alt), бросает на пол, бьёт ногой, игрок погибает.
  Рык (stalker_roar = ice_sale.ogg) и текстура рыка (stalker_run_scream.png) - когда он рычит.
- Новые анимации lift (поднял игрока) и kick (удар ногой) написаны мной в том же формате.
- Яйцо двуногого: textures/item/bipedal_stalker_spawn_egg.png.
Команды: /goatstalker onlooker | bipedalMob | battle
Config: onlookerEnabled/onlookerMinutes, bipedalStalkerEnabled/bipedalStalkerMinutes
