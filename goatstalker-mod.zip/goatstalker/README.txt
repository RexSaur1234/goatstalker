GOAT STALKER (Forge 1.20.1)

КАК СОБРАТЬ JAR
1. Скачай Forge MDK 1.20.1 (47.x): files.minecraftforge.net -> 1.20.1 -> Mdk. Распакуй.
2. В MDK удали папку src и файлы build.gradle, gradle.properties, settings.gradle.
3. Скопируй сюда всё из этого архива (src, build.gradle, gradle.properties, settings.gradle).
   Папки gradle/ и файлы gradlew, gradlew.bat остаются из MDK.
4. Нужна Java 17. Запусти в этой папке:  gradlew build
5. Готовый jar: build/libs/goatstalker-1.0.0.jar -> положи в папку mods.

ТЕСТ БЕЗ ОЖИДАНИЯ
В игре: /summon goatstalker:goat_stalker  или яйцо в творческом инвентаре (вкладка яиц).
Настройки: config/goatstalker-common.toml

НОВОЕ: ДВУНОГИЙ СТАЛКЕР И NULLSPACE 2
Команды (нужны права оператора):
  /goatstalker bipedalStalkerTree    - существо выглядывает из-за ближайшего дерева (нужен лес рядом)
  /goatstalker bipedalStalkerhouse   - телепорт в Nullspace 2 (деревня)
  /goatstalker bipedalStalkerRoof    - (в Nullspace 2) вызвать существо на крыше
  /goatstalker nullspaceReturn       - вернуться обратно
Блок выхода: "Nullspace Exit" (творческий режим, вкладка функциональных блоков).

ЦЕПОЧКА: трава -> Island -> Village -> назад
  Сбойная трава (светится, проходимая) иногда появляется рядом: коснулся -> Nullspace 1 (Island).
  Island: плоский мир, вдали башня. Подойдёшь ближе - "RUN, IT'S BEHIND YOU" и двуногий бежит за тобой.
  В башне по центру светящийся сбойный камень: наступил -> Nullspace 2 (Village).
  Из Village выход: блок Nullspace Exit (или тебя догонит двуногий).
Команды: /goatstalker island | glitchGrass | bipedalStalkerhouse | bipedalStalkerTree | bipedalStalkerRoof | nullspaceReturn

МУЗЫКА: когда убегаешь на Island, играет island_chase.ogg (повторяется, пока идёт погоня; громкость - ползунок "Музыка").

ОБНОВЛЕНИЕ: 3D-МОДЕЛЬ, МУЗЫКА, ДЕРЕВНЯ-ПЛЮС
- Бегущий двуногий (Island и Village) - модель StalkerRun, анимация terror (бег), grito (крик, когда догнал).
  Модель и анимации: src/main/resources/assets/goatstalker/stalker/ (остальные анимации уже внутри:
  crack, grabbed, hanging, gateo, escalar, salto, espera, acercar, encorvar).
- Размер модели: константа MODEL_SCALE в client/BipedalRenderer.java.
- Музыка (стерео, слышна на всю карту, ползунок "Музыка"):
    island_chase.ogg   - побег на Island
    village_arrive.ogg - при входе в Village (watcher_chase.ogg, 17 с, повторяется до начала погони)
    village_chase.ogg  - побег от двуногого в Village (прежняя песня)
- Надпись RUN, IT'S BEHIND YOU трясётся и висит, пока двуногий бежит на Island (рисует клиент).
- Village: два пересекающихся проспекта (плюс), 100 домов во всех четырёх сторонах и в углах, мир ограничен
  (граница мира 150x150). Один дом с выходом стоит сбоку, на восточном конце. Измерение называется goatstalker:village.
- Двуногий появляется на случайном далёком доме (45-95 блоков от игрока).

ВЕРСИЯ 1.2.0: Onlooker, настоящий двуногий сталкер, битва с козлом
- Onlooker (картинка onlooker.png): появляется в 22-34 блоках впереди, пока ты не смотришь - зовёт "hey" (goat_hey).
  Посмотрел -> "look this", потом "hey" (hey_voice), потом исчезает. Не посмотрел 2 минуты - исчезает.
- Настоящий двуногий (яйцо в творческом режиме, /goatstalker bipedalMob): 200 здоровья, убивается.
  Приседает и ползёт в узких местах, ломает стёкла, лазит по стенам и ползёт по потолку, не проходит сквозь стены.
  Увидел Goat Stalker - бежит к нему, бьётся и разрывает пополам (/goatstalker battle - проверка).
  Поймал игрока - поднимает, орёт (stalker_scream_alt), бросает на пол, бьёт ногой, игрок погибает.
  Рык (stalker_roar = ice_sale.ogg) и текстура рыка (stalker_run_scream.png) - когда он рычит.
- Новые анимации lift (поднял игрока) и kick (удар ногой) написаны мной в том же формате.
- Яйцо двуногого: textures/item/bipedal_stalker_spawn_egg.png.
Команды: /goatstalker onlooker | bipedalMob | battle
Config: onlookerEnabled/onlookerMinutes, bipedalStalkerEnabled/bipedalStalkerMinutes

ВЕРСИЯ 1.3.0: головы в шахте и существо за углом
- Копаешь строго вниз (8+ блоков) -> 30%: у входа в шахту смотрит голова козла (onlyhead2.png), 10 секунд.
  Звук peek_hi, когда ты её увидел. Не копаешь - она просто исчезает.
- Выбрался взглядом вверх из глубокой шахты (после остановки) -> 20%: смотрит лицо маленького сталкера (little_stalker.png).
- Начать копать вверх к голове или подойти ближе 3.5 блоков -> голова исчезает и снимает половину здоровья.
- В шахтах (под землёй) изредка существо выглядывает из-за угла (stalkerjumpscare.png), как двуногий за деревом:
  подошёл ближе 5 блоков -> минус половина здоровья и уходит; не подходил - через 10 секунд уходит за угол.
Команды: /goatstalker shaftGoat | shaftFace | caveCorner
Config: shaftEventsEnabled, shaftGoatHeadPercent, shaftFacePercent, caveCornerEnabled, caveCornerMinutes

ВЕРСИЯ 1.4.0: событие двойной двери и окна
- Игрок строит двойную дверь (две двери рядом) -> с шансом 30% в проёме появляется существо (door_creature.png).
  Музыка: door -> Tormentor R -> door -> Tormentor R (tormentor_door.ogg, tormentor_r.ogg).
- Потом существо в двери пропадает, появляется в окне (стекло/решётка рядом, knocker_window1.png), музыка не стихает,
  затем звук монстра (goat_window_voice.ogg), существо и музыка пропадают.
- Если окна рядом нет, второе существо появляется в проёме двери.
Команда: /goatstalker doorEvent (проверка: существо ставится в 4 блоках перед тобой)
Config: doubleDoorEventEnabled, doubleDoorPercent (30), doubleDoorCooldownMinutes (10)

ВЕРСИЯ 1.4.1: исправление двери
- Существо в двери теперь размером со стену (3.9 блока): тело в проёме, голова над дверью, рука тянется по стене.
  Оно плоско лежит на стене с твоей стороны и не поворачивается за камерой. Двери сами открываются.
- Музыка door и Tormentor R была очень тихой в самих файлах (-44 дБ), громкость поднята примерно на 20 дБ.
  Теперь она играет в категории "Общая громкость", так что слышна даже при выключенной музыке в настройках.
- Окно ищется сначала в той же стене, что и дверь (до 10 блоков влево и вправо): стекло, панель, решётка,
  люк, забор или просто дыра в стене. Лицо существа смотрит в окно снаружи.
- Существо в окне появляется только через ~48 секунд (после door, R, door, R).
- /goatstalker doorEvent теперь берёт ближайшую дверь в 8 блоках.

ВЕРСИЯ 1.4.2
- Шанс события двери: 30% каждый раз, когда ты строишь двойную дверь, но не чаще одного раза в 10 минут
  (config: doubleDoorPercent, doubleDoorCooldownMinutes).
- Подошёл к существу в двери ближе 2 блоков -> сразу смерть, существо и музыка пропадают (doorCreatureKills).
- Второе существо появляется в ближайшем к игроку стекле (стекло, стеклянная панель, решётка) или заборе, до 24 блоков.
  Люки и дыры в стене больше не считаются.
- Каждые 20 минут за спиной звучит голос "I know you're here" (iknowyourhere.ogg).
  Config: iKnowYoureHereEnabled, iKnowYoureHereMinutes. Проверка: /goatstalker iKnowYoureHere

ВЕРСИЯ 1.4.3
- Пока существо стоит в проёме, двери закрыть нельзя (ни рукой, ни редстоуном - они сразу открываются обратно).
