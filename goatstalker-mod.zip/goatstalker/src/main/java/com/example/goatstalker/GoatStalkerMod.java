package com.example.goatstalker;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GoatStalkerMod.MODID)
public class GoatStalkerMod {
    public static final String MODID = "goatstalker";

    public GoatStalkerMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener(this::onCreativeTab);
        bus.addListener(this::onSpawnPlacements);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, StalkerConfig.SPEC);
        Crawl.register();
        AnguishNet.register();
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.STALKER.get(), StalkerEntity.createAttributes().build());
        event.put(ModEntities.BIPEDAL_MOB.get(), BipedalMobEntity.createAttributes().build());
        event.put(ModEntities.TORMENTOR.get(), TormentorEntity.createAttributes().build());
        event.put(ModEntities.BIPEDAL_2.get(), BipedalStalker2Entity.createAttributes().build());
        event.put(ModEntities.EVIL_TORMENTOR.get(), EvilDarkTormentorEntity.createAttributes().build());
        event.put(ModEntities.SUFFERING.get(), SufferingEntity.createAttributes().build());
        event.put(ModEntities.ANGUISH.get(), AnguishEntity.createAttributes().build());
        event.put(ModEntities.QUADRUPED.get(), QuadrupedStalkerEntity.createAttributes().build());
    }

    /** Anguish spawns on its own, rarely, in the dark (data/goatstalker/forge/biome_modifier/anguish.json). */
    private void onSpawnPlacements(net.minecraftforge.event.entity.SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.ANGUISH.get(), net.minecraft.world.entity.SpawnPlacements.Type.ON_GROUND,
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                AnguishEntity::checkAnguishSpawn, net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.REPLACE);
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.STALKER_EGG);
            event.accept(ModItems.BIPEDAL_EGG);
            event.accept(ModItems.BIPEDAL_2_EGG);
            event.accept(ModItems.TORMENTOR_EGG);
            event.accept(ModItems.EVIL_TORMENTOR_EGG);
            event.accept(ModItems.SUFFERING_EGG);
            event.accept(ModItems.ANGUISH_EGG);
            event.accept(ModItems.QUADRUPED_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.EXIT_ITEM);
            event.accept(ModItems.GLITCH_GRASS_ITEM);
            event.accept(ModItems.GLITCH_STONE_ITEM);
            event.accept(ModItems.TV_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.CASSETTE);
        }
    }
}
