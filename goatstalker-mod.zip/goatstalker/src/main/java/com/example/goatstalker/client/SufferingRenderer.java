package com.example.goatstalker.client;

import java.util.Collections;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.SufferingEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Sufferings: the player's Blockbench model (StalkerDiversion.geo.json) with its animations, 12 blocks tall in
 * Blockbench; scaled 2.1 times = about 25 blocks, three times the Evil Dark Tormentor (8.4 blocks).
 */
public class SufferingRenderer extends EntityRenderer<SufferingEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/suffering.png");
    public static final SkeletalModel MODEL = new SkeletalModel("suffering/model.json", "suffering/animations.json");
    public static final float MODEL_SCALE = 2.1F;

    public SufferingRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 1.5F;
    }

    @Override
    public void render(SufferingEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the front of the model (+X) looks where it looks
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.ZP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, SufferingEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, SufferingEntity.ANIM_NAMES[index], seconds, light, overlay, Collections.emptySet());
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(SufferingEntity entity) {
        return TEXTURE;
    }
}
