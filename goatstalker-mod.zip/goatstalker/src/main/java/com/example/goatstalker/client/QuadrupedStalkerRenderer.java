package com.example.goatstalker.client;

import java.util.Collections;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.QuadrupedStalkerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The quadruped stalker: the player's Blockbench model (StalkerSpotted.geo.json), 3.9 blocks in Blockbench, x1.33. */
public class QuadrupedStalkerRenderer extends EntityRenderer<QuadrupedStalkerEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/quadruped_stalker.png");
    public static final SkeletalModel MODEL = new SkeletalModel("quadruped/model.json", "quadruped/animations.json");
    /** As big as the bipedal stalker (about 5.2 blocks with the head up). */
    public static final float MODEL_SCALE = 1.33F;

    public QuadrupedStalkerRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.8F;
    }

    @Override
    public void render(QuadrupedStalkerEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the model's front (+X) looks where it looks
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.XP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, QuadrupedStalkerEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        if (entity.isTrampling()) {
            seconds *= 1.6F; // stamping fast on the player
        }
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, QuadrupedStalkerEntity.ANIM_NAMES[index], seconds, light, overlay, Collections.emptySet());
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(QuadrupedStalkerEntity entity) {
        return TEXTURE;
    }
}
