package com.example.goatstalker;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A player held by the bipedal stalker cannot jump off its hands. */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class MobEvents {
    /** Near Sufferings every monster of the mod kills a player with one hit. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof Player) || event.getEntity().level().isClientSide) {
            return;
        }
        Entity attacker = event.getSource().getEntity();
        if (attacker != null && !(attacker instanceof SufferingEntity) && SufferingEntity.isGoatMonster(attacker)
                && SufferingEntity.empowers(attacker)) {
            event.setAmount(100000.0F);
        }
    }

    @SubscribeEvent
    public static void onMount(EntityMountEvent event) {
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof BipedalMobEntity mob
                && mob.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof TormentorEntity t
                && t.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof EvilDarkTormentorEntity t
                && t.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
        if (event.isDismounting() && event.getEntityBeingMounted() instanceof BipedalStalker2Entity b
                && b.isHolding(event.getEntityMounting())) {
            event.setCanceled(true);
        }
    }
}
