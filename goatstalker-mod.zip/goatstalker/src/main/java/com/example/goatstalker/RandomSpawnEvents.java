package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Bipedal Stalker 2 and Sufferings come on their own every so often (see the config), in the normal world:
 * Bipedal Stalker 2 on average every 35 minutes (30-45 blocks away, stays ~8 minutes),
 * Sufferings on average every 60 minutes (70-90 blocks away, it is a giant; stays ~10 minutes unless it hunts).
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class RandomSpawnEvents {
    private static final Map<UUID, Long> NEXT_B2 = new HashMap<>();
    private static final Map<UUID, Long> NEXT_SUF = new HashMap<>();
    private static final Map<UUID, Long> NEXT_QUAD = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 11) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        try {
            tryOne(p, level, NEXT_B2, StalkerConfig.BIPEDAL2_ENABLED, StalkerConfig.BIPEDAL2_MINUTES,
                    ModEntities.BIPEDAL_2::get, BipedalStalker2Entity.class, 30.0D, 45.0D, 9600);
            tryOne(p, level, NEXT_SUF, StalkerConfig.SUFFERING_ENABLED, StalkerConfig.SUFFERING_MINUTES,
                    ModEntities.SUFFERING::get, SufferingEntity.class, 70.0D, 90.0D, 12000);
            tryOne(p, level, NEXT_QUAD, StalkerConfig.QUADRUPED_ENABLED, StalkerConfig.QUADRUPED_MINUTES,
                    ModEntities.QUADRUPED::get, QuadrupedStalkerEntity.class, 30.0D, 45.0D, 9600);
        } catch (Exception ignored) {
            // never crash the game because of a spawn
        }
    }

    private static <T extends Mob> void tryOne(ServerPlayer p, ServerLevel level, Map<UUID, Long> next,
                                               ForgeConfigSpec.BooleanValue enabled, ForgeConfigSpec.IntValue minutes,
                                               Supplier<EntityType<T>> type, Class<T> cls, double minD, double maxD, int life) {
        if (!enabled.get()) {
            return;
        }
        long now = level.getGameTime();
        long avg = minutes.get() * 1200L;
        Long when = next.get(p.getUUID());
        if (when == null) {
            next.put(p.getUUID(), now + avg / 2 + level.random.nextInt((int) Math.max(1L, avg)));
            return;
        }
        if (now < when) {
            return;
        }
        boolean ok = level.getEntitiesOfClass(cls, p.getBoundingBox().inflate(200.0D)).isEmpty()
                && spawn(p, level, type.get(), minD, maxD, life);
        next.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1L, avg)) : 1200L));
    }

    private static <T extends Mob> boolean spawn(ServerPlayer p, ServerLevel level, EntityType<T> type,
                                                 double minD, double maxD, int life) {
        for (int i = 0; i < 20; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0D;
            double d = minD + level.random.nextDouble() * (maxD - minD);
            double x = p.getX() + Math.cos(a) * d;
            double z = p.getZ() + Math.sin(a) * d;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
            BlockPos below = BlockPos.containing(x, y - 1, z);
            if (Math.abs(y - p.getY()) > 24.0D || !level.getFluidState(below).isEmpty()
                    || level.getBlockState(below).isAir()) {
                continue;
            }
            T m = type.create(level);
            if (m == null) {
                return false;
            }
            Vec3 at = new Vec3(x, y, z);
            m.moveTo(at.x, at.y, at.z, level.random.nextFloat() * 360.0F, 0.0F);
            if (!level.noCollision(m)) {
                continue;
            }
            if (m instanceof BipedalStalker2Entity b) {
                b.setTimedLife(life);
            } else if (m instanceof SufferingEntity s) {
                s.setTimedLife(life);
            } else if (m instanceof QuadrupedStalkerEntity q) {
                q.setTimedLife(life);
            }
            m.setPersistenceRequired(); // the timer removes it, not the vanilla despawning
            level.addFreshEntity(m);
            return true;
        }
        return false;
    }
}
