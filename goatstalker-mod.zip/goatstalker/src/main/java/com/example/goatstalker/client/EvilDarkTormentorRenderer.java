package com.example.goatstalker.client;

import java.util.Set;

import com.example.goatstalker.EvilDarkTormentorEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.TormentorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The Evil Dark Tormentor: the Tormentor's model and animations, dark texture, 3 blocks taller (8.4 blocks). */
public class EvilDarkTormentorRenderer extends EntityRenderer<EvilDarkTormentorEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/evil_dark_tormentor.png");
    /** 6.8 blocks in Blockbench -> 8.4 blocks. */
    public static final float MODEL_SCALE = 1.235F;
    private static final Set<String> HIDDEN = Set.of("crawl_head");
    /**
     * Its own model: the same bones (and so the same animations) as the Tormentor, but every part stands exactly
     * where it is in the player's picture, at the picture's own size (assets/goatstalker/evil/model.json).
     */
    public static final SkeletalModel MODEL = new SkeletalModel("evil/model.json", "tormentor/animations.json");

    public EvilDarkTormentorRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(EvilDarkTormentorEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        if (entity.isTorn()) {
            return; // its two halves are drawn as separate pieces
        }
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F));
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.ZP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, TormentorEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, TormentorEntity.ANIM_NAMES[index], seconds, light, overlay, HIDDEN);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(EvilDarkTormentorEntity entity) {
        return TEXTURE;
    }
}
