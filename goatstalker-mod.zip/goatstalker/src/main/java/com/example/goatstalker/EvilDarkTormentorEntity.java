package com.example.goatstalker;

import java.util.List;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The Evil Dark Tormentor: the StalkerGoat model, 3 blocks taller than the Tormentor (8.4 blocks), dark texture.
 * It breaks every block but bedrock, and one grab is enough: the player bursts.
 * Fights (it leads them all):
 * - a bipedal stalker alone: grabs its head and tears it off;
 * - a Tormentor alone: rams it, tears off its arms, breaks its horns, tears off its legs and eats its head;
 * - a Goat Stalker alone: takes it in both hands and tears it in two;
 * - a Tormentor and a bipedal together: tears off the bipedal's arm, throws the Tormentor (by the leg) at it, they
 *   fall, and it stamps them both to death;
 * - a Tormentor, a bipedal and a Goat Stalker together: it knocks the bipedal down and screams at it, the goat jumps
 *   on its neck and chokes it, the bipedal takes its arms, the Tormentor its legs, and they tear it in two. Then the
 *   three look at each other, scream, and go their ways: they never fight each other again.
 */
public class EvilDarkTormentorEntity extends Monster {
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(EvilDarkTormentorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(EvilDarkTormentorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_TORN =
            SynchedEntityData.defineId(EvilDarkTormentorEntity.class, EntityDataSerializers.BOOLEAN);

    private static final int NONE = 0, BIP = 1, TOR = 2, GOAT = 3, TWO = 4, LOSE = 5;

    private int clientAnimStart;
    private int forcedAnim = -1;
    private int cooldown = 60;
    private int lifetime = -1;
    private int stuckTicks = 0;

    // catching a player
    private UUID capturedId;
    private int captureTick;
    private boolean releasing;

    // the scripted fights
    private int scene = NONE;
    private int phase = 0; // 0 = coming together, 1 = the fight
    private int t = 0;
    private UUID bipId, torId, goatId;
    private Vec3 throwFrom, throwTo;

    public EvilDarkTormentorEntity(EntityType<? extends EvilDarkTormentorEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 50.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, TormentorEntity.A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_TORN, false);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    /** Torn in two: the pieces are separate entities, this one is no longer drawn. */
    public boolean isTorn() {
        return this.entityData.get(DATA_TORN);
    }

    /**
     * True if an Evil Dark Tormentor (alive, not torn apart) is within this many blocks: then the bipedal stalker,
     * the Tormentor and the Goat Stalker do not fight each other - it is their common enemy.
     */
    public static boolean isNear(Entity e, double range) {
        return !e.level().getEntitiesOfClass(EvilDarkTormentorEntity.class, e.getBoundingBox().inflate(range),
                x -> x.isAlive() && !x.isTorn()).isEmpty();
    }

    public void setTimedLife(int ticks) {
        this.lifetime = ticks;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    @Override
    public float maxUpStep() {
        return 1.5F;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.capturedId != null || (this.scene != NONE && this.phase == 1) || isTorn();
    }

    private boolean busy() {
        return this.capturedId != null || this.scene != NONE;
    }

    public boolean isHolding(Entity e) {
        return !this.releasing && this.capturedId != null && this.capturedId.equals(e.getUUID());
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return !isTorn() && super.hurt(source, amount);
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true) {
            @Override
            public boolean canUse() {
                return !EvilDarkTormentorEntity.this.busy() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !EvilDarkTormentorEntity.this.busy() && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 25.0D;
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (target instanceof ServerPlayer sp && distSqr <= getAttackReachSqr(target)) {
                    EvilDarkTormentorEntity.this.startCapture(sp);
                }
            }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 48.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false,
                e -> this.scene == NONE && e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        if (this.lifetime >= 0 && this.tickCount > this.lifetime && !busy()) {
            discard();
            return;
        }
        if (this.capturedId != null) {
            tickCapture(sl);
        } else if (this.scene != NONE) {
            tickScene(sl);
        } else if (this.tickCount % 10 == 0) {
            breakThrough(sl);
            lookForEnemies(sl);
        }
        updateAnim();
    }

    private void updateAnim() {
        int anim;
        if (this.forcedAnim >= 0) {
            anim = this.forcedAnim;
        } else {
            Vec3 v = getDeltaMovement();
            anim = (v.x * v.x + v.z * v.z > 0.002D) ? TormentorEntity.A_RUN : TormentorEntity.A_IDLE;
        }
        if (anim != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void anim(int a) {
        this.forcedAnim = a;
        if (a >= 0) {
            this.entityData.set(DATA_ANIM, a);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private void face(Entity e) {
        faceTo(e.getX() - getX(), e.getZ() - getZ());
    }

    private Vec3 forward() {
        double r = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(r), 0.0D, Math.cos(r));
    }

    private void scream(ServerLevel sl) {
        anim(TormentorEntity.A_SCREAM);
        sl.playSound(null, getX(), getY() + 7.0D, getZ(), ModSounds.SCREAM.get(), SoundSource.HOSTILE, 6.0F, 0.5F);
        sl.playSound(null, getX(), getY() + 7.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 6.0F, 0.6F);
    }

    private void crack(ServerLevel sl, Vec3 at) {
        sl.playSound(null, at.x, at.y, at.z, ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.8F);
    }

    // ------------------------------ breaking everything but bedrock ------------------------------
    private void breakThrough(ServerLevel sl) {
        LivingEntity target = getTarget();
        if (target == null || !sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            this.stuckTicks = 0;
            return;
        }
        Vec3 v = getDeltaMovement();
        boolean still = v.x * v.x + v.z * v.z < 0.0009D;
        boolean noPath = getNavigation().isDone() || getNavigation().getPath() == null || !getNavigation().getPath().canReach();
        this.stuckTicks = distanceToSqr(target) > 16.0D && (this.horizontalCollision || still || noPath) ? this.stuckTicks + 10 : 0;
        if (this.stuckTicks < 20) {
            return;
        }
        double dx = target.getX() - getX();
        double dz = target.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5D) {
            return;
        }
        dx /= len;
        dz /= len;
        int broken = 0;
        for (double step = 0.8D; step <= 2.8D && broken < 24; step += 0.6D) {
            for (int side = -1; side <= 1; side++) {
                for (int h = 0; h <= 8 && broken < 24; h++) {
                    BlockPos pos = BlockPos.containing(getX() + dx * step - dz * side * 0.6D, getY() + h + 0.1D,
                            getZ() + dz * step + dx * side * 0.6D);
                    BlockState st = sl.getBlockState(pos);
                    if (st.isAir() || st.is(Blocks.BEDROCK) || !st.getFluidState().isEmpty()
                            || st.getDestroySpeed(sl, pos) < 0.0F) {
                        continue; // everything but bedrock (and other unbreakable blocks)
                    }
                    sl.destroyBlock(pos, true, this);
                    broken++;
                }
            }
        }
        if (broken > 0) {
            sl.playSound(null, getX(), getY() + 2.0D, getZ(), SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.HOSTILE, 2.5F, 0.4F);
            getNavigation().stop();
            this.stuckTicks = 0;
        }
    }

    // ------------------------------ the player: one grab and he bursts ------------------------------
    private void startCapture(ServerPlayer sp) {
        if (this.capturedId != null || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            return;
        }
        this.capturedId = sp.getUUID();
        this.captureTick = 0;
        getNavigation().stop();
        sp.startRiding(this, true);
        anim(TormentorEntity.A_GRAB);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) {
            return;
        }
        Vec3 f = forward();
        callback.accept(passenger, getX() + f.x * 1.8D, getY() + 6.6D, getZ() + f.z * 1.8D);
    }

    private void tickCapture(ServerLevel sl) {
        ServerPlayer sp = this.capturedId == null ? null : sl.getServer().getPlayerList().getPlayer(this.capturedId);
        this.captureTick++;
        getNavigation().stop();
        if (sp == null || !sp.isAlive()) {
            if (this.captureTick > 30) {
                endCapture(sl);
            }
            return;
        }
        if (sp.getVehicle() != this) {
            sp.startRiding(this, true);
        }
        if (this.captureTick == 24) { // he bursts in its hand
            Vec3 at = sp.position().add(0.0D, 1.0D, 0.0D);
            this.releasing = true;
            sp.stopRiding();
            this.releasing = false;
            Blood.spray(sl, at.x, at.y, at.z, 160, 1.0D);
            sl.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 3, 0.4D, 0.4D, 0.4D, 0.0D);
            sl.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0F, 1.2F);
            crack(sl, at);
            sp.kill();
        }
    }

    private void endCapture(ServerLevel sl) {
        this.capturedId = null;
        this.forcedAnim = -1;
        scream(sl);
        this.forcedAnim = -1;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (this.capturedId != null && this.level() instanceof ServerLevel sl) {
            ServerPlayer sp = sl.getServer().getPlayerList().getPlayer(this.capturedId);
            if (sp != null && sp.getVehicle() == this) {
                this.releasing = true;
                sp.stopRiding();
                this.releasing = false;
            }
        }
        super.remove(reason);
    }

    // ------------------------------ choosing a fight ------------------------------
    private <T extends LivingEntity> T nearest(List<T> list) {
        T best = null;
        for (T e : list) {
            if (best == null || distanceToSqr(e) < distanceToSqr(best)) {
                best = e;
            }
        }
        return best;
    }

    private void lookForEnemies(ServerLevel sl) {
        if (this.cooldown > 0 || isTorn()) {
            return;
        }
        AABB box = getBoundingBox().inflate(40.0D);
        BipedalMobEntity b = nearest(sl.getEntitiesOfClass(BipedalMobEntity.class, box,
                e -> e.isAlive() && e.canStartTormentorFight() && hasLineOfSight(e)));
        TormentorEntity tor = nearest(sl.getEntitiesOfClass(TormentorEntity.class, box,
                e -> e.canBeDirected() && hasLineOfSight(e)));
        StalkerEntity g = nearest(sl.getEntitiesOfClass(StalkerEntity.class, box,
                e -> e.canBeDirected() && hasLineOfSight(e)));
        if (b != null && tor != null && g != null) {
            begin(LOSE, b, tor, g);
        } else if (b != null && tor != null) {
            begin(TWO, b, tor, null);
        } else {
            LivingEntity n = nearest(java.util.Arrays.asList(new LivingEntity[] {b, tor, g}).stream()
                    .filter(java.util.Objects::nonNull).toList());
            if (n == b && b != null) {
                begin(BIP, b, null, null);
            } else if (n == tor && tor != null) {
                begin(TOR, null, tor, null);
            } else if (n == g && g != null) {
                begin(GOAT, null, null, g);
            }
        }
    }

    private void begin(int s, BipedalMobEntity b, TormentorEntity tor, StalkerEntity g) {
        this.scene = s;
        this.phase = 0;
        this.t = 0;
        this.bipId = b == null ? null : b.getUUID();
        this.torId = tor == null ? null : tor.getUUID();
        this.goatId = g == null ? null : g.getUUID();
        setTarget(null);
        getNavigation().stop();
        if (b != null) {
            b.joinDirected(this);
        }
        if (tor != null) {
            tor.joinDirected(this);
        }
        if (g != null) {
            g.joinDirected();
        }
    }

    public void startTestFight(BipedalMobEntity b, TormentorEntity tor, StalkerEntity g) {
        int s = b != null && tor != null && g != null ? LOSE : b != null && tor != null ? TWO
                : b != null ? BIP : tor != null ? TOR : GOAT;
        begin(s, b, tor, g);
    }

    private BipedalMobEntity bip(ServerLevel sl) {
        return this.bipId != null && sl.getEntity(this.bipId) instanceof BipedalMobEntity b ? b : null;
    }

    private TormentorEntity tor(ServerLevel sl) {
        return this.torId != null && sl.getEntity(this.torId) instanceof TormentorEntity e ? e : null;
    }

    private StalkerEntity goat(ServerLevel sl) {
        return this.goatId != null && sl.getEntity(this.goatId) instanceof StalkerEntity e ? e : null;
    }

    /** Ends the fight; whoever is still standing is free again. */
    private void endScene(ServerLevel sl) {
        BipedalMobEntity b = bip(sl);
        if (b != null && !b.isDeadByTormentor()) {
            b.leaveTormentorFight();
        }
        TormentorEntity tor = tor(sl);
        if (tor != null && !tor.isCorpse()) {
            tor.leaveDirected();
        }
        StalkerEntity g = goat(sl);
        if (g != null) {
            g.releaseDirected();
        }
        this.scene = NONE;
        this.phase = 0;
        this.forcedAnim = -1;
        this.cooldown = 200;
        this.bipId = this.torId = this.goatId = null;
        if (!isTorn()) {
            Player p = sl.getNearestPlayer(this, 64.0D);
            if (p != null && !p.isCreative() && !p.isSpectator()) {
                setTarget(p);
            }
        }
    }

    /** Moves a creature that is held by the fight (it cannot walk by itself) toward a spot. */
    private static boolean walk(LivingEntity e, Vec3 to, double speed) {
        double dx = to.x - e.getX();
        double dz = to.z - e.getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 0.3D) {
            return true;
        }
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        e.setYRot(yaw);
        e.yBodyRot = yaw;
        e.yHeadRot = yaw;
        double s = Math.min(speed, d);
        e.move(MoverType.SELF, new Vec3(dx / d * s, -0.08D, dz / d * s));
        return false;
    }

    private Vec3 slot(double ahead, double side) {
        Vec3 f = forward();
        return position().add(f.x * ahead - f.z * side, 0.0D, f.z * ahead + f.x * side);
    }

    // ------------------------------ the fights ------------------------------
    private void tickScene(ServerLevel sl) {
        BipedalMobEntity b = bip(sl);
        TormentorEntity tor = tor(sl);
        StalkerEntity g = goat(sl);
        boolean missing = (this.bipId != null && b == null) || (this.torId != null && tor == null)
                || (this.goatId != null && g == null && this.scene != GOAT);
        if (missing && this.phase == 0) {
            endScene(sl);
            return;
        }
        this.t++;
        switch (this.scene) {
            case BIP -> sceneBip(sl, b);
            case TOR -> sceneTor(sl, tor);
            case GOAT -> sceneGoat(sl, g);
            case TWO -> sceneTwo(sl, b, tor);
            case LOSE -> sceneLose(sl, b, tor, g);
            default -> endScene(sl);
        }
    }

    /** Walks up to the victim (phase 0); true once close enough (the fight starts, the time is reset). */
    private boolean approach(LivingEntity victim, double reach, double speed) {
        if (this.phase == 1) {
            return true;
        }
        if (victim == null || this.t > 600) {
            return false;
        }
        face(victim);
        if (this.t % 10 == 1) {
            getNavigation().moveTo(victim, speed);
        }
        if (getNavigation().isDone() && distanceTo(victim) > reach) { // no path for something this tall: straight on
            walk(this, victim.position(), 0.2D * speed);
        }
        if (distanceTo(victim) <= reach) {
            this.phase = 1;
            this.t = 0;
            getNavigation().stop();
            return true;
        }
        return false;
    }

    // a bipedal stalker alone: grabs its head and tears it off
    private void sceneBip(ServerLevel sl, BipedalMobEntity b) {
        if (this.phase == 0) {
            if (this.t > 600) {
                endScene(sl);
                return;
            }
            if (b != null) {
                b.faceTowards(this);
                if (this.t == 1) {
                    b.fightRoar();
                }
            }
            approach(b, 5.5D, 1.4D);
            return;
        }
        if (b == null) {
            endScene(sl);
            return;
        }
        if (this.t < 60) {
            face(b);
            b.faceTowards(this);
        }
        Vec3 head = b.position().add(0.0D, 4.6D, 0.0D);
        switch (this.t) {
            case 1 -> anim(TormentorEntity.A_GRAB);
            case 12 -> b.fightAnim(BipedalMobEntity.A_ROAR, true);
            case 34 -> {
                b.losePart(BipedalMobEntity.LOST_HEAD);
                crack(sl, head);
                Blood.spray(sl, head.x, head.y, head.z, 90, 0.7D);
                b.fallDown();
                b.dieByTormentor();
                anim(TormentorEntity.A_HOLD);
            }
            case 60 -> scream(sl);
            case 110 -> endScene(sl);
            default -> { }
        }
    }

    // a Tormentor alone: rams it, arms, horns, legs, eats the head
    private void sceneTor(ServerLevel sl, TormentorEntity tor) {
        if (this.phase == 0) {
            if (tor == null || this.t > 600) {
                endScene(sl);
                return;
            }
            tor.faceTowards(this);
            if (this.t == 1) {
                tor.screamNow();
            }
            if (approach(tor, 4.0D, 2.2D)) { // it runs into it
                sl.playSound(null, tor.getX(), tor.getY() + 2.0D, tor.getZ(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 2.0F, 0.5F);
                sl.playSound(null, tor.getX(), tor.getY(), tor.getZ(), SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 3.0F, 0.6F);
                tor.dAnim(TormentorEntity.A_HURT);
                Vec3 push = tor.position().subtract(position()).normalize();
                tor.move(MoverType.SELF, new Vec3(push.x * 1.2D, 0.0D, push.z * 1.2D));
            }
            return;
        }
        if (tor == null) {
            endScene(sl);
            return;
        }
        face(tor);
        Vec3 c = tor.position().add(0.0D, tor.isFallen() ? 0.6D : 3.0D, 0.0D);
        switch (this.t) {
            case 15 -> anim(TormentorEntity.A_GRAB);
            case 35 -> { // left arm
                tor.losePart(TormentorEntity.LOST_ARM_L);
                crack(sl, c);
                Blood.spray(sl, c.x, c.y + 1.0D, c.z, 50, 0.5D);
                tor.dAnim(TormentorEntity.A_HURT);
            }
            case 55 -> anim(TormentorEntity.A_GRAB);
            case 75 -> { // right arm
                tor.losePart(TormentorEntity.LOST_ARM_R);
                crack(sl, c);
                Blood.spray(sl, c.x, c.y + 1.0D, c.z, 50, 0.5D);
                tor.dAnim(TormentorEntity.A_HURT);
            }
            case 95 -> anim(TormentorEntity.A_HOLD);
            case 108 -> { // the horns
                tor.breakHorns();
                Vec3 h = tor.position().add(0.0D, 5.6D, 0.0D);
                crack(sl, h);
                Blood.spray(sl, h.x, h.y, h.z, 30, 0.4D);
            }
            case 128 -> anim(TormentorEntity.A_GRAB);
            case 145 -> { // the legs: it falls
                tor.losePart(TormentorEntity.LOST_LEGS);
                tor.fallDown();
                crack(sl, tor.position());
                Blood.spray(sl, tor.getX(), tor.getY() + 0.5D, tor.getZ(), 60, 0.6D);
                sl.playSound(null, tor.getX(), tor.getY(), tor.getZ(), SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 3.0F, 0.6F);
            }
            case 170 -> anim(TormentorEntity.A_BEAT); // bends down over it
            case 240 -> { // the head is eaten
                tor.losePart(TormentorEntity.LOST_HEAD);
                tor.dieCorpse();
            }
            case 262 -> scream(sl);
            case 310 -> endScene(sl);
            default -> { }
        }
        if (this.t > 175 && this.t < 240 && this.t % 8 == 0) { // eating
            Vec3 head = tor.position().add(forward().scale(-4.0D)).add(0.0D, 0.5D, 0.0D);
            sl.playSound(null, head.x, head.y, head.z, SoundEvents.GENERIC_EAT, SoundSource.HOSTILE, 2.5F, 0.5F);
            Blood.spray(sl, head.x, head.y, head.z, 14, 0.4D);
        }
    }

    // a Goat Stalker alone: both hands, torn in two
    private void sceneGoat(ServerLevel sl, StalkerEntity g) {
        if (this.phase == 0) {
            if (g == null || this.t > 600) {
                endScene(sl);
                return;
            }
            g.faceTowards(this);
            approach(g, 4.5D, 1.5D);
            if (this.phase == 1) {
                g.setNoGravity(true);
            }
            return;
        }
        if (this.t <= 50 && g != null) { // held up in front of it, in both hands
            face(g);
            Vec3 f = forward();
            double shake = 0.08D;
            g.setPos(getX() + f.x * 2.2D + (this.random.nextDouble() - 0.5D) * shake, getY() + Math.min(4.5D, this.t * 0.2D),
                    getZ() + f.z * 2.2D + (this.random.nextDouble() - 0.5D) * shake);
            g.setDeltaMovement(Vec3.ZERO);
            g.faceTowards(this);
        }
        switch (this.t) {
            case 1 -> {
                anim(TormentorEntity.A_GRAB);
                if (g != null) {
                    g.dAnim(TormentorEntity.A_HURT);
                }
            }
            case 30 -> {
                if (g != null) {
                    g.dAnim(TormentorEntity.A_HOLD);
                }
            }
            case 50 -> {
                if (g != null) {
                    Vec3 f = forward();
                    BipedalMobEntity.tearInTwo(sl, g.position(), f.x, f.z, BipedalEntity.GOAT_TOP, BipedalEntity.GOAT_BOTTOM, 0.3D);
                    g.discard();
                }
            }
            case 70 -> scream(sl);
            case 110 -> endScene(sl);
            default -> { }
        }
    }

    // a Tormentor and a bipedal: arm off, the Tormentor thrown at the bipedal, both stamped to death
    private void sceneTwo(ServerLevel sl, BipedalMobEntity b, TormentorEntity tor) {
        if (b == null || tor == null) {
            endScene(sl);
            return;
        }
        if (this.phase == 0) { // they attack it: both come running
            face(b);
            if (this.t == 1) {
                b.fightRoar();
                tor.screamNow();
            }
            if (this.t > 20) {
                b.fightAnim(BipedalMobEntity.A_RUN, false);
                tor.dAnim(TormentorEntity.A_RUN);
            }
            boolean bi = walk(b, slot(4.5D, 1.2D), 0.35D);
            boolean ti = walk(tor, slot(4.2D, -3.5D), 0.35D);
            if ((bi && ti) || this.t > 160) {
                this.phase = 1;
                this.t = 0;
                b.fightAnim(BipedalMobEntity.A_ROAR, true);
                tor.dAnim(TormentorEntity.A_IDLE);
            }
            return;
        }
        if (this.t < 30) {
            face(b);
            b.faceTowards(this);
            tor.faceTowards(this);
        }
        switch (this.t) {
            case 1 -> anim(TormentorEntity.A_GRAB);
            case 22 -> { // the bipedal's arm
                b.losePart(BipedalMobEntity.LOST_ARM);
                Vec3 sh = b.position().add(0.0D, 4.0D, 0.0D);
                crack(sl, sh);
                Blood.spray(sl, sh.x, sh.y, sh.z, 50, 0.5D);
                b.fightAnim(BipedalMobEntity.A_ROAR, true);
            }
            case 40 -> { // turns to the Tormentor, takes it by the leg
                face(tor);
                anim(TormentorEntity.A_GRAB);
                tor.dAnim(TormentorEntity.A_HURT);
                this.throwFrom = tor.position();
            }
            case 70 -> { // and throws it at the bipedal
                face(b);
                anim(TormentorEntity.A_KICK);
                this.throwTo = b.position().add(forward().scale(0.8D));
            }
            case 82 -> { // they crash and fall
                sl.playSound(null, b.getX(), b.getY() + 1.0D, b.getZ(), SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 4.0F, 0.5F);
                sl.playSound(null, b.getX(), b.getY() + 1.0D, b.getZ(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 2.0F, 0.6F);
                b.fallDown();
                b.fightAnim(BipedalMobEntity.A_IDLE, false);
                tor.fallDown();
                tor.dAnim(TormentorEntity.A_IDLE);
            }
            case 90 -> anim(TormentorEntity.A_RUN);
            case 115, 140, 165, 190 -> anim(TormentorEntity.A_STOMP);
            case 128, 153, 178, 203 -> { // stamps
                Vec3 at = b.position().add(tor.position()).scale(0.5D);
                sl.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 3.0F, 0.5F);
                crack(sl, at);
                Blood.spray(sl, b.getX(), b.getY() + 0.5D, b.getZ(), 30, 0.7D);
                Blood.spray(sl, tor.getX(), tor.getY() + 0.5D, tor.getZ(), 30, 0.7D);
                if (this.t == 203) {
                    b.dieByTormentor();
                    tor.dieCorpse();
                }
            }
            case 225 -> scream(sl);
            case 270 -> endScene(sl);
            default -> { }
        }
        if (this.t > 40 && this.t < 70) { // swung by the leg, high up
            double k = (this.t - 40) / 30.0D;
            Vec3 f = forward();
            tor.setPos(getX() + f.x * 2.5D, getY() + 1.5D + k * 3.0D, getZ() + f.z * 2.5D);
            tor.setDeltaMovement(Vec3.ZERO);
        } else if (this.t >= 70 && this.t < 82 && this.throwFrom != null && this.throwTo != null) { // flying
            double k = (this.t - 70) / 12.0D;
            Vec3 f = forward();
            Vec3 from = new Vec3(getX() + f.x * 2.5D, getY() + 4.5D, getZ() + f.z * 2.5D);
            tor.setPos(from.x + (this.throwTo.x - from.x) * k, from.y + (this.throwTo.y - from.y) * k,
                    from.z + (this.throwTo.z - from.z) * k);
            tor.setDeltaMovement(Vec3.ZERO);
        } else if (this.t > 90 && this.t < 115) { // goes to stand over them
            Vec3 mid = b.position().add(tor.position()).scale(0.5D);
            Vec3 me = position();
            Vec3 to = mid.subtract(me);
            double len = to.horizontalDistance();
            if (len > 2.5D) {
                faceTo(to.x, to.z);
                move(MoverType.SELF, new Vec3(to.x / len * 0.25D, -0.08D, to.z / len * 0.25D));
            }
        }
    }

    // a Tormentor, a bipedal and a Goat Stalker together: they tear it in two
    private void sceneLose(ServerLevel sl, BipedalMobEntity b, TormentorEntity tor, StalkerEntity g) {
        if (b == null || tor == null || g == null) {
            if (!isTorn()) {
                endScene(sl);
            }
            return;
        }
        if (this.phase == 0) { // the three of them come at it
            face(b);
            if (this.t == 1) {
                b.fightRoar();
                tor.screamNow();
                sl.playSound(null, g.getX(), g.getY() + 2.0D, g.getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 3.0F, 1.3F);
            }
            if (this.t > 20) {
                b.fightAnim(BipedalMobEntity.A_RUN, false);
                tor.dAnim(TormentorEntity.A_RUN);
                g.dAnim(TormentorEntity.A_RUN);
            }
            boolean bi = walk(b, slot(4.5D, 0.0D), 0.35D);
            boolean ti = walk(tor, slot(2.5D, -4.0D), 0.35D);
            boolean gi = walk(g, slot(3.0D, 3.5D), 0.4D);
            if ((bi && ti && gi) || this.t > 160) {
                this.phase = 1;
                this.t = 0;
                b.fightAnim(BipedalMobEntity.A_IDLE, false);
                tor.dAnim(TormentorEntity.A_IDLE);
                g.dAnim(TormentorEntity.A_IDLE);
            }
            return;
        }
        Vec3 f = forward();
        Vec3 neck = position().add(f.x * 0.6D, 6.4D, f.z * 0.6D);
        switch (this.t) {
            case 1 -> { // knocks the bipedal down
                face(b);
                anim(TormentorEntity.A_KICK);
            }
            case 9 -> {
                sl.playSound(null, b.getX(), b.getY() + 2.0D, b.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 4.0F, 0.4F);
                sl.playSound(null, b.getX(), b.getY(), b.getZ(), SoundEvents.GENERIC_BIG_FALL, SoundSource.HOSTILE, 4.0F, 0.5F);
                b.fallDown();
            }
            case 24 -> scream(sl); // and screams at it
            case 50 -> { // the goat jumps on its neck
                g.setNoGravity(true);
                g.dAnim(TormentorEntity.A_GRAB);
                sl.playSound(null, g.getX(), g.getY() + 2.0D, g.getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 3.0F, 1.4F);
            }
            case 80 -> { // the bipedal gets up
                b.standUp();
                b.fightAnim(BipedalMobEntity.A_RUN, false);
                tor.dAnim(TormentorEntity.A_RUN);
            }
            case 105 -> { // takes its arms / the Tormentor its legs
                b.fightAnim(BipedalMobEntity.A_LIFT, false);
                tor.dAnim(TormentorEntity.A_GRAB);
            }
            case 170 -> { // torn in two: the top half to the bipedal, the legs to the Tormentor
                Vec3 dir = b.position().subtract(tor.position());
                double len = Math.max(0.01D, dir.horizontalDistance());
                BipedalMobEntity.tearInTwo(sl, position(), dir.x / len, dir.z / len, BipedalEntity.EDT_TOP,
                        BipedalEntity.EDT_BOTTOM, 0.35D);
                this.entityData.set(DATA_TORN, true);
                setInvisible(true);
                this.noPhysics = true;
                setNoGravity(true);
                g.setNoGravity(false);
                g.setPos(getX() + f.x * 1.5D, getY(), getZ() + f.z * 1.5D);
                g.dAnim(TormentorEntity.A_IDLE);
                b.fightAnim(BipedalMobEntity.A_IDLE, false);
                tor.dAnim(TormentorEntity.A_IDLE);
            }
            case 195 -> { // the three look at each other...
                Vec3 mid = b.position().add(tor.position()).add(g.position()).scale(1.0D / 3.0D);
                for (LivingEntity e : new LivingEntity[] {b, tor, g}) {
                    faceAt(e, mid);
                }
            }
            case 205 -> { // ...and scream
                b.fightRoar();
                tor.screamNow();
                g.dAnim(TormentorEntity.A_SCREAM);
                sl.playSound(null, g.getX(), g.getY() + 2.0D, g.getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 1.2F);
            }
            case 250 -> { // and go their ways, never to fight each other again
                Vec3 mid = b.position().add(tor.position()).add(g.position()).scale(1.0D / 3.0D);
                b.addTag(TormentorEntity.PEACE);
                tor.addTag(TormentorEntity.PEACE);
                g.addTag(TormentorEntity.PEACE);
                endScene(sl);
                for (net.minecraft.world.entity.Mob m : new net.minecraft.world.entity.Mob[] {b, tor, g}) {
                    Vec3 away = m.position().subtract(mid);
                    double l = Math.max(0.01D, away.horizontalDistance());
                    Vec3 to = m.position().add(away.x / l * 30.0D, 0.0D, away.z / l * 30.0D);
                    m.getNavigation().moveTo(to.x, to.y, to.z, 1.0D);
                }
                discard();
            }
            default -> { }
        }
        if (this.t > 50 && this.t < 170) { // the goat on its neck, choking it; it tries to throw the goat off
            g.setPos(neck.x, neck.y - 1.4D, neck.z);
            g.setDeltaMovement(Vec3.ZERO);
            g.faceTowards(this);
            if (this.t % 12 == 0) {
                anim(TormentorEntity.A_HURT);
                setYRot(getYRot() + (this.random.nextFloat() - 0.5F) * 50.0F);
                this.yBodyRot = getYRot();
                sl.playSound(null, neck.x, neck.y, neck.z, SoundEvents.PLAYER_HURT_DROWN, SoundSource.HOSTILE, 3.0F, 0.4F);
            }
        }
        if (this.t > 80 && this.t < 105) { // the bipedal and the Tormentor take hold of it
            walk(b, slot(0.0D, 3.2D), 0.3D);
            walk(tor, slot(0.0D, -3.2D), 0.3D);
        }
        if (this.t >= 105 && this.t < 170) { // and pull, each to its side
            b.faceTowards(this);
            tor.faceTowards(this);
            Vec3 bo = b.position().subtract(position());
            Vec3 to = tor.position().subtract(position());
            if (this.t % 4 == 0) {
                b.move(MoverType.SELF, new Vec3(bo.x / Math.max(0.1D, bo.horizontalDistance()) * 0.04D, -0.08D,
                        bo.z / Math.max(0.1D, bo.horizontalDistance()) * 0.04D));
                tor.move(MoverType.SELF, new Vec3(to.x / Math.max(0.1D, to.horizontalDistance()) * 0.04D, -0.08D,
                        to.z / Math.max(0.1D, to.horizontalDistance()) * 0.04D));
            }
            if (this.t % 15 == 0) {
                crack(sl, position().add(0.0D, 4.0D, 0.0D));
            }
        }
    }

    private static void faceAt(LivingEntity e, Vec3 at) {
        float yaw = (float) (Mth.atan2(-(at.x - e.getX()), at.z - e.getZ()) * 57.29577951308232D);
        e.setYRot(yaw);
        e.yBodyRot = yaw;
        e.yHeadRot = yaw;
    }

    // ------------------------------ misc ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 9, getY() - 1, getZ() - 9, getX() + 9, getY() + 12, getZ() + 9);
    }
}
