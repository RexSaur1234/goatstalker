package com.example.goatstalker;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GoatStalkerMod.MODID);

    public static final RegistryObject<Item> STALKER_EGG = ITEMS.register("goat_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.STALKER, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> EXIT_ITEM = ITEMS.register("nullspace_exit",
            () -> new BlockItem(ModBlocks.EXIT.get(), new Item.Properties()));

    public static final RegistryObject<Item> GLITCH_GRASS_ITEM = ITEMS.register("glitch_grass",
            () -> new BlockItem(ModBlocks.GLITCH_GRASS.get(), new Item.Properties()));

    public static final RegistryObject<Item> GLITCH_STONE_ITEM = ITEMS.register("glitch_stone",
            () -> new BlockItem(ModBlocks.GLITCH_STONE.get(), new Item.Properties()));

    public static final RegistryObject<Item> BIPEDAL_EGG = ITEMS.register("bipedal_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BIPEDAL_MOB, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> TV_ITEM = ITEMS.register("tv",
            () -> new BlockItem(ModBlocks.TV.get(), new Item.Properties()));

    public static final RegistryObject<Item> CASSETTE = ITEMS.register("cassette",
            () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> EVIL_TORMENTOR_EGG = ITEMS.register("evil_dark_tormentor_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.EVIL_TORMENTOR, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> BIPEDAL_2_EGG = ITEMS.register("bipedal_stalker_2_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BIPEDAL_2, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> SUFFERING_EGG = ITEMS.register("sufferings_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SUFFERING, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> ANGUISH_EGG = ITEMS.register("anguish_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ANGUISH, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> QUADRUPED_EGG = ITEMS.register("quadruped_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.QUADRUPED, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> TORMENTOR_EGG = ITEMS.register("tormentor_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TORMENTOR, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));
}
