package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Events under the ground.
 * 1. Dig straight down and fall into your own shaft (8+ blocks deep): 30 % that the goat head looks down from the top
 *    of the shaft for 10 seconds.
 * 2. Look up out of a deep shaft: 20 % that the little stalker's face watches you, then vanishes.
 *    Both heads say "hi" when you first see them. If you dig up toward a head (or get close), it vanishes and takes
 *    half of your health.
 * 3. Rarely, in a mine, the creature leans out from behind a corner (works like the one behind a tree).
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class MineEvents {
    /** The shaft the player is digging: its column, where it started (the rim) and how deep it is. */
    private static final class Dig {
        int x;
        int z;
        int rimY;
        int depth;
        long lastTick;
        boolean goatRolled;
        boolean faceRolled;
    }

    private static final Map<UUID, Dig> DIG = new HashMap<>();
    private static final Map<UUID, Long> NEXT_CAVE = new HashMap<>();

    // ------------------------------ digging ------------------------------
    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (!StalkerConfig.SHAFT_ENABLED.get() || !(event.getPlayer() instanceof ServerPlayer p)) {
            return;
        }
        if (!(p.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD
                || p.isCreative() || p.isSpectator()) {
            return;
        }
        BlockPos pos = event.getPos();
        long now = level.getGameTime();

        // digging up toward a head: it vanishes and takes half of the health
        if (pos.getY() > p.getBlockY() + 1 && Math.abs(pos.getX() - p.getBlockX()) <= 1
                && Math.abs(pos.getZ() - p.getBlockZ()) <= 1) {
            BipedalEntity head = findShaftHead(p, level);
            if (head != null) {
                head.strike(p);
            }
            return;
        }
        // digging straight down, under his own feet
        if (pos.getX() == p.getBlockX() && pos.getZ() == p.getBlockZ() && pos.getY() < p.getBlockY()) {
            UUID id = p.getUUID();
            Dig d = DIG.get(id);
            if (d == null || d.x != pos.getX() || d.z != pos.getZ() || now - d.lastTick > 600L) {
                d = new Dig();
                d.x = pos.getX();
                d.z = pos.getZ();
                d.rimY = p.getBlockY();
                DIG.put(id, d);
            }
            d.depth++;
            d.lastTick = now;
            if (d.depth >= 8 && !d.goatRolled) {
                d.goatRolled = true;
                if (level.random.nextInt(100) < StalkerConfig.SHAFT_GOAT_PERCENT.get()) {
                    spawnShaftHead(p, level, d.x, d.z, d.rimY, BipedalEntity.SHAFT_GOAT);
                }
            }
        }
    }

    private static BipedalEntity findShaftHead(ServerPlayer p, ServerLevel level) {
        for (BipedalEntity e : level.getEntitiesOfClass(BipedalEntity.class,
                p.getBoundingBox().inflate(80.0D, 250.0D, 80.0D))) {
            if (e.isShaftHeadOf(p)) {
                return e;
            }
        }
        return null;
    }

    /** The head sits at the mouth of the shaft: the centre of the picture is at the rim, the lower half sinks into the hole. */
    private static boolean spawnShaftHead(ServerPlayer p, ServerLevel level, int x, int z, int rimY, int kind) {
        if (findShaftHead(p, level) != null) {
            return false;
        }
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return false;
        }
        double h = kind == BipedalEntity.SHAFT_GOAT ? 2.6D : 1.4D;
        e.setup(kind, p.getUUID());
        e.setPos(x + 0.5D, rimY - 0.5D + h / 2.0D, z + 0.5D);
        level.addFreshEntity(e);
        return true;
    }

    // ------------------------------ timers ------------------------------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        if (!(event.player instanceof ServerPlayer p) || p.tickCount % 10 != 0) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        UUID id = p.getUUID();
        long now = level.getGameTime();

        // the little stalker's face: you dug a deep shaft, stopped and looked up
        Dig d = DIG.get(id);
        if (d != null) {
            boolean inColumn = Math.abs(p.getX() - (d.x + 0.5D)) < 1.5D && Math.abs(p.getZ() - (d.z + 0.5D)) < 1.5D;
            if (!inColumn || now - d.lastTick > 6000L) {
                DIG.remove(id);
            } else if (StalkerConfig.SHAFT_ENABLED.get() && !d.faceRolled && d.depth >= 8
                    && p.getY() < d.rimY - 7 && p.getXRot() < -50.0F && now - d.lastTick > 20L) {
                d.faceRolled = true;
                if (level.random.nextInt(100) < StalkerConfig.SHAFT_FACE_PERCENT.get()) {
                    spawnShaftHead(p, level, d.x, d.z, d.rimY, BipedalEntity.SHAFT_FACE);
                }
            }
        }

        // the creature behind a corner of a mine
        if (StalkerConfig.CAVE_ENABLED.get() && isUnderground(p, level)) {
            long next = NEXT_CAVE.computeIfAbsent(id, k -> now + StalkerConfig.CAVE_MINUTES.get() * 600L);
            if (now >= next) {
                boolean ok = spawnCave(p, level);
                long avg = StalkerConfig.CAVE_MINUTES.get() * 1200L;
                NEXT_CAVE.put(id, now + (ok ? avg / 2 + level.random.nextInt((int) Math.min(Integer.MAX_VALUE, avg)) : 600L));
            }
        }
    }

    private static boolean isUnderground(ServerPlayer p, ServerLevel level) {
        return !level.canSeeSky(p.blockPosition())
                && p.getY() < level.getHeight(Heightmap.Types.WORLD_SURFACE, p.getBlockX(), p.getBlockZ()) - 8;
    }

    // ------------------------------ the corner of a mine ------------------------------
    private static boolean solid(ServerLevel level, BlockPos pos) {
        return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    private static boolean free3(ServerLevel level, BlockPos pos) {
        return !solid(level, pos) && !solid(level, pos.above()) && !solid(level, pos.above(2));
    }

    /**
     * Finds a wall corner ahead (a 2-high solid pillar with free space behind it and to its right) and puts the creature
     * behind it so that it leans out on the player's right, exactly like the creature behind a tree.
     */
    public static boolean spawnCave(ServerPlayer p, ServerLevel level) {
        RandomSource r = level.random;
        Vec3 eye = p.getEyePosition();
        int y = Mth.floor(p.getY());
        for (int i = 0; i < 60; i++) {
            double dist = 6 + r.nextInt(11);
            double a = Math.toRadians(p.getYRot() + (r.nextDouble() - 0.5D) * 80.0D);
            int x = Mth.floor(p.getX() - Math.sin(a) * dist);
            int z = Mth.floor(p.getZ() + Math.cos(a) * dist);
            BlockPos pillar = new BlockPos(x, y, z);
            if (!solid(level, pillar) || !solid(level, pillar.above())) {
                continue;
            }
            double dx = x + 0.5D - p.getX();
            double dz = z + 0.5D - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 3.0D) {
                continue;
            }
            dx /= len;
            dz /= len;
            double rx = -dz; // to the player's right
            double rz = dx;
            BlockPos behind = BlockPos.containing(x + 0.5D + dx, y, z + 0.5D + dz);
            BlockPos side = BlockPos.containing(x + 0.5D + rx, y, z + 0.5D + rz);
            if (!free3(level, behind) || !free3(level, side) || !solid(level, behind.below())) {
                continue;
            }
            Vec3 aim = new Vec3(x + 0.5D - dx * 0.7D, y + 1.0D, z + 0.5D - dz * 0.7D);
            if (level.clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p))
                    .getType() != HitResult.Type.MISS) {
                continue; // the pillar must be in sight
            }
            BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
            if (e == null) {
                return false;
            }
            e.setup(BipedalEntity.CAVE, p.getUUID());
            e.setSlide(dz, -dx); // to the player's left: it slides behind the corner and goes away
            double sideOffset = 0.5D + BipedalEntity.CAVE_W / 2.0D;
            e.setPos(x + 0.5D + dx * 0.9D + rx * sideOffset, y, z + 0.5D + dz * 0.9D + rz * sideOffset);
            level.addFreshEntity(e);
            return true;
        }
        return false;
    }

    // ------------------------------ commands (tests) ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var goat = Commands.literal("shaftGoat").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawnShaftHead(p, p.serverLevel(), p.getBlockX(), p.getBlockZ(), p.getBlockY() + 12, BipedalEntity.SHAFT_GOAT)) {
                ctx.getSource().sendFailure(Component.literal("A head is already watching you."));
                return 0;
            }
            return 1;
        });
        var face = Commands.literal("shaftFace").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawnShaftHead(p, p.serverLevel(), p.getBlockX(), p.getBlockZ(), p.getBlockY() + 12, BipedalEntity.SHAFT_FACE)) {
                ctx.getSource().sendFailure(Component.literal("A head is already watching you."));
                return 0;
            }
            return 1;
        });
        var corner = Commands.literal("caveCorner").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawnCave(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No wall corner found in front of you. Go into a mine and face a corner."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(goat).then(face).then(corner));
    }
}
