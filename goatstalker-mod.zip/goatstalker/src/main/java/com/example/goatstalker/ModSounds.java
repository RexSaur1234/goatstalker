package com.example.goatstalker;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, GoatStalkerMod.MODID);

    public static final RegistryObject<SoundEvent> SCREAM = SOUNDS.register("stalker_scream",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "stalker_scream")));

    // Music files are stereo with a huge attenuation distance (see sounds.json), so they are heard on the whole map.
    /** Island: music while the creature chases you (2 min 15 s, repeated by the mod). */
    public static final RegistryObject<SoundEvent> ISLAND_CHASE = SOUNDS.register("island_chase",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "island_chase")));

    /** Village: music that starts when you arrive. */
    public static final RegistryObject<SoundEvent> VILLAGE_ARRIVE = SOUNDS.register("village_arrive",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "village_arrive")));

    /** Village: the chase song (53 s, repeated by the mod). */
    public static final RegistryObject<SoundEvent> VILLAGE_CHASE = SOUNDS.register("village_chase",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "village_chase")));

    // Short voice lines of the Onlooker and the roar of the bipedal stalker (mono, heard around the source).
    public static final int GOAT_HEY_TICKS = 17;    // goat_v2_hey, 0.83 s
    public static final int LOOK_THIS_TICKS = 28;   // "look this", 1.36 s
    public static final int HEY_VOICE_TICKS = 34;   // "hey", 1.70 s

    public static final RegistryObject<SoundEvent> GOAT_HEY = SOUNDS.register("goat_hey",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "goat_hey")));
    public static final RegistryObject<SoundEvent> LOOK_THIS = SOUNDS.register("look_this",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "look_this")));
    public static final RegistryObject<SoundEvent> HEY_VOICE = SOUNDS.register("hey_voice",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "hey_voice")));
    public static final RegistryObject<SoundEvent> STALKER_ROAR = SOUNDS.register("stalker_roar",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "stalker_roar")));

    /** The scream of the bipedal stalker at the moment it holds the player in its hands (1.85 s). */
    public static final RegistryObject<SoundEvent> SCREAM_ALT = SOUNDS.register("stalker_scream_alt",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "stalker_scream_alt")));

    /** The "hi" when you see a head peeking over the top of your shaft (1.59 s). */
    public static final RegistryObject<SoundEvent> PEEK_HI = SOUNDS.register("peek_hi",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "peek_hi")));

    /** Double-door event: door music (7.74 s), the Tormentor "R" track (16.09 s) and the voice from the window (1.57 s). */
    public static final int DOOR_MUSIC_TICKS = 155;
    public static final int TORMENTOR_R_TICKS = 322;
    public static final int WINDOW_VOICE_TICKS = 32;
    public static final RegistryObject<SoundEvent> DOOR_MUSIC = SOUNDS.register("door_music",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "door_music")));
    public static final RegistryObject<SoundEvent> TORMENTOR_R = SOUNDS.register("tormentor_r",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "tormentor_r")));
    public static final RegistryObject<SoundEvent> GOAT_WINDOW_VOICE = SOUNDS.register("goat_window_voice",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "goat_window_voice")));

    /** "I know you're here" - heard every 20 minutes (2.93 s). */
    public static final RegistryObject<SoundEvent> I_KNOW_YOURE_HERE = SOUNDS.register("i_know_youre_here",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "i_know_youre_here")));
}
