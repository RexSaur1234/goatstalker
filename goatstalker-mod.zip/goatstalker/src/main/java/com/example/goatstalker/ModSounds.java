package com.example.goatstalker;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, GoatStalkerMod.MODID);

    public static final RegistryObject<SoundEvent> SCREAM = SOUNDS.register("stalker_scream",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "stalker_scream")));

    // Music files are stereo with a huge attenuation distance (see sounds.json), so they are heard on the whole map.
    /** Island: music while the creature chases you (2 min 15 s, repeated by the mod). */
    public static final RegistryObject<SoundEvent> ISLAND_CHASE = SOUNDS.register("island_chase",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "island_chase")));

    /** Village: music that starts when you arrive. */
    public static final RegistryObject<SoundEvent> VILLAGE_ARRIVE = SOUNDS.register("village_arrive",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "village_arrive")));

    /** Village: the chase song (53 s, repeated by the mod). */
    public static final RegistryObject<SoundEvent> VILLAGE_CHASE = SOUNDS.register("village_chase",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "village_chase")));
}
