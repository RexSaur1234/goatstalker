package com.example.goatstalker;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * Press C (key "Crawl") to crawl like in a one-block gap; press again to stand up. The key lives on the client, the
 * client tells the server, and both put the player into the crawling pose every tick (vanilla calls it SWIMMING).
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class Crawl {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GoatStalkerMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    /** Server: players who are crawling. */
    private static final Set<UUID> CRAWLING = new HashSet<>();
    /** Client: is the local player crawling (set by the key handler on the client). */
    public static boolean clientCrawling = false;
    /** Client: the local player's id (so the other players seen on this client are left alone). */
    public static UUID clientPlayerId = null;

    public static void register() {
        CHANNEL.registerMessage(0, Toggle.class, Toggle::encode, Toggle::decode, Toggle::handle);
    }

    /** Client to server: "I crawl now" or "I stand up". */
    public record Toggle(boolean crawl) {
        public static void encode(Toggle msg, FriendlyByteBuf buf) {
            buf.writeBoolean(msg.crawl());
        }

        public static Toggle decode(FriendlyByteBuf buf) {
            return new Toggle(buf.readBoolean());
        }

        public static void handle(Toggle msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer p = ctx.get().getSender();
                if (p != null) {
                    if (msg.crawl()) {
                        CRAWLING.add(p.getUUID());
                    } else {
                        CRAWLING.remove(p.getUUID());
                    }
                }
            });
            ctx.get().setPacketHandled(true);
        }
    }

    private static boolean canCrawl(Player p) {
        return !p.isPassenger() && !p.isSleeping() && !p.getAbilities().flying && !p.isFallFlying()
                && !p.isInWater() && !p.isSpectator();
    }

    /** At the end of the player's tick (after vanilla has chosen the pose) the pose is set to crawling. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player p = event.player;
        boolean crawl;
        if (p.level().isClientSide) {
            crawl = clientCrawling && p.getUUID().equals(clientPlayerId);
        } else {
            crawl = CRAWLING.contains(p.getUUID());
        }
        if (crawl && canCrawl(p) && p.getPose() != Pose.SWIMMING) {
            p.setPose(Pose.SWIMMING);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        CRAWLING.remove(event.getEntity().getUUID());
    }
}
