package com.example.goatstalker.client;

import org.lwjgl.glfw.GLFW;

import com.example.goatstalker.AnguishNet;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.social.SocialInteractionsScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Anguish: the keys A, F, P, D, T, R come one after another. Only the current one is shown, and the player has
 * 3 seconds to press it; then the next one appears. Miss one and he dies.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID, value = Dist.CLIENT)
public class AnguishKeys {
    private static final int[] KEYS = {GLFW.GLFW_KEY_A, GLFW.GLFW_KEY_F, GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_D,
            GLFW.GLFW_KEY_T, GLFW.GLFW_KEY_R};
    private static final String[] NAMES = {"A", "F", "P", "D", "T", "R"};
    private static final int PER_KEY = 60; // 3 seconds for each key

    private static boolean active = false;
    private static int index = 0;
    private static int left = 0;
    private static boolean wasDown = true;
    private static int runTicks = 0;
    private static int okTicks = 0;

    public static void start(int ticks) {
        active = ticks > 0;
        index = 0;
        left = PER_KEY;
        wasDown = true; // a key already held down does not count: it must be pressed now
        okTicks = 0;
        if (!active) {
            runTicks = 0;
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        if (runTicks > 0) {
            runTicks--;
        }
        if (okTicks > 0) {
            okTicks--;
        }
        Minecraft mc = Minecraft.getInstance();
        if (!active || mc.player == null) {
            return;
        }
        boolean down = InputConstants.isKeyDown(mc.getWindow().getWindow(), KEYS[index]);
        if (down && !wasDown) { // pressed now
            index++;
            left = PER_KEY;
            okTicks = 6;
            if (index >= KEYS.length) {
                active = false;
                runTicks = 50;
                AnguishNet.CHANNEL.sendToServer(new AnguishNet.Pressed(true));
                if (mc.screen instanceof ChatScreen || mc.screen instanceof SocialInteractionsScreen) {
                    mc.setScreen(null); // T and P open screens: close them so the player can run
                }
                return;
            }
            wasDown = InputConstants.isKeyDown(mc.getWindow().getWindow(), KEYS[index]);
            return;
        }
        wasDown = down;
        if (--left <= 0) { // too late
            active = false;
            AnguishNet.CHANNEL.sendToServer(new AnguishNet.Pressed(false));
        }
    }

    /** Drawn above everything (registered in ClientSetup). */
    public static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (runTicks > 0 && !active) {
            String s = "БЕГИ!";
            g.pose().pushPose();
            g.pose().translate(width / 2.0F + (float) ((Math.random() - 0.5D) * 6.0D), height / 3.0F, 0.0F);
            g.pose().scale(3.0F, 3.0F, 1.0F);
            g.drawString(mc.font, s, -mc.font.width(s) / 2, 0, 0xFF3030, true);
            g.pose().popPose();
            return;
        }
        if (!active) {
            return;
        }
        String title = "НАЖМИ:";
        float shake = (float) ((Math.random() - 0.5D) * 4.0D);
        g.pose().pushPose();
        g.pose().translate(width / 2.0F + shake, height / 2.0F - 62.0F, 0.0F);
        g.pose().scale(2.0F, 2.0F, 1.0F);
        g.drawString(mc.font, title, -mc.font.width(title) / 2, 0, 0xFF2020, true);
        g.pose().popPose();
        // only the current key, big
        int box = 40;
        int x = width / 2 - box / 2;
        int y = height / 2 - 34;
        g.fill(x - 3, y - 3, x + box + 3, y + box + 3, 0xFF000000);
        g.fill(x, y, x + box, y + box, okTicks > 0 ? 0xFF2E9E3A : 0xFF8A1010);
        g.pose().pushPose();
        g.pose().translate(x + box / 2.0F, y + 9.0F, 0.0F);
        g.pose().scale(3.0F, 3.0F, 1.0F);
        g.drawString(mc.font, NAMES[index], -mc.font.width(NAMES[index]) / 2, 0, 0xFFFFFF, true);
        g.pose().popPose();
        // its 3 seconds
        int barW = 120;
        int bx = width / 2 - barW / 2;
        int by = y + box + 10;
        g.fill(bx, by, bx + barW, by + 6, 0xFF300000);
        g.fill(bx, by, bx + barW * left / PER_KEY, by + 6, 0xFFFF3030);
        String count = (index + 1) + " / " + KEYS.length;
        g.drawString(mc.font, count, width / 2 - mc.font.width(count) / 2, by + 12, 0xDDDDDD, true);
    }
}
