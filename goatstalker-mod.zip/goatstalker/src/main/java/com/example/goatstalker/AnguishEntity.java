package com.example.goatstalker;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Anguish: a red horned creature (about 4.5 blocks), a little faster than a running player; it breaks wood. It is rare.
 * - When a player looks at it, its head opens; its voice is heard once and its music begins. The player must press
 *   A F P D T R all together within a few seconds, or he dies. If he makes it, it is stunned for a moment and then
 *   it chases him; every time it reaches him he must press the keys again. When the music ends it is gone.
 * - When another monster of the mod (not Sufferings) sees it, its head opens and that monster kills itself.
 */
public class AnguishEntity extends Monster {
    public static final int A_IDLE = 0;
    public static final int A_OPEN = 1;
    public static final int A_RUN = 2;
    public static final String[] ANIM_NAMES = {"idle", "open", "run"};

    private static final ResourceLocation MUSIC_ID = new ResourceLocation(GoatStalkerMod.MODID, "lc_music");
    private static final int MUSIC_TICKS = 1190;     // lc_music.ogg, 59.5 s: the length of the whole chase
    /** The keys come one after another, 3 seconds for each: at most 6 x 3 s (the client says when one was missed). */
    private static final int FIRST_QTE_TICKS = 6 * 60 + 20;
    private static final int QTE_TICKS = 6 * 60 + 20;
    private static final int STUN_TICKS = 50;        // after the keys: a head start for the player

    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(AnguishEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(AnguishEntity.class, EntityDataSerializers.INT);
    private int clientAnimStart;

    /** 0 = wandering, 1 = the keys (it stands, its head open), 2 = stunned, 3 = chasing, 4 = killing, 5 = leaving. */
    private int phase = 0;
    private int phaseTick = 0;
    private UUID preyId;
    private int huntTicks = 0;
    private int qteTicks = 0;
    private int openTicks = 0;
    private int stuckTicks = 0;

    public AnguishEntity(EntityType<? extends AnguishEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.37D)   // a little faster than a sprinting player
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.ATTACK_DAMAGE, 1000.0D);
    }

    /** Rare: only one in a large area, and only one spawn attempt in four is allowed. */
    public static boolean checkAnguishSpawn(EntityType<AnguishEntity> type, ServerLevelAccessor level, MobSpawnType reason,
                                            BlockPos pos, RandomSource random) {
        if (!Monster.checkMonsterSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) {
            return true;
        }
        return random.nextInt(4) == 0
                && level.getEntitiesOfClass(AnguishEntity.class, new AABB(pos).inflate(192.0D)).isEmpty();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    private void anim(int a) {
        if (a != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, a);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.5D) {
            @Override
            public boolean canUse() {
                return AnguishEntity.this.phase == 0 && super.canUse();
            }
        });
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.phase == 1 || this.phase == 2 || this.phase == 4 || this.phase == 5;
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return this.phase == 0 && super.removeWhenFarAway(dist);
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 3, getY() - 1, getZ() - 3, getX() + 3, getY() + 6, getZ() + 3);
    }

    // ------------------------------ tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        this.phaseTick++;
        if (this.phase != 0) {
            this.huntTicks++;
            if (this.huntTicks >= MUSIC_TICKS && this.phase != 4 && this.phase != 5) {
                leave(sl); // the music is over: it is gone
            }
        }
        if (this.tickCount % 20 == 7) {
            lookAtMonsters(sl);
        }
        switch (this.phase) {
            case 0 -> tickWander(sl);
            case 1 -> tickKeys(sl);
            case 2 -> tickStun(sl);
            case 3 -> tickChase(sl);
            case 4 -> tickKill(sl);
            case 5 -> {
                if (this.phaseTick > 30) {
                    discard();
                }
            }
            default -> this.phase = 0;
        }
        if (this.phase == 0) {
            if (this.openTicks > 0) {
                this.openTicks--;
                anim(A_OPEN);
            } else {
                Vec3 v = getDeltaMovement();
                anim(v.x * v.x + v.z * v.z > 0.002D ? A_RUN : A_IDLE);
            }
        }
    }

    private void setPhase(int p) {
        this.phase = p;
        this.phaseTick = 0;
    }

    private ServerPlayer prey(ServerLevel sl) {
        return this.preyId == null ? null : sl.getServer().getPlayerList().getPlayer(this.preyId);
    }

    private void faceTo(LivingEntity e) {
        float yaw = (float) (Mth.atan2(-(e.getX() - getX()), e.getZ() - getZ()) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    /** Is the player looking right at it? */
    private boolean looksAtMe(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 to = new Vec3(getX(), getY() + 3.6D, getZ()).subtract(eye);
        double d = to.length();
        if (d > 48.0D || d < 0.1D) {
            return false;
        }
        return p.getViewVector(1.0F).dot(to.scale(1.0D / d)) > 0.93D && p.hasLineOfSight(this);
    }

    private void tickWander(ServerLevel sl) {
        if (this.tickCount % 4 != 0) {
            return;
        }
        for (ServerPlayer p : sl.players()) {
            if (p.isAlive() && !p.isCreative() && !p.isSpectator() && looksAtMe(p)) {
                this.preyId = p.getUUID();
                this.huntTicks = 0;
                // its voice once, and at the same time its music
                sl.playSound(null, getX(), getY() + 3.5D, getZ(), ModSounds.LC_VOICE.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
                sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.LC_MUSIC.get(), SoundSource.MASTER, 1.0F, 1.0F);
                startKeys(sl, p, FIRST_QTE_TICKS);
                return;
            }
        }
    }

    /** The player must press A F P D T R together. */
    private void startKeys(ServerLevel sl, ServerPlayer p, int ticks) {
        setPhase(1);
        this.qteTicks = ticks;
        getNavigation().stop();
        setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
        anim(A_OPEN);
        AnguishNet.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new AnguishNet.Keys(ticks));
    }

    private void tickKeys(ServerLevel sl) {
        ServerPlayer p = prey(sl);
        if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator()) {
            leave(sl);
            return;
        }
        faceTo(p);
        getNavigation().stop();
        if (this.phaseTick >= this.qteTicks + 4) { // too late
            setPhase(4);
        }
    }

    /** The client says the keys were pressed in time. */
    public static void keysPressed(ServerPlayer p, boolean success) {
        for (AnguishEntity a : p.serverLevel().getEntitiesOfClass(AnguishEntity.class, p.getBoundingBox().inflate(80.0D),
                e -> e.phase == 1 && p.getUUID().equals(e.preyId))) {
            if (!success) {
                a.setPhase(4); // a key was missed: it kills him
            } else if (a.phaseTick <= a.qteTicks + 4) {
                a.setPhase(2);
                a.anim(A_IDLE); // its head closes: it is stunned
                p.serverLevel().playSound(null, a.getX(), a.getY() + 3.0D, a.getZ(), ModSounds.BONE_CRACKED.get(),
                        SoundSource.HOSTILE, 2.0F, 1.3F);
            }
        }
    }

    private void tickStun(ServerLevel sl) {
        getNavigation().stop();
        if (this.phaseTick >= STUN_TICKS) {
            setPhase(3);
            anim(A_RUN);
        }
    }

    private void tickChase(ServerLevel sl) {
        ServerPlayer p = prey(sl);
        if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator() || p.level() != this.level()) {
            leave(sl);
            return;
        }
        anim(A_RUN);
        if (this.phaseTick % 5 == 1) {
            getNavigation().moveTo(p, 1.0D);
        }
        getLookControl().setLookAt(p);
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        if (dx * dx + dz * dz < 6.0D && Math.abs(p.getY() - getY()) < 3.0D) {
            startKeys(sl, p, QTE_TICKS); // it has caught up: the keys again
            return;
        }
        if (this.phaseTick % 10 == 0) {
            breakWood(sl, p);
        }
    }

    private void tickKill(ServerLevel sl) {
        ServerPlayer p = prey(sl);
        anim(A_OPEN);
        if (p != null) {
            faceTo(p);
        }
        if (this.phaseTick == 1) {
            if (p != null) {
                AnguishNet.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new AnguishNet.Keys(0));
            }
            if (p != null && p.isAlive()) {
                // it lunges at him
                Vec3 to = p.position().subtract(position());
                if (to.lengthSqr() > 4.0D) {
                    Vec3 n = to.normalize();
                    setPos(p.getX() - n.x * 1.5D, p.getY(), p.getZ() - n.z * 1.5D);
                }
                sl.playSound(null, getX(), getY() + 3.0D, getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 0.8F);
                sl.playSound(null, p.getX(), p.getY() + 1.0D, p.getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.9F);
                Blood.spray(sl, p.getX(), p.getY() + 1.2D, p.getZ(), 80, 0.6D);
                p.invulnerableTime = 0;
                p.hurt(this.level().damageSources().mobAttack(this), 100000.0F);
                if (p.isAlive()) {
                    p.kill();
                }
            }
        }
        if (this.phaseTick >= 50) {
            leave(sl);
        }
    }

    /** It goes away (puff of smoke) and its music stops. */
    private void leave(ServerLevel sl) {
        stopMusic(sl);
        if (this.phase != 5) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 2.0D, getZ(), 40, 0.5D, 1.5D, 0.5D, 0.02D);
        }
        setPhase(5);
        getNavigation().stop();
    }

    private void stopMusic(ServerLevel sl) {
        ServerPlayer p = prey(sl);
        if (p != null) {
            p.connection.send(new ClientboundStopSoundPacket(MUSIC_ID, SoundSource.MASTER));
            AnguishNet.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new AnguishNet.Keys(0));
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (this.level() instanceof ServerLevel sl && this.phase != 0) {
            stopMusic(sl);
        }
        super.remove(reason);
    }

    // ------------------------------ breaking wood ------------------------------
    private void breakWood(ServerLevel sl, LivingEntity t) {
        if (!sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return;
        }
        Vec3 v = getDeltaMovement();
        boolean still = v.x * v.x + v.z * v.z < 0.0009D;
        this.stuckTicks = (this.horizontalCollision || still) && distanceToSqr(t) > 6.0D ? this.stuckTicks + 10 : 0;
        if (this.stuckTicks < 20) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5D) {
            return;
        }
        dx /= len;
        dz /= len;
        int broken = 0;
        for (double step = 0.7D; step <= 2.2D && broken < 8; step += 0.5D) {
            for (int h = 0; h <= 4 && broken < 8; h++) {
                BlockPos pos = BlockPos.containing(getX() + dx * step, getY() + h + 0.1D, getZ() + dz * step);
                BlockState st = sl.getBlockState(pos);
                if (st.isAir() || st.getDestroySpeed(sl, pos) < 0.0F
                        || !(st.is(BlockTags.MINEABLE_WITH_AXE) || st.is(BlockTags.PLANKS) || st.is(BlockTags.LOGS))) {
                    continue;
                }
                sl.destroyBlock(pos, true, this);
                broken++;
            }
        }
        if (broken > 0) {
            sl.playSound(null, getX(), getY() + 2.0D, getZ(), SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.HOSTILE, 1.4F, 0.8F);
            getNavigation().stop();
            this.stuckTicks = 0;
        }
    }

    // ------------------------------ the other monsters ------------------------------
    /** Monsters of the mod that kill themselves (ticks since they saw it). */
    private static final Map<UUID, Integer> DOOMED = new HashMap<>();

    private void lookAtMonsters(ServerLevel sl) {
        List<Mob> mobs = sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(32.0D),
                m -> m.isAlive() && SufferingEntity.isGoatMonster(m) && !DOOMED.containsKey(m.getUUID()) && m.hasLineOfSight(this));
        for (Mob m : mobs) {
            DOOMED.put(m.getUUID(), 0);
            if (this.phase == 0) {
                this.openTicks = 80; // its head opens
                anim(A_OPEN);
            }
            sl.playSound(null, getX(), getY() + 3.5D, getZ(), ModSounds.LC_VOICE.get(), SoundSource.HOSTILE, 3.0F, 1.0F);
        }
    }

    @Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
    public static class Events {
        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent event) {
            if (event.phase != TickEvent.Phase.END || DOOMED.isEmpty()) {
                return;
            }
            Iterator<Map.Entry<UUID, Integer>> it = DOOMED.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Integer> en = it.next();
                Mob m = null;
                for (ServerLevel sl : event.getServer().getAllLevels()) {
                    if (sl.getEntity(en.getKey()) instanceof Mob found) {
                        m = found;
                        break;
                    }
                }
                if (m == null || !m.isAlive()) {
                    it.remove();
                    continue;
                }
                int t = en.getValue() + 1;
                en.setValue(t);
                try {
                    tortureSelf(m, t);
                } catch (Exception ignored) {
                    m.discard();
                    it.remove();
                }
            }
        }

        /** It stops, claws at itself and bleeds until it dies. */
        private static void tortureSelf(Mob m, int t) {
            ServerLevel sl = (ServerLevel) m.level();
            m.setTarget(null);
            m.getNavigation().stop();
            m.setDeltaMovement(0.0D, m.getDeltaMovement().y, 0.0D);
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 9, true, false));
            if (t % 12 == 0) {
                m.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                Blood.spray(sl, m.getX(), m.getY() + m.getBbHeight() * 0.6D, m.getZ(), 25, 0.4D);
                if (t % 24 == 0) {
                    sl.playSound(null, m.getX(), m.getY() + 2.0D, m.getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE,
                            2.0F, 0.8F + sl.random.nextFloat() * 0.4F);
                }
                m.invulnerableTime = 0;
                m.hurt(sl.damageSources().generic(), Math.max(6.0F, m.getMaxHealth() * 0.09F));
            }
            if (t >= 240 && m.isAlive()) { // whatever it is, it does not last longer than 12 seconds
                Blood.spray(sl, m.getX(), m.getY() + m.getBbHeight() * 0.5D, m.getZ(), 80, 0.7D);
                m.kill();
                if (m.isAlive()) {
                    m.discard();
                }
            }
        }
    }

    // ------------------------------ sounds ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }
}
