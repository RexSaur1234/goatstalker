package com.example.goatstalker.client;

import java.util.Set;

import com.example.goatstalker.BipedalStalker2Entity;
import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.TormentorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Bipedal Stalker 2: its own flat-part model made from the player's picture (assets/goatstalker/bipedal2/model.json),
 * the same bones as the Tormentor, so it uses the Tormentor's animations. About 6.2 blocks tall.
 */
public class BipedalStalker2Renderer extends EntityRenderer<BipedalStalker2Entity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_stalker_2.png");
    public static final SkeletalModel MODEL = new SkeletalModel("bipedal2/model.json", "tormentor/animations.json");
    /** The model is 108.8 pixels (6.8 blocks) tall in its own units: 0.912 makes it 6.2 blocks. */
    public static final float MODEL_SCALE = 0.912F;
    private static final Set<String> HIDDEN = Set.of("crawl_head");
    private static final Set<String> HIDDEN_HEADLESS = Set.of("crawl_head", "head", "neck");

    public BipedalStalker2Renderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(BipedalStalker2Entity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the front of the model (+X) looks where it looks
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.ZP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, TormentorEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, TormentorEntity.ANIM_NAMES[index], seconds, light, overlay,
                entity.isHeadless() ? HIDDEN_HEADLESS : HIDDEN);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(BipedalStalker2Entity entity) {
        return TEXTURE;
    }
}
