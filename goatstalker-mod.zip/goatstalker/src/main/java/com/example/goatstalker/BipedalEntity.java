package com.example.goatstalker;

import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * Scripted appearances of the tall creature and its helpers (not a real mob, it cannot be hit):
 * TREE       - leans out from behind a tree, hits for half of your health if you come close, then slides left.
 * ROOF       - head and shoulders on a roof in Nullspace 2, then it sinks down and the chase starts.
 * RUNNER     - the 3D model (StalkerRun) runs after the player; when it catches him it roars and he is sent back.
 * ONLOOKER   - stands in the distance and calls "hey"; when you look at it: "look this", then "hey", and it vanishes.
 * GOAT_TOP / GOAT_BOTTOM - the two halves of the Goat Stalker torn apart by the bipedal stalker.
 */
public class BipedalEntity extends Entity {
    public static final int TREE = 0;
    public static final int ROOF = 1;
    public static final int RUNNER = 2;
    public static final int ONLOOKER = 3;
    public static final int GOAT_TOP = 4;
    public static final int GOAT_BOTTOM = 5;

    /** Size of the tree picture in blocks (height * ratio 0.4521); the renderer and the spawn code both use it. */
    public static final float TREE_H = 4.2F;
    public static final float TREE_W = 1.899F;

    /** Runner animations: 0 = terror (running), 1 = grito (roaring, when it has caught you). */
    public static final int ANIM_RUN = 0;
    public static final int ANIM_SCREAM = 1;

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);

    private UUID target;
    private double slideX;
    private double slideZ;
    private boolean hit;
    private int caughtAt = -1;
    // goat halves
    private double vx;
    private double vy;
    private double vz;
    private boolean landed;
    // onlooker
    private int olPhase = 0;
    private int olNext = 0;
    private int olTimer = 0;

    public BipedalEntity(EntityType<? extends BipedalEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_KIND, TREE);
        this.entityData.define(DATA_ANIM, ANIM_RUN);
        this.entityData.define(DATA_ANIM_START, 0);
    }

    public int getKind() {
        return this.entityData.get(DATA_KIND);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getAnimStart() {
        return this.entityData.get(DATA_ANIM_START);
    }

    public void setup(int kind, UUID target) {
        this.entityData.set(DATA_KIND, kind);
        this.target = target;
    }

    public void setSlide(double x, double z) {
        this.slideX = x;
        this.slideZ = z;
    }

    public void setVelocity(double x, double y, double z) {
        this.vx = x;
        this.vy = y;
        this.vz = z;
    }

    /** The pictures and the model are bigger than the entity box, so make the culling box big enough. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 5, getY() - 1, getZ() - 5, getX() + 5, getY() + 9, getZ() + 5);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        int kind = getKind();
        if (kind == GOAT_TOP || kind == GOAT_BOTTOM) {
            tickHalf();
            return;
        }
        ServerPlayer p = this.target == null ? null : sl.getServer().getPlayerList().getPlayer(this.target);
        if (p == null || p.level() != this.level() || !p.isAlive()) {
            this.discard();
            return;
        }
        switch (kind) {
            case TREE -> tickTree(p);
            case ROOF -> tickRoof(sl, p);
            case ONLOOKER -> tickOnlooker(sl, p);
            default -> tickRunner(sl, p);
        }
    }

    // ------------------------------ goat halves ------------------------------
    private void tickHalf() {
        if (this.tickCount > 80) {
            this.discard();
            return;
        }
        if (this.landed) {
            return;
        }
        this.vy -= 0.05D;
        double nx = getX() + this.vx;
        double ny = getY() + this.vy;
        double nz = getZ() + this.vz;
        BlockPos pos = BlockPos.containing(nx, ny, nz);
        if (this.vy < 0.0D && !this.level().getBlockState(pos).getCollisionShape(this.level(), pos).isEmpty()) {
            this.landed = true;
            ny = Mth.floor(ny) + 1.0D;
        }
        setPos(nx, ny, nz);
    }

    // ------------------------------ onlooker ------------------------------
    private boolean isLookedAtBy(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 aim = new Vec3(getX(), getY() + 3.0D, getZ());
        Vec3 to = aim.subtract(eye);
        double d = to.length();
        if (d > 70.0D || d < 0.5D) {
            return false;
        }
        if (p.getViewVector(1.0F).dot(to.scale(1.0D / d)) < 0.9D) {
            return false;
        }
        return this.level().clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    private void tickOnlooker(ServerLevel sl, ServerPlayer p) {
        switch (this.olPhase) {
            case 0 -> { // it keeps calling "hey" until somebody looks at it
                if (this.tickCount >= this.olNext) {
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.GOAT_HEY.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olNext = this.tickCount + ModSounds.GOAT_HEY_TICKS + 15;
                }
                if (isLookedAtBy(p)) {
                    p.connection.send(new ClientboundStopSoundPacket(
                            new ResourceLocation(GoatStalkerMod.MODID, "goat_hey"), SoundSource.HOSTILE));
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.LOOK_THIS.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olPhase = 1;
                    this.olTimer = this.tickCount;
                } else if (this.tickCount > 2400) { // nobody looked for 2 minutes
                    this.discard();
                }
            }
            case 1 -> { // "look this", then "hey"
                if (this.tickCount - this.olTimer >= ModSounds.LOOK_THIS_TICKS) {
                    sl.playSound(null, getX(), getY() + 2.0D, getZ(), ModSounds.HEY_VOICE.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                    this.olPhase = 2;
                    this.olTimer = this.tickCount;
                }
            }
            default -> {
                if (this.tickCount - this.olTimer >= ModSounds.HEY_VOICE_TICKS + 40) {
                    this.discard();
                }
            }
        }
    }

    // ------------------------------ tree ------------------------------
    private void tickTree(ServerPlayer p) {
        if (this.tickCount < 200) {
            if (!this.hit) {
                double dx = p.getX() - getX();
                double dz = p.getZ() - getZ();
                if (dx * dx + dz * dz < 25.0D) { // the player came closer than 5 blocks
                    this.hit = true;
                    halveHealth(p);
                    this.tickCount = 200;        // and it leaves right away
                }
            }
            return;
        }
        if (this.tickCount < 214) {
            setPos(getX() + this.slideX * 0.07D, getY(), getZ() + this.slideZ * 0.07D);
            return;
        }
        this.discard();
    }

    private void halveHealth(ServerPlayer p) {
        float cur = p.getHealth();
        float dmg = cur / 2.0F;
        if (cur - dmg < 1.0F) {
            dmg = cur - 1.0F;
        }
        if (dmg > 0.0F) {
            p.hurt(this.level().damageSources().magic(), dmg);
        }
    }

    // ------------------------------ roof ------------------------------
    private void tickRoof(ServerLevel sl, ServerPlayer p) {
        if (this.tickCount >= 60 && this.tickCount < 82) {
            setPos(getX(), getY() - 0.13D, getZ()); // head and shoulders go down behind the roof
        } else if (this.tickCount >= 82) {
            // the runner starts on the ground beside the house, on the side facing the player
            double dx = p.getX() - getX();
            double dz = p.getZ() - getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 1.0D) {
                dx = 1.0D;
                dz = 0.0D;
                len = 1.0D;
            }
            BipedalEntity runner = ModEntities.BIPEDAL.get().create(sl);
            if (runner != null) {
                runner.setup(RUNNER, p.getUUID());
                runner.setPos(getX() + dx / len * 6.0D, Nullspace.GROUND_TOP, getZ() + dz / len * 6.0D);
                runner.faceTo(dx, dz);
                sl.addFreshEntity(runner);
                NullspaceEvents.startVillageChase(p);
            }
            this.discard();
        }
    }

    // ------------------------------ runner ------------------------------
    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        this.setYRot(yaw);
        this.setXRot(0.0F);
    }

    private void tickRunner(ServerLevel sl, ServerPlayer p) {
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        faceTo(dx, dz);

        if (this.caughtAt >= 0) { // it has caught the player: it roars, then he is sent back
            if (this.tickCount - this.caughtAt > 45) {
                this.discard();
            }
            return;
        }
        if (d < 2.6D) {
            this.caughtAt = this.tickCount;
            this.entityData.set(DATA_ANIM, ANIM_SCREAM);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
            NullspaceEvents.stopMusic(p);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.SCREAM.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
            NullspaceEvents.schedule(sl.getServer(), 38, () -> NullspaceEvents.returnPlayerIfInNullspace(p));
            return;
        }
        setPos(getX() + dx / d * 0.42D, Nullspace.GROUND_TOP, getZ() + dz / d * 0.42D);
        if (this.tickCount % 4 == 0) {
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GRAVEL_STEP, SoundSource.HOSTILE, 1.5F, 0.6F);
        }
        if (this.tickCount > 900) {
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
