package com.example.goatstalker.client;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.example.goatstalker.GoatStalkerMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * A Blockbench model made of flat parts on a skeleton, with Bedrock animations, read from two JSON files that were
 * converted from the Blockbench/Bedrock files. Units are pixels (1/16 block); Y is up.
 * Flat parts can lie in the XY plane (north/south faces) or in the YZ plane (east/west faces).
 */
public class SkeletalModel {
    private final String modelPath;
    private final String animPath;

    public SkeletalModel(String modelPath, String animPath) {
        this.modelPath = modelPath;
        this.animPath = animPath;
    }

    private static final float DEG = (float) (Math.PI / 180.0D);

    private static final class Cube {
        float[] from, to, origin, rot;
        float[] north, south, east, west;
    }

    private static final class Bone {
        String name;
        float[] pivot, rot;
        final List<Cube> cubes = new ArrayList<>();
        final List<Bone> children = new ArrayList<>();
    }

    private static final class Key {
        float t;
        float[] pre, post;
        boolean smooth;
    }

    private static final class Channel {
        float[] constant;
        List<Key> keys;
    }

    private static final class BoneAnim {
        Channel rot, pos, scale;
    }

    private static final class Anim {
        float length;
        String loop;
        final Map<String, BoneAnim> bones = new HashMap<>();
    }

    private int currentOverlay = OverlayTexture.NO_OVERLAY;
    private boolean loaded;
    private final List<Bone> roots = new ArrayList<>();
    private final Map<String, Anim> anims = new HashMap<>();

    // ------------------------------ loading ------------------------------
    private synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            ResourceManager rm = Minecraft.getInstance().getResourceManager();
            JsonObject model = readJson(rm, new ResourceLocation(GoatStalkerMod.MODID, this.modelPath));
            Map<String, Bone> byName = new HashMap<>();
            List<JsonObject> raw = new ArrayList<>();
            for (JsonElement e : model.getAsJsonArray("bones")) {
                JsonObject o = e.getAsJsonObject();
                raw.add(o);
                Bone b = new Bone();
                b.name = o.get("name").getAsString();
                b.pivot = floats(o.getAsJsonArray("pivot"));
                b.rot = floats(o.getAsJsonArray("rotation"));
                for (JsonElement ce : o.getAsJsonArray("cubes")) {
                    JsonObject co = ce.getAsJsonObject();
                    Cube c = new Cube();
                    c.from = floats(co.getAsJsonArray("from"));
                    c.to = floats(co.getAsJsonArray("to"));
                    c.origin = floats(co.getAsJsonArray("origin"));
                    c.rot = floats(co.getAsJsonArray("rotation"));
                    if (co.has("north")) {
                        c.north = floats(co.getAsJsonArray("north"));
                    }
                    if (co.has("south")) {
                        c.south = floats(co.getAsJsonArray("south"));
                    }
                    if (co.has("east")) {
                        c.east = floats(co.getAsJsonArray("east"));
                    }
                    if (co.has("west")) {
                        c.west = floats(co.getAsJsonArray("west"));
                    }
                    b.cubes.add(c);
                }
                byName.put(b.name, b);
            }
            for (JsonObject o : raw) {
                Bone b = byName.get(o.get("name").getAsString());
                if (o.get("parent").isJsonNull()) {
                    roots.add(b);
                } else {
                    byName.get(o.get("parent").getAsString()).children.add(b);
                }
            }

            JsonObject animJson = readJson(rm, new ResourceLocation(GoatStalkerMod.MODID, this.animPath));
            for (Map.Entry<String, JsonElement> en : animJson.entrySet()) {
                JsonObject ao = en.getValue().getAsJsonObject();
                Anim a = new Anim();
                a.length = ao.get("length").getAsFloat();
                a.loop = ao.get("loop").getAsString();
                for (Map.Entry<String, JsonElement> be : ao.getAsJsonObject("bones").entrySet()) {
                    JsonObject bo = be.getValue().getAsJsonObject();
                    BoneAnim ba = new BoneAnim();
                    ba.rot = channel(bo, "rotation");
                    ba.pos = channel(bo, "position");
                    ba.scale = channel(bo, "scale");
                    a.bones.put(be.getKey(), ba);
                }
                anims.put(en.getKey(), a);
            }
        } catch (Exception ex) {
            roots.clear(); // the creature simply will not be drawn if the files cannot be read
        }
    }

    private static JsonObject readJson(ResourceManager rm, ResourceLocation id) throws Exception {
        try (Reader r = rm.openAsReader(id)) {
            return JsonParser.parseReader(r).getAsJsonObject();
        }
    }

    private static float[] floats(JsonArray arr) {
        float[] f = new float[arr.size()];
        for (int i = 0; i < f.length; i++) {
            f[i] = arr.get(i).getAsFloat();
        }
        return f;
    }

    private static Channel channel(JsonObject bone, String name) {
        if (!bone.has(name)) {
            return null;
        }
        JsonObject o = bone.getAsJsonObject(name);
        Channel c = new Channel();
        if (o.has("const")) {
            c.constant = floats(o.getAsJsonArray("const"));
        } else {
            c.keys = new ArrayList<>();
            for (JsonElement ke : o.getAsJsonArray("keys")) {
                JsonObject ko = ke.getAsJsonObject();
                Key k = new Key();
                k.t = ko.get("t").getAsFloat();
                k.pre = floats(ko.getAsJsonArray("pre"));
                k.post = floats(ko.getAsJsonArray("post"));
                k.smooth = ko.get("smooth").getAsBoolean();
                c.keys.add(k);
            }
        }
        return c;
    }

    // ------------------------------ animation sampling ------------------------------
    private static float[] sample(Channel c, float t, float[] def) {
        if (c == null) {
            return def;
        }
        if (c.constant != null) {
            return c.constant;
        }
        List<Key> ks = c.keys;
        if (ks.isEmpty()) {
            return def;
        }
        if (t <= ks.get(0).t) {
            return ks.get(0).post;
        }
        for (int i = 0; i < ks.size() - 1; i++) {
            Key a = ks.get(i);
            Key b = ks.get(i + 1);
            if (t >= a.t && t < b.t) {
                float f = (t - a.t) / (b.t - a.t);
                float[] out = new float[3];
                if (a.smooth) {
                    float[] p0 = i > 0 ? ks.get(i - 1).post : a.post;
                    float[] p3 = i + 2 < ks.size() ? ks.get(i + 2).pre : b.pre;
                    for (int j = 0; j < 3; j++) {
                        out[j] = catmull(p0[j], a.post[j], b.pre[j], p3[j], f);
                    }
                } else {
                    for (int j = 0; j < 3; j++) {
                        out[j] = a.post[j] + (b.pre[j] - a.post[j]) * f;
                    }
                }
                return out;
            }
        }
        return ks.get(ks.size() - 1).pre;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5F * ((2.0F * p1) + (-p0 + p2) * t + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t2
                + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t3);
    }

    // ------------------------------ rendering ------------------------------
    /**
     * Draws the whole creature. The pose must already be scaled to 1/16 (pixels).
     * @param hidden names of bones that are not drawn (with everything attached to them), e.g. a torn-off arm
     */
    public void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light, int overlay,
                       Set<String> hidden) {
        this.currentOverlay = overlay;
        this.hidden = hidden;
        load();
        Anim anim = anims.get(animName);
        float t = 0.0F;
        if (anim != null) {
            float len = Math.max(anim.length, 0.0001F);
            float s = Math.max(0.0F, seconds); // a negative time made the bones jump
            t = "true".equals(anim.loop) ? (s % len) : Math.min(s, len);
        }
        for (Bone b : roots) {
            renderBone(b, pose, vc, anim, t, light);
        }
    }

    private Set<String> hidden = Collections.emptySet();

    private void renderBone(Bone b, PoseStack pose, VertexConsumer vc, Anim anim, float t, int light) {
        float[] arot = {0, 0, 0};
        float[] apos = {0, 0, 0};
        float[] ascale = {1, 1, 1};
        if (anim != null) {
            BoneAnim ba = anim.bones.get(b.name);
            if (ba != null) {
                arot = sample(ba.rot, t, arot);
                apos = sample(ba.pos, t, apos);
                ascale = sample(ba.scale, t, ascale);
            }
        }
        if (this.hidden.contains(b.name)) {
            return;
        }
        if (ascale[0] <= 0.001F && ascale[1] <= 0.001F && ascale[2] <= 0.001F) {
            return; // scaled to zero: this part (and everything on it) is hidden
        }
        pose.pushPose();
        pose.translate(b.pivot[0] + apos[0], b.pivot[1] + apos[1], b.pivot[2] + apos[2]);
        pose.mulPose(rotation(b.rot[0] + arot[0], b.rot[1] + arot[1], b.rot[2] + arot[2]));
        if (ascale[0] != 1.0F || ascale[1] != 1.0F || ascale[2] != 1.0F) {
            pose.scale(ascale[0], ascale[1], ascale[2]);
        }
        pose.translate(-b.pivot[0], -b.pivot[1], -b.pivot[2]);
        for (Cube c : b.cubes) {
            renderCube(c, pose, vc, light);
        }
        for (Bone child : b.children) {
            renderBone(child, pose, vc, anim, t, light);
        }
        pose.popPose();
    }

    /** Blockbench (Bedrock) rotation: degrees, X and Y inverted, applied in the order Z, Y, X. */
    private static Quaternionf rotation(float x, float y, float z) {
        return new Quaternionf().rotationZYX(z * DEG, -y * DEG, -x * DEG);
    }

    private void renderCube(Cube c, PoseStack pose, VertexConsumer vc, int light) {
        pose.pushPose();
        pose.translate(c.origin[0], c.origin[1], c.origin[2]);
        pose.mulPose(rotation(c.rot[0], c.rot[1], c.rot[2]));
        pose.translate(-c.origin[0], -c.origin[1], -c.origin[2]);
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        float x0 = Math.min(c.from[0], c.to[0]);
        float x1 = Math.max(c.from[0], c.to[0]);
        float y0 = Math.min(c.from[1], c.to[1]);
        float y1 = Math.max(c.from[1], c.to[1]);
        float z = c.from[2];
        if (c.north != null) { // seen from -Z: the left side of the picture is +X
            float zz = z - 0.1F;
            float[] u = c.north;
            quad(vc, m, n, light, 0.0F, 0.0F, -1.0F,
                    x1, y0, zz, u[0], u[3],
                    x0, y0, zz, u[2], u[3],
                    x0, y1, zz, u[2], u[1],
                    x1, y1, zz, u[0], u[1]);
        }
        float z0 = Math.min(c.from[2], c.to[2]);
        float z1 = Math.max(c.from[2], c.to[2]);
        float x = c.from[0];
        if (c.east != null) { // a part in the YZ plane, seen from +X: the left side of the picture is +Z
            float xx = x + 0.02F;
            float[] u = c.east;
            quad(vc, m, n, light, 1.0F, 0.0F, 0.0F,
                    xx, y0, z1, u[0], u[3],
                    xx, y0, z0, u[2], u[3],
                    xx, y1, z0, u[2], u[1],
                    xx, y1, z1, u[0], u[1]);
        }
        if (c.west != null) { // seen from -X: the left side of the picture is -Z
            float xx = x - 0.02F;
            float[] u = c.west;
            quad(vc, m, n, light, -1.0F, 0.0F, 0.0F,
                    xx, y0, z0, u[0], u[3],
                    xx, y0, z1, u[2], u[3],
                    xx, y1, z1, u[2], u[1],
                    xx, y1, z0, u[0], u[1]);
        }
        if (c.south != null) { // seen from +Z: the left side of the picture is -X
            float zz = z + 0.1F;
            float[] u = c.south;
            quad(vc, m, n, light, 0.0F, 0.0F, 1.0F,
                    x0, y0, zz, u[0], u[3],
                    x1, y0, zz, u[2], u[3],
                    x1, y1, zz, u[2], u[1],
                    x0, y1, zz, u[0], u[1]);
        }
        pose.popPose();
    }

    private void quad(VertexConsumer vc, Matrix4f m, Matrix3f n, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float au, float av,
                             float bx, float by, float bz, float bu, float bv,
                             float cx, float cy, float cz, float cu, float cv,
                             float dx, float dy, float dz, float du, float dv) {
        vertex(vc, m, n, light, nx, ny, nz, ax, ay, az, au, av);
        vertex(vc, m, n, light, nx, ny, nz, bx, by, bz, bu, bv);
        vertex(vc, m, n, light, nx, ny, nz, cx, cy, cz, cu, cv);
        vertex(vc, m, n, light, nx, ny, nz, dx, dy, dz, du, dv);
    }

    private void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, int light, float nx, float ny, float nz,
                               float x, float y, float z, float u, float v) {
        vc.vertex(m, x, y, z)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(this.currentOverlay)
                .uv2(light)
                .normal(n, nx, ny, nz)
                .endVertex();
    }
}
