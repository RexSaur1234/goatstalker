package com.example.goatstalker;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/** Anguish: the server tells the client to show the keys A F P D T R; the client answers when they were pressed. */
public class AnguishNet {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GoatStalkerMod.MODID, "anguish"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0, Keys.class, Keys::encode, Keys::decode, Keys::handle,
                java.util.Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(1, Pressed.class, Pressed::encode, Pressed::decode, Pressed::handle,
                java.util.Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    /** Server to client: show the keys for this many ticks (0 = hide them). */
    public record Keys(int ticks) {
        public static void encode(Keys m, FriendlyByteBuf buf) {
            buf.writeVarInt(m.ticks());
        }

        public static Keys decode(FriendlyByteBuf buf) {
            return new Keys(buf.readVarInt());
        }

        public static void handle(Keys m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> com.example.goatstalker.client.AnguishKeys.start(m.ticks())));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Client to server: all the keys were pressed in time (true), or one of them was not (false). */
    public record Pressed(boolean success) {
        public static void encode(Pressed m, FriendlyByteBuf buf) {
            buf.writeBoolean(m.success());
        }

        public static Pressed decode(FriendlyByteBuf buf) {
            return new Pressed(buf.readBoolean());
        }

        public static void handle(Pressed m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer p = ctx.get().getSender();
                if (p != null) {
                    AnguishEntity.keysPressed(p, m.success());
                }
            });
            ctx.get().setPacketHandled(true);
        }
    }
}
