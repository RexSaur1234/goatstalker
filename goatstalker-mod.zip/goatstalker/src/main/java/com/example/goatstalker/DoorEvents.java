package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

/**
 * Double-door event. When the player builds a double door (two doors side by side), with a chance the creature
 * stands in the doorway while the music plays: door, Tormentor R, door, Tormentor R. Then it vanishes from the
 * doorway and appears behind a window (the music goes on), says its line (goat_window_voice), and the creature
 * and the music both disappear.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class DoorEvents {
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static final Map<UUID, Integer> TOKEN = new HashMap<>();

    private static final ResourceLocation[] MUSIC_IDS = {
            new ResourceLocation(GoatStalkerMod.MODID, "door_music"),
            new ResourceLocation(GoatStalkerMod.MODID, "tormentor_r")};

    // ------------------------------ detection ------------------------------
    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (!StalkerConfig.DOOR_ENABLED.get() || !(event.getEntity() instanceof ServerPlayer p)
                || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        BlockState st = event.getPlacedBlock();
        if (!(st.getBlock() instanceof DoorBlock)) {
            return;
        }
        BlockPos pos = event.getPos();
        if (st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) {
            pos = pos.below();
        }
        if (!isDoubleDoor(level, pos)) {
            return;
        }
        long now = level.getGameTime();
        Long until = COOLDOWN.get(p.getUUID());
        if (until != null && now < until) {
            return;
        }
        if (level.random.nextInt(100) >= StalkerConfig.DOOR_PERCENT.get()) {
            return;
        }
        if (start(p, level, pos)) {
            COOLDOWN.put(p.getUUID(), now + StalkerConfig.DOOR_COOLDOWN_MINUTES.get() * 1200L + 1000L);
        }
    }

    /** Two door blocks of the same facing standing next to each other (the lower halves are side by side). */
    private static boolean isDoubleDoor(ServerLevel level, BlockPos lower) {
        BlockState me = level.getBlockState(lower);
        if (!(me.getBlock() instanceof DoorBlock)) {
            return false;
        }
        Direction facing = me.getValue(DoorBlock.FACING);
        for (Direction side : new Direction[] {facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockState other = level.getBlockState(lower.relative(side));
            if (other.getBlock() instanceof DoorBlock
                    && other.getValue(DoorBlock.FACING) == facing
                    && other.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------ the scene ------------------------------
    private static void play(ServerPlayer p, RegistryObject<SoundEvent> s, int token) {
        if (!p.isAlive() || TOKEN.getOrDefault(p.getUUID(), 0) != token) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), s.get(), SoundSource.MUSIC, 1.0F, 1.0F);
    }

    private static void stopMusic(ServerPlayer p) {
        TOKEN.merge(p.getUUID(), 1, Integer::sum);
        for (ResourceLocation id : MUSIC_IDS) {
            p.connection.send(new ClientboundStopSoundPacket(id, SoundSource.MUSIC));
        }
    }

    private static BipedalEntity spawn(ServerLevel level, ServerPlayer p, int kind, double x, double y, double z) {
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return null;
        }
        e.setup(kind, p.getUUID());
        e.setPos(x, y, z);
        level.addFreshEntity(e);
        return e;
    }

    /** @param doorLower the lower half of the door the creature stands in. */
    public static boolean start(ServerPlayer p, ServerLevel level, BlockPos doorLower) {
        stopMusic(p); // also gives this scene a fresh token
        final int tk = TOKEN.get(p.getUUID());

        BipedalEntity door = spawn(level, p, BipedalEntity.DOOR, doorLower.getX() + 0.5D, doorLower.getY(), doorLower.getZ() + 0.5D);
        if (door == null) {
            return false;
        }
        var server = p.server;
        int d = ModSounds.DOOR_MUSIC_TICKS;
        int r = ModSounds.TORMENTOR_R_TICKS;

        // door, R, door, R
        play(p, ModSounds.DOOR_MUSIC, tk);
        NullspaceEvents.schedule(server, d, () -> play(p, ModSounds.TORMENTOR_R, tk));
        NullspaceEvents.schedule(server, d + r, () -> play(p, ModSounds.DOOR_MUSIC, tk));
        NullspaceEvents.schedule(server, 2 * d + r, () -> play(p, ModSounds.TORMENTOR_R, tk));

        // the doorway empties, the window shows up, the music keeps going
        int t1 = 2 * d + 2 * r;
        NullspaceEvents.schedule(server, t1, () -> {
            door.discard();
            if (TOKEN.getOrDefault(p.getUUID(), 0) != tk || !p.isAlive()) {
                return;
            }
            ServerLevel pl = p.serverLevel();
            BipedalEntity win = placeAtWindow(pl, p, doorLower);
            play(p, ModSounds.TORMENTOR_R, tk);
            int voiceAt = 100;
            NullspaceEvents.schedule(server, voiceAt, () -> {
                if (win != null && !win.isRemoved() && TOKEN.getOrDefault(p.getUUID(), 0) == tk) {
                    pl.playSound(null, win.getX(), win.getY() + 1.5D, win.getZ(), ModSounds.GOAT_WINDOW_VOICE.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                }
            });
            NullspaceEvents.schedule(server, voiceAt + ModSounds.WINDOW_VOICE_TICKS + 4, () -> {
                if (win != null) {
                    win.discard();
                }
                if (TOKEN.getOrDefault(p.getUUID(), 0) == tk) {
                    stopMusic(p);
                }
            });
        });
        return true;
    }

    /** Looks for a window (glass or glass pane) near the player with free air behind it; falls back to the doorway. */
    private static BipedalEntity placeAtWindow(ServerLevel level, ServerPlayer p, BlockPos fallback) {
        RandomSource r = level.random;
        BlockPos base = p.blockPosition();
        for (int i = 0; i < 150; i++) {
            BlockPos g = base.offset(r.nextInt(21) - 10, r.nextInt(5) - 1, r.nextInt(21) - 10);
            BlockState st = level.getBlockState(g);
            if (!(st.getBlock() instanceof IronBarsBlock || st.is(BlockTags.IMPERMEABLE))) {
                continue;
            }
            double dx = g.getX() + 0.5D - p.getX();
            double dz = g.getZ() + 0.5D - p.getZ();
            Direction away = Math.abs(dx) > Math.abs(dz)
                    ? (dx > 0 ? Direction.EAST : Direction.WEST)
                    : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
            BlockPos out = g.relative(away);
            if (!level.getBlockState(out).getCollisionShape(level, out).isEmpty()
                    || !level.getBlockState(out.above()).getCollisionShape(level, out.above()).isEmpty()) {
                continue;
            }
            // the picture's face is about 70 % of the way up, so the feet go about 1.8 blocks under the window's middle
            return spawn(level, p, BipedalEntity.WINDOW, out.getX() + 0.5D, g.getY() - 1.3D, out.getZ() + 0.5D);
        }
        return spawn(level, p, BipedalEntity.WINDOW, fallback.getX() + 0.5D, fallback.getY(), fallback.getZ() + 0.5D);
    }

    // ------------------------------ test command ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("doorEvent").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            double a = Math.toRadians(p.getYRot());
            BlockPos at = BlockPos.containing(p.getX() - Math.sin(a) * 4.0D, p.getY(), p.getZ() + Math.cos(a) * 4.0D);
            if (!start(p, level, at)) {
                ctx.getSource().sendFailure(Component.literal("Could not start the door event."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd));
    }
}
