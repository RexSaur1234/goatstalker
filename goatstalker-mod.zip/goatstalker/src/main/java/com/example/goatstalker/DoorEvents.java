package com.example.goatstalker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CrossCollisionBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

/**
 * Double-door event. When the player builds a double door (two doors side by side), with a chance the creature
 * stands in the doorway while the music plays: door, Tormentor R, door, Tormentor R. Then it vanishes from the
 * doorway and appears behind a window (the music goes on), says its line (goat_window_voice), and the creature
 * and the music both disappear.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class DoorEvents {
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static final Map<UUID, Integer> TOKEN = new HashMap<>();
    private static final Map<UUID, Long> WHISPER = new HashMap<>();
    private static final Map<UUID, Long> NEXT_PEEKER = new HashMap<>();
    /** Doors that cannot be closed while the creature stands in them. */
    private static final Map<UUID, List<BlockPos>> LOCKED = new java.util.concurrent.ConcurrentHashMap<>();

    private static final ResourceLocation[] MUSIC_IDS = {
            new ResourceLocation(GoatStalkerMod.MODID, "door_music"),
            new ResourceLocation(GoatStalkerMod.MODID, "tormentor_r")};

    // ------------------------------ when it comes ------------------------------
    private static final Map<UUID, Long> NEXT_DOOR = new HashMap<>();

    /** At a random moment (about every 50 minutes) if there is a double door near the player. */
    private static void tickDoorTimer(ServerPlayer p, long now) {
        ServerLevel level = p.serverLevel();
        if (!StalkerConfig.DOOR_ENABLED.get() || level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long avg = StalkerConfig.DOOR_MINUTES.get() * 1200L;
        long next = NEXT_DOOR.computeIfAbsent(p.getUUID(), k -> now + avg / 2 + level.random.nextInt((int) Math.max(1, avg)));
        if (now < next) {
            return;
        }
        BlockPos door = isBusy(p.getUUID()) ? null : DarkDoorEvents.findDoubleDoor(level, p);
        boolean ok = door != null && start(p, level, door);
        NEXT_DOOR.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1, avg)) : 600L));
    }

    /** Two door blocks of the same facing standing next to each other (the lower halves are side by side). */
    private static boolean isDoubleDoor(ServerLevel level, BlockPos lower) {
        BlockState me = level.getBlockState(lower);
        if (!(me.getBlock() instanceof DoorBlock)) {
            return false;
        }
        Direction facing = me.getValue(DoorBlock.FACING);
        for (Direction side : new Direction[] {facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockState other = level.getBlockState(lower.relative(side));
            if (other.getBlock() instanceof DoorBlock
                    && other.getValue(DoorBlock.FACING) == facing
                    && other.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------ the scene ------------------------------
    // The music uses the MASTER category, so it is heard even when the "Music" slider is turned off.
    private static final SoundSource CAT = SoundSource.MASTER;

    private static void play(ServerPlayer p, RegistryObject<SoundEvent> s, int token) {
        if (!p.isAlive() || TOKEN.getOrDefault(p.getUUID(), 0) != token) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), s.get(), CAT, 1.0F, 1.0F);
    }

    private static void stopMusic(ServerPlayer p) {
        TOKEN.merge(p.getUUID(), 1, Integer::sum);
        for (ResourceLocation id : MUSIC_IDS) {
            p.connection.send(new ClientboundStopSoundPacket(id, CAT));
        }
    }

    /** Yaw that makes the flat picture face along {@code inside} (toward the inside of the house). */
    static float yawFacing(Direction inside) {
        // the picture is drawn as if a camera looked at it in the direction opposite to "inside"
        double lx = -inside.getStepX();
        double lz = -inside.getStepZ();
        return (float) Math.toDegrees(Math.atan2(-lx, lz));
    }

    private static BipedalEntity spawn(ServerLevel level, ServerPlayer p, int kind, double x, double y, double z, float yaw) {
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return null;
        }
        e.setup(kind, p.getUUID());
        e.moveTo(x, y, z, yaw, 0.0F);
        e.setYRot(yaw);
        e.yRotO = yaw;
        level.addFreshEntity(e);
        return e;
    }

    /** The other half of a double door next to this one, or null. */
    static BlockPos partner(ServerLevel level, BlockPos lower) {
        BlockState me = level.getBlockState(lower);
        if (!(me.getBlock() instanceof DoorBlock)) {
            return null;
        }
        Direction facing = me.getValue(DoorBlock.FACING);
        for (Direction side : new Direction[] {facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockPos o = lower.relative(side);
            BlockState other = level.getBlockState(o);
            if (other.getBlock() instanceof DoorBlock && other.getValue(DoorBlock.FACING) == facing
                    && other.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                return o;
            }
        }
        return null;
    }

    static void closeDoor(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.getBlock() instanceof DoorBlock door && st.getValue(DoorBlock.OPEN)) {
            door.setOpen(null, level, st, pos, false);
        }
    }

    /** Doors of another scene: they cannot be closed until unlock is called. */
    static void lock(UUID owner, List<BlockPos> doors) {
        LOCKED.put(owner, java.util.List.copyOf(doors));
    }

    static void unlock(UUID owner) {
        LOCKED.remove(owner);
    }

    /** True while one of the door scenes runs for this player. */
    static boolean isBusy(UUID owner) {
        return LOCKED.containsKey(owner);
    }

    static void openDoor(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.getBlock() instanceof DoorBlock door && !st.getValue(DoorBlock.OPEN)) {
            door.setOpen(null, level, st, pos, true);
        }
    }

    /**
     * @param doorLower the lower half of a door, or any block where the creature should stand
     */
    public static boolean start(ServerPlayer p, ServerLevel level, BlockPos doorLower) {
        stopMusic(p); // also gives this scene a fresh token
        final int tk = TOKEN.get(p.getUUID());

        // which way is "inside" (the player's side of the wall) and where is the middle of the doorway
        BlockState st = level.getBlockState(doorLower);
        Direction inside;
        double cx = doorLower.getX() + 0.5D;
        double cz = doorLower.getZ() + 0.5D;
        BlockPos other = null;
        if (st.getBlock() instanceof DoorBlock) {
            Direction f = st.getValue(DoorBlock.FACING);
            double dot = (p.getX() - cx) * f.getStepX() + (p.getZ() - cz) * f.getStepZ();
            inside = dot >= 0 ? f : f.getOpposite();
            other = partner(level, doorLower);
            if (other != null) {
                cx = (cx + other.getX() + 0.5D) / 2.0D;
                cz = (cz + other.getZ() + 0.5D) / 2.0D;
            }
            openDoor(level, doorLower);
            List<BlockPos> lock = new ArrayList<>();
            lock.add(doorLower.immutable());
            if (other != null) {
                openDoor(level, other);
                lock.add(other.immutable());
            }
            LOCKED.put(p.getUUID(), lock);
        } else {
            inside = Direction.fromYRot(p.getYRot()).getOpposite(); // test: it faces the player
        }
        // the picture stands just in front of the wall on the player's side, so the head and the arm lie on the wall
        double off = st.getBlock() instanceof DoorBlock ? 0.62D : 0.0D;
        BipedalEntity door = spawn(level, p, BipedalEntity.DOOR, cx + inside.getStepX() * off, doorLower.getY(),
                cz + inside.getStepZ() * off, yawFacing(inside));
        if (door == null) {
            return false;
        }
        final BlockPos wallFrom = doorLower;
        final Direction in = inside;
        var server = p.server;
        int d = ModSounds.DOOR_MUSIC_TICKS;
        int r = ModSounds.TORMENTOR_R_TICKS;

        // door, R, door, R
        play(p, ModSounds.DOOR_MUSIC, tk);
        NullspaceEvents.schedule(server, d, () -> play(p, ModSounds.TORMENTOR_R, tk));
        NullspaceEvents.schedule(server, d + r, () -> play(p, ModSounds.DOOR_MUSIC, tk));
        NullspaceEvents.schedule(server, 2 * d + r, () -> play(p, ModSounds.TORMENTOR_R, tk));

        // the doorway empties, the creature shows up in a window, the music keeps going
        int t1 = 2 * d + 2 * r;
        NullspaceEvents.schedule(server, t1, () -> { // it is gone, the doors are free, the music stops
            door.discard();
            LOCKED.remove(p.getUUID());
            if (TOKEN.getOrDefault(p.getUUID(), 0) == tk) {
                stopMusic(p);
            }
        });
        return true;
    }

    /** The player walked into the creature in the doorway: the scene ends and the music stops. */
    public static void killedByDoor(ServerPlayer p) {
        stopMusic(p);
        LOCKED.remove(p.getUUID());
    }

    private static boolean isLocked(BlockPos lower) {
        for (List<BlockPos> l : LOCKED.values()) {
            if (l.contains(lower)) {
                return true;
            }
        }
        return false;
    }

    /** Called by the door creature every few ticks: doors shut by redstone are opened again. */
    public static void keepOpen(ServerLevel level, UUID owner) {
        List<BlockPos> l = LOCKED.get(owner);
        if (l != null) {
            for (BlockPos pos : l) {
                openDoor(level, pos);
            }
        }
    }

    /** While the creature stands in the doorway, the door cannot be closed. */
    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickBlock event) {
        if (event.getLevel().isClientSide() || LOCKED.isEmpty()) {
            return; // only the server decides (the client gets the door state back from it)
        }
        BlockState st = event.getLevel().getBlockState(event.getPos());
        if (!(st.getBlock() instanceof DoorBlock)) {
            return;
        }
        BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? event.getPos().below() : event.getPos();
        if (isLocked(lower)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    /** Glass blocks, glass panes (and iron bars) and fences count as a window. */
    private static boolean isWindow(BlockState st) {
        return st.getBlock() instanceof IronBarsBlock   // glass panes and iron bars
                || st.is(BlockTags.IMPERMEABLE)         // glass blocks (all colours)
                || st.getBlock() instanceof FenceBlock;
    }

    private static boolean open(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    /**
     * Which way the window looks (its normal), or null if that cannot be told. A glass pane knows it from its
     * connections; for a glass block (or a fence) the wall runs where its solid neighbours are.
     */
    private static Direction.Axis windowNormal(ServerLevel level, BlockPos g) {
        BlockState st = level.getBlockState(g);
        boolean alongX;
        boolean alongZ;
        if (st.getBlock() instanceof IronBarsBlock || st.getBlock() instanceof FenceBlock) {
            alongX = st.getValue(CrossCollisionBlock.EAST) || st.getValue(CrossCollisionBlock.WEST);
            alongZ = st.getValue(CrossCollisionBlock.NORTH) || st.getValue(CrossCollisionBlock.SOUTH);
        } else {
            alongX = !open(level, g.east()) || !open(level, g.west());
            alongZ = !open(level, g.north()) || !open(level, g.south());
        }
        if (alongX && !alongZ) {
            return Direction.Axis.Z; // the wall runs east-west, the window looks north-south
        }
        if (alongZ && !alongX) {
            return Direction.Axis.X;
        }
        // not clear: the side that has air on both sides of the window
        boolean openZ = open(level, g.north()) && open(level, g.south());
        boolean openX = open(level, g.east()) && open(level, g.west());
        if (openZ != openX) {
            return openZ ? Direction.Axis.Z : Direction.Axis.X;
        }
        return null;
    }

    /**
     * Puts the creature outside, straight behind the window (not inside the glass and not to the side): its face is
     * in line with the middle of the window, the picture is parallel to the wall and 1.6 blocks behind it.
     * Returns null if there is no room behind this window.
     */
    private static BipedalEntity spawnAtWindow(ServerLevel level, ServerPlayer p, BlockPos g) {
        return spawnAtWindow(level, p, g, BipedalEntity.WINDOW, BipedalEntity.WINDOW_H * 0.55D);
    }

    /** @param faceHeight how high the face is above the feet of the picture (it goes to the middle of the window). */
    static BipedalEntity spawnAtWindow(ServerLevel level, ServerPlayer p, BlockPos g, int kind, double faceHeight) {
        return spawnAtWindow(level, p, g, kind, faceHeight, BipedalEntity.WINDOW_GAP);
    }

    static BipedalEntity spawnAtWindow(ServerLevel level, ServerPlayer p, BlockPos g, int kind, double faceHeight,
                                       double gap) {
        Direction.Axis axis = windowNormal(level, g);
        if (axis == null) {
            return null;
        }
        double toPlayer = axis == Direction.Axis.X ? p.getX() - (g.getX() + 0.5D) : p.getZ() - (g.getZ() + 0.5D);
        if (Math.abs(toPlayer) < 0.3D) {
            return null; // the player stands in the window itself
        }
        Direction out = axis == Direction.Axis.X
                ? (toPlayer > 0 ? Direction.WEST : Direction.EAST)
                : (toPlayer > 0 ? Direction.NORTH : Direction.SOUTH);
        BlockPos o1 = g.relative(out);
        BlockPos o2 = o1.relative(out);
        if (!open(level, o1) || !open(level, o2)) {
            return null; // something is right behind the glass
        }
        Direction inside = out.getOpposite();
        // the face goes to the middle of the window
        double feet = g.getY() + 0.5D - faceHeight;
        return spawn(level, p, kind, g.getX() + 0.5D + out.getStepX() * gap, feet,
                g.getZ() + 0.5D + out.getStepZ() * gap, yawFacing(inside));
    }

    /** Window blocks near the player (glass, panes, fences), nearest first. */
    static List<BlockPos> windowsNear(ServerLevel level, ServerPlayer p, int radius) {
        BlockPos me = BlockPos.containing(p.getEyePosition());
        List<BlockPos> found = new ArrayList<>();
        for (BlockPos q : BlockPos.betweenClosed(me.offset(-radius, -5, -radius), me.offset(radius, 5, radius))) {
            if (isWindow(level.getBlockState(q))) {
                found.add(q.immutable());
            }
        }
        found.sort((x, y) -> Double.compare(x.distSqr(me), y.distSqr(me)));
        return found;
    }

    /** The nearest glass (or fence) to the player with room behind it, up to 24 blocks away; else the doorway. */
    private static BipedalEntity placeAtWindow(ServerLevel level, ServerPlayer p, BlockPos door, Direction inside) {
        List<BlockPos> found = windowsNear(level, p, 24);
        for (int i = 0; i < found.size() && i < 64; i++) {
            BipedalEntity e = spawnAtWindow(level, p, found.get(i));
            if (e != null) {
                return e;
            }
        }
        return spawn(level, p, BipedalEntity.WINDOW, door.getX() + 0.5D + inside.getStepX() * 0.62D, door.getY(),
                door.getZ() + 0.5D + inside.getStepZ() * 0.62D, yawFacing(inside));
    }

    // ------------------------------ "I know you're here" ------------------------------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.WHISPER_ENABLED.get()) {
            return;
        }
        long now = p.serverLevel().getGameTime();
        tickPeekerTimer(p, now);
        tickDoorTimer(p, now);
        long every = StalkerConfig.WHISPER_MINUTES.get() * 1200L;
        Long next = WHISPER.get(p.getUUID());
        if (next == null || next - now > every) { // first time, or the config was changed to a shorter time
            WHISPER.put(p.getUUID(), now + every);
            return;
        }
        if (now >= next) {
            WHISPER.put(p.getUUID(), now + every);
            whisper(p);
        }
    }

    // ------------------------------ the creature looking in through a window ------------------------------
    private static void tickPeekerTimer(ServerPlayer p, long now) {
        ServerLevel level = p.serverLevel();
        if (!StalkerConfig.PEEKER_ENABLED.get() || level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long avg = StalkerConfig.PEEKER_MINUTES.get() * 1200L;
        long next = NEXT_PEEKER.computeIfAbsent(p.getUUID(), k -> now + avg / 2 + level.random.nextInt((int) Math.max(1, avg)));
        if (now < next || level.canSeeSky(p.blockPosition())) {
            return; // only while the player is indoors
        }
        boolean ok = spawnPeeker(p, level);
        NEXT_PEEKER.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1, avg)) : 400L));
    }

    public static boolean spawnPeeker(ServerPlayer p, ServerLevel level) {
        for (BipedalEntity e : level.getEntitiesOfClass(BipedalEntity.class, p.getBoundingBox().inflate(100.0D))) {
            if (e.getKind() == BipedalEntity.PEEKER) {
                return false;
            }
        }
        List<BlockPos> found = windowsNear(level, p, 16);
        for (int i = 0; i < found.size() && i < 64; i++) {
            BipedalEntity e = spawnAtWindow(level, p, found.get(i), BipedalEntity.PEEKER,
                    BipedalEntity.PEEKER_H * BipedalEntity.PEEKER_FACE);
            if (e != null) {
                e.setWindow(found.get(i), level.getBlockState(found.get(i)).getBlock() instanceof IronBarsBlock);
                // a second guarantee that it goes away on time (its music stops when it is removed)
                NullspaceEvents.schedule(level.getServer(), StalkerConfig.PEEKER_SECONDS.get() * 20 + 20, () -> {
                    if (!e.isRemoved()) {
                        e.discard();
                    }
                });
                return true;
            }
        }
        return false;
    }

    /** The voice comes from right behind the player. */
    public static void whisper(ServerPlayer p) {
        double a = Math.toRadians(p.getYRot());
        double x = p.getX() + Math.sin(a) * 1.5D;
        double z = p.getZ() - Math.cos(a) * 1.5D;
        p.connection.send(new ClientboundSoundPacket(Holder.direct(ModSounds.I_KNOW_YOURE_HERE.get()), SoundSource.HOSTILE,
                x, p.getEyeY(), z, 1.0F, 1.0F, p.getRandom().nextLong()));
    }

    // ------------------------------ test command ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("doorEvent").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            BlockPos at = null;
            double best = Double.MAX_VALUE;
            for (BlockPos q : BlockPos.betweenClosed(p.blockPosition().offset(-8, -3, -8), p.blockPosition().offset(8, 3, 8))) {
                BlockState qs = level.getBlockState(q);
                if (qs.getBlock() instanceof DoorBlock && qs.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                    double dd = q.distSqr(p.blockPosition());
                    if (dd < best) {
                        best = dd;
                        at = q.immutable();
                    }
                }
            }
            if (at == null) { // no door near: 4 blocks in front of the player
                double a = Math.toRadians(p.getYRot());
                at = BlockPos.containing(p.getX() - Math.sin(a) * 4.0D, p.getY(), p.getZ() + Math.cos(a) * 4.0D);
            }
            if (!start(p, level, at)) {
                ctx.getSource().sendFailure(Component.literal("Could not start the door event."));
                return 0;
            }
            return 1;
        });
        var voice = Commands.literal("iKnowYoureHere").executes(ctx -> {
            whisper(ctx.getSource().getPlayerOrException());
            return 1;
        });
        var peeker = Commands.literal("windowPeeker").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawnPeeker(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No window with free room behind it within 16 blocks (or one is already watching)."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd).then(voice).then(peeker));
    }
}
