package com.example.goatstalker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

/**
 * Double-door event. When the player builds a double door (two doors side by side), with a chance the creature
 * stands in the doorway while the music plays: door, Tormentor R, door, Tormentor R. Then it vanishes from the
 * doorway and appears behind a window (the music goes on), says its line (goat_window_voice), and the creature
 * and the music both disappear.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class DoorEvents {
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();
    private static final Map<UUID, Integer> TOKEN = new HashMap<>();
    private static final Map<UUID, Long> WHISPER = new HashMap<>();
    /** Doors that cannot be closed while the creature stands in them. */
    private static final Map<UUID, List<BlockPos>> LOCKED = new HashMap<>();

    private static final ResourceLocation[] MUSIC_IDS = {
            new ResourceLocation(GoatStalkerMod.MODID, "door_music"),
            new ResourceLocation(GoatStalkerMod.MODID, "tormentor_r")};

    // ------------------------------ detection ------------------------------
    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (!StalkerConfig.DOOR_ENABLED.get() || !(event.getEntity() instanceof ServerPlayer p)
                || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        BlockState st = event.getPlacedBlock();
        if (!(st.getBlock() instanceof DoorBlock)) {
            return;
        }
        BlockPos pos = event.getPos();
        if (st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) {
            pos = pos.below();
        }
        if (!isDoubleDoor(level, pos)) {
            return;
        }
        long now = level.getGameTime();
        Long until = COOLDOWN.get(p.getUUID());
        if (until != null && now < until) {
            return;
        }
        if (level.random.nextInt(100) >= StalkerConfig.DOOR_PERCENT.get()) {
            return;
        }
        if (start(p, level, pos)) {
            COOLDOWN.put(p.getUUID(), now + StalkerConfig.DOOR_COOLDOWN_MINUTES.get() * 1200L + 1000L);
        }
    }

    /** Two door blocks of the same facing standing next to each other (the lower halves are side by side). */
    private static boolean isDoubleDoor(ServerLevel level, BlockPos lower) {
        BlockState me = level.getBlockState(lower);
        if (!(me.getBlock() instanceof DoorBlock)) {
            return false;
        }
        Direction facing = me.getValue(DoorBlock.FACING);
        for (Direction side : new Direction[] {facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockState other = level.getBlockState(lower.relative(side));
            if (other.getBlock() instanceof DoorBlock
                    && other.getValue(DoorBlock.FACING) == facing
                    && other.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------ the scene ------------------------------
    // The music uses the MASTER category, so it is heard even when the "Music" slider is turned off.
    private static final SoundSource CAT = SoundSource.MASTER;

    private static void play(ServerPlayer p, RegistryObject<SoundEvent> s, int token) {
        if (!p.isAlive() || TOKEN.getOrDefault(p.getUUID(), 0) != token) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), s.get(), CAT, 1.0F, 1.0F);
    }

    private static void stopMusic(ServerPlayer p) {
        TOKEN.merge(p.getUUID(), 1, Integer::sum);
        for (ResourceLocation id : MUSIC_IDS) {
            p.connection.send(new ClientboundStopSoundPacket(id, CAT));
        }
    }

    /** Yaw that makes the flat picture face along {@code inside} (toward the inside of the house). */
    private static float yawFacing(Direction inside) {
        // the picture is drawn as if a camera looked at it in the direction opposite to "inside"
        double lx = -inside.getStepX();
        double lz = -inside.getStepZ();
        return (float) Math.toDegrees(Math.atan2(-lx, lz));
    }

    private static BipedalEntity spawn(ServerLevel level, ServerPlayer p, int kind, double x, double y, double z, float yaw) {
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return null;
        }
        e.setup(kind, p.getUUID());
        e.moveTo(x, y, z, yaw, 0.0F);
        e.setYRot(yaw);
        e.yRotO = yaw;
        level.addFreshEntity(e);
        return e;
    }

    /** The other half of a double door next to this one, or null. */
    private static BlockPos partner(ServerLevel level, BlockPos lower) {
        BlockState me = level.getBlockState(lower);
        if (!(me.getBlock() instanceof DoorBlock)) {
            return null;
        }
        Direction facing = me.getValue(DoorBlock.FACING);
        for (Direction side : new Direction[] {facing.getClockWise(), facing.getCounterClockWise()}) {
            BlockPos o = lower.relative(side);
            BlockState other = level.getBlockState(o);
            if (other.getBlock() instanceof DoorBlock && other.getValue(DoorBlock.FACING) == facing
                    && other.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                return o;
            }
        }
        return null;
    }

    private static void openDoor(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.getBlock() instanceof DoorBlock door && !st.getValue(DoorBlock.OPEN)) {
            door.setOpen(null, level, st, pos, true);
        }
    }

    /**
     * @param doorLower the lower half of a door, or any block where the creature should stand
     */
    public static boolean start(ServerPlayer p, ServerLevel level, BlockPos doorLower) {
        stopMusic(p); // also gives this scene a fresh token
        final int tk = TOKEN.get(p.getUUID());

        // which way is "inside" (the player's side of the wall) and where is the middle of the doorway
        BlockState st = level.getBlockState(doorLower);
        Direction inside;
        double cx = doorLower.getX() + 0.5D;
        double cz = doorLower.getZ() + 0.5D;
        BlockPos other = null;
        if (st.getBlock() instanceof DoorBlock) {
            Direction f = st.getValue(DoorBlock.FACING);
            double dot = (p.getX() - cx) * f.getStepX() + (p.getZ() - cz) * f.getStepZ();
            inside = dot >= 0 ? f : f.getOpposite();
            other = partner(level, doorLower);
            if (other != null) {
                cx = (cx + other.getX() + 0.5D) / 2.0D;
                cz = (cz + other.getZ() + 0.5D) / 2.0D;
            }
            openDoor(level, doorLower);
            List<BlockPos> lock = new ArrayList<>();
            lock.add(doorLower.immutable());
            if (other != null) {
                openDoor(level, other);
                lock.add(other.immutable());
            }
            LOCKED.put(p.getUUID(), lock);
        } else {
            inside = Direction.fromYRot(p.getYRot()).getOpposite(); // test: it faces the player
        }
        // the picture stands just in front of the wall on the player's side, so the head and the arm lie on the wall
        double off = st.getBlock() instanceof DoorBlock ? 0.62D : 0.0D;
        BipedalEntity door = spawn(level, p, BipedalEntity.DOOR, cx + inside.getStepX() * off, doorLower.getY(),
                cz + inside.getStepZ() * off, yawFacing(inside));
        if (door == null) {
            return false;
        }
        final BlockPos wallFrom = doorLower;
        final Direction in = inside;
        var server = p.server;
        int d = ModSounds.DOOR_MUSIC_TICKS;
        int r = ModSounds.TORMENTOR_R_TICKS;

        // door, R, door, R
        play(p, ModSounds.DOOR_MUSIC, tk);
        NullspaceEvents.schedule(server, d, () -> play(p, ModSounds.TORMENTOR_R, tk));
        NullspaceEvents.schedule(server, d + r, () -> play(p, ModSounds.DOOR_MUSIC, tk));
        NullspaceEvents.schedule(server, 2 * d + r, () -> play(p, ModSounds.TORMENTOR_R, tk));

        // the doorway empties, the creature shows up in a window, the music keeps going
        int t1 = 2 * d + 2 * r;
        NullspaceEvents.schedule(server, t1, () -> {
            door.discard();
            LOCKED.remove(p.getUUID());
            if (TOKEN.getOrDefault(p.getUUID(), 0) != tk || !p.isAlive()) {
                return;
            }
            ServerLevel pl = p.serverLevel();
            play(p, ModSounds.TORMENTOR_R, tk);
            BipedalEntity win = placeAtWindow(pl, p, wallFrom, in);
            int voiceAt = 100;
            NullspaceEvents.schedule(server, voiceAt, () -> {
                if (win != null && !win.isRemoved() && TOKEN.getOrDefault(p.getUUID(), 0) == tk) {
                    pl.playSound(null, win.getX(), win.getY() + 1.6D, win.getZ(), ModSounds.GOAT_WINDOW_VOICE.get(),
                            SoundSource.HOSTILE, 3.0F, 1.0F);
                }
            });
            NullspaceEvents.schedule(server, voiceAt + ModSounds.WINDOW_VOICE_TICKS + 6, () -> {
                if (win != null) {
                    win.discard();
                }
                if (TOKEN.getOrDefault(p.getUUID(), 0) == tk) {
                    stopMusic(p);
                }
            });
        });
        return true;
    }

    /** The player walked into the creature in the doorway: the scene ends and the music stops. */
    public static void killedByDoor(ServerPlayer p) {
        stopMusic(p);
        LOCKED.remove(p.getUUID());
    }

    private static boolean isLocked(BlockPos lower) {
        for (List<BlockPos> l : LOCKED.values()) {
            if (l.contains(lower)) {
                return true;
            }
        }
        return false;
    }

    /** Called by the door creature every few ticks: doors shut by redstone are opened again. */
    public static void keepOpen(ServerLevel level, UUID owner) {
        List<BlockPos> l = LOCKED.get(owner);
        if (l != null) {
            for (BlockPos pos : l) {
                openDoor(level, pos);
            }
        }
    }

    /** While the creature stands in the doorway, the door cannot be closed. */
    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickBlock event) {
        if (LOCKED.isEmpty()) {
            return;
        }
        BlockState st = event.getLevel().getBlockState(event.getPos());
        if (!(st.getBlock() instanceof DoorBlock)) {
            return;
        }
        BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? event.getPos().below() : event.getPos();
        if (isLocked(lower)) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    /** Glass blocks, glass panes (and iron bars) and fences count as a window. */
    private static boolean isWindow(BlockState st) {
        return st.getBlock() instanceof IronBarsBlock   // glass panes and iron bars
                || st.is(BlockTags.IMPERMEABLE)         // glass blocks (all colours)
                || st.getBlock() instanceof FenceBlock;
    }

    private static boolean open(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    /** The creature's face looks in through the window from outside (the side away from the player). */
    private static BipedalEntity spawnAtWindow(ServerLevel level, ServerPlayer p, BlockPos g) {
        // the wall runs along the axis where the window has solid neighbours / more glass; it looks out along the other one
        boolean wallAlongX = !open(level, g.east()) || !open(level, g.west());
        boolean wallAlongZ = !open(level, g.north()) || !open(level, g.south());
        double dx = g.getX() + 0.5D - p.getX();
        double dz = g.getZ() + 0.5D - p.getZ();
        Direction out;
        if (wallAlongX && !wallAlongZ) {
            out = dz > 0 ? Direction.SOUTH : Direction.NORTH;
        } else if (wallAlongZ && !wallAlongX) {
            out = dx > 0 ? Direction.EAST : Direction.WEST;
        } else {
            out = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST)
                    : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        }
        Direction inside = out.getOpposite();
        // its face is about 45 % from the top of the picture: put it in the middle of the window
        double feet = g.getY() + 0.5D - BipedalEntity.WINDOW_H * 0.55D;
        return spawn(level, p, BipedalEntity.WINDOW, g.getX() + 0.5D + out.getStepX() * 0.95D, feet,
                g.getZ() + 0.5D + out.getStepZ() * 0.95D, yawFacing(inside));
    }

    /** The nearest glass (or fence) to the player, up to 24 blocks away. If there is none, it comes back to the doorway. */
    private static BipedalEntity placeAtWindow(ServerLevel level, ServerPlayer p, BlockPos door, Direction inside) {
        BlockPos me = BlockPos.containing(p.getEyePosition());
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos q : BlockPos.betweenClosed(me.offset(-24, -5, -24), me.offset(24, 5, 24))) {
            double d = q.distSqr(me);
            if (d < bestD && isWindow(level.getBlockState(q))) {
                bestD = d;
                best = q.immutable();
            }
        }
        if (best != null) {
            return spawnAtWindow(level, p, best);
        }
        return spawn(level, p, BipedalEntity.WINDOW, door.getX() + 0.5D + inside.getStepX() * 0.62D, door.getY(),
                door.getZ() + 0.5D + inside.getStepZ() * 0.62D, yawFacing(inside));
    }

    // ------------------------------ "I know you're here" ------------------------------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.WHISPER_ENABLED.get()) {
            return;
        }
        long now = p.serverLevel().getGameTime();
        long every = StalkerConfig.WHISPER_MINUTES.get() * 1200L;
        Long next = WHISPER.get(p.getUUID());
        if (next == null || next - now > every) { // first time, or the config was changed to a shorter time
            WHISPER.put(p.getUUID(), now + every);
            return;
        }
        if (now >= next) {
            WHISPER.put(p.getUUID(), now + every);
            whisper(p);
        }
    }

    /** The voice comes from right behind the player. */
    public static void whisper(ServerPlayer p) {
        double a = Math.toRadians(p.getYRot());
        double x = p.getX() + Math.sin(a) * 1.5D;
        double z = p.getZ() - Math.cos(a) * 1.5D;
        p.connection.send(new ClientboundSoundPacket(Holder.direct(ModSounds.I_KNOW_YOURE_HERE.get()), SoundSource.HOSTILE,
                x, p.getEyeY(), z, 1.0F, 1.0F, p.getRandom().nextLong()));
    }

    // ------------------------------ test command ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("doorEvent").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            BlockPos at = null;
            double best = Double.MAX_VALUE;
            for (BlockPos q : BlockPos.betweenClosed(p.blockPosition().offset(-8, -3, -8), p.blockPosition().offset(8, 3, 8))) {
                BlockState qs = level.getBlockState(q);
                if (qs.getBlock() instanceof DoorBlock && qs.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                    double dd = q.distSqr(p.blockPosition());
                    if (dd < best) {
                        best = dd;
                        at = q.immutable();
                    }
                }
            }
            if (at == null) { // no door near: 4 blocks in front of the player
                double a = Math.toRadians(p.getYRot());
                at = BlockPos.containing(p.getX() - Math.sin(a) * 4.0D, p.getY(), p.getZ() + Math.cos(a) * 4.0D);
            }
            if (!start(p, level, at)) {
                ctx.getSource().sendFailure(Component.literal("Could not start the door event."));
                return 0;
            }
            return 1;
        });
        var voice = Commands.literal("iKnowYoureHere").executes(ctx -> {
            whisper(ctx.getSource().getPlayerOrException());
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd).then(voice));
    }
}
