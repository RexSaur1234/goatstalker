package com.example.goatstalker.client;

import com.example.goatstalker.BipedalEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.ModBlockEntities;
import com.example.goatstalker.ModEntities;
import com.example.goatstalker.Nullspace;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.STALKER.get(), StalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.PART.get(), StalkerPartRenderer::new);
        event.registerEntityRenderer(ModEntities.BIPEDAL.get(), BipedalRenderer::new);
        event.registerEntityRenderer(ModEntities.BIPEDAL_MOB.get(), BipedalMobRenderer::new);
        event.registerEntityRenderer(ModEntities.TORMENTOR.get(), TormentorRenderer::new);
        event.registerEntityRenderer(ModEntities.BIPEDAL_2.get(), BipedalStalker2Renderer::new);
        event.registerEntityRenderer(ModEntities.EVIL_TORMENTOR.get(), EvilDarkTormentorRenderer::new);
        event.registerEntityRenderer(ModEntities.SUFFERING.get(), SufferingRenderer::new);
        event.registerEntityRenderer(ModEntities.ANGUISH.get(), AnguishRenderer::new);
        event.registerEntityRenderer(ModEntities.QUADRUPED.get(), QuadrupedStalkerRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.TV.get(), TvRenderer::new);
    }

    /**
     * "RUN, IT'S BEHIND YOU": shown for as long as the creature runs after you on the Island, and it shakes.
     * No network needed: the client just looks for a running creature nearby.
     */
    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("anguish_keys", (gui, graphics, partialTick, width, height) ->
                AnguishKeys.render(graphics, width, height));
        event.registerAboveAll("run_text", (gui, graphics, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null || mc.level.dimension() != Nullspace.ISLAND) {
                return;
            }
            boolean chase = false;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof BipedalEntity b && b.getKind() == BipedalEntity.RUNNER
                        && b.getAnim() == BipedalEntity.ANIM_RUN) {
                    chase = true;
                    break;
                }
            }
            if (!chase) {
                return;
            }
            String text = "RUN, IT'S BEHIND YOU";
            float scale = 1.5F;
            int textWidth = mc.font.width(text);
            float shakeX = (float) ((Math.random() - 0.5D) * 5.0D);
            float shakeY = (float) ((Math.random() - 0.5D) * 5.0D);
            graphics.pose().pushPose();
            graphics.pose().translate(width / 2.0F + shakeX, height - 62.0F + shakeY, 0.0F);
            graphics.pose().scale(scale, scale, 1.0F);
            graphics.drawString(mc.font, text, -textWidth / 2, 0, 0xC8F4FF, true);
            graphics.pose().popPose();
        });
    }
}
