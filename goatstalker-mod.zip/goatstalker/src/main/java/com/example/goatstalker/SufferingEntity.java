package com.example.goatstalker;

import java.util.List;
import java.util.UUID;

import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Sufferings: a giant pale creature, three times as tall as the Evil Dark Tormentor (about 25 blocks; the hitbox is
 * smaller, so it can still walk through the world), a little faster than a wolf.
 * When it sees a player: bone crack and its voice, then it stands still for 5 seconds, then it twists its body and
 * runs after him with its own chase music. One touch kills.
 * Every Goat Stalker monster near it becomes angrier (it hunts the nearest player), faster and stronger, and kills
 * the player with one hit.
 */
public class SufferingEntity extends Monster {
    public static final int A_IDLE = 0;
    public static final int A_TALK = 1;
    public static final int A_TWIST = 2;
    public static final int A_RUN = 3;
    public static final int A_TILT = 4;
    public static final int A_SCREAM = 5;
    /** Animation names in assets/goatstalker/suffering/animations.json. */
    public static final String[] ANIM_NAMES = {"quieto", "hablar", "doblar", "correr", "js_tilt", "js_scream"};

    /** How far its influence on the other monsters reaches. */
    public static final double AURA = 64.0D;
    private static final ResourceLocation CHASE_ID = new ResourceLocation(GoatStalkerMod.MODID, "cu_chase");
    private static final int CHASE_MUSIC_TICKS = 804; // cu_chase.ogg is 40.2 s

    private static final int VOICE_TICKS = 96;   // sufrimiento_voice.ogg, 4.8 s
    private static final int STAND_TICKS = 100;  // then it just stands for 5 seconds
    private static final int TWIST_TICKS = 64;   // the "doblar" animation, 3.2 s

    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(SufferingEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(SufferingEntity.class, EntityDataSerializers.INT);

    private int clientAnimStart;

    /** 0 = wandering, 1 = noticed (voice, standing, twisting), 2 = chasing, 3 = killing. */
    private int phase = 0;
    private int phaseTick = 0;
    private UUID preyId;
    private UUID musicFor;
    private int musicTick = 0;
    private int lostTicks = 0;
    private int cooldown = 0;
    private int lifetime = -1;

    /** It goes away after this many ticks, unless it is chasing someone (when it came on its own). */
    public void setTimedLife(int ticks) {
        this.lifetime = ticks;
    }

    public SufferingEntity(EntityType<? extends SufferingEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1000.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)   // a wolf has 0.3
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.ATTACK_DAMAGE, 1000.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    // ------------------------------ the other monsters ------------------------------
    /** The monsters of this mod. */
    public static boolean isGoatMonster(Entity e) {
        return e instanceof StalkerEntity || e instanceof BipedalMobEntity || e instanceof BipedalStalker2Entity
                || e instanceof TormentorEntity || e instanceof EvilDarkTormentorEntity || e instanceof QuadrupedStalkerEntity;
    }

    /** True when a living Sufferings is near this entity: it is stronger, faster, angrier and kills with one hit. */
    public static boolean empowers(Entity e) {
        return !e.level().getEntitiesOfClass(SufferingEntity.class, e.getBoundingBox().inflate(AURA),
                SufferingEntity::isAlive).isEmpty();
    }

    private void empowerOthers(ServerLevel sl) {
        List<Mob> mobs = sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(AURA),
                m -> m.isAlive() && isGoatMonster(m));
        for (Mob m : mobs) {
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 50, 1, true, false));
            m.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 50, 4, true, false));
            if (m.getTarget() == null) { // angrier: it goes for the nearest player at once
                Player p = sl.getNearestPlayer(m.getX(), m.getY(), m.getZ(), 48.0D,
                        e -> e instanceof Player pl && !pl.isCreative() && !pl.isSpectator() && pl.isAlive());
                if (p != null) {
                    m.setTarget(p);
                }
            }
        }
    }

    // ------------------------------ size ------------------------------
    @Override
    public float maxUpStep() {
        return 2.0F;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distSqr) {
        return distSqr < 320.0D * 320.0D; // a giant: seen from far away
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 12, getY() - 1, getZ() - 12, getX() + 12, getY() + 27, getZ() + 12);
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.phase == 1 || this.phase == 3;
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, true) {
            @Override
            public boolean canUse() {
                return SufferingEntity.this.phase == 2 && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return SufferingEntity.this.phase == 2 && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 30.0D; // its arms are long: about 5.5 blocks
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (distSqr <= getAttackReachSqr(target)) {
                    SufferingEntity.this.strike(target);
                }
            }
        });
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                e -> e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.lifetime >= 0 && this.tickCount > this.lifetime && this.phase == 0) {
            discard();
            return;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        if (this.tickCount % 20 == 0) {
            empowerOthers(sl);
        }
        this.phaseTick++;
        switch (this.phase) {
            case 0 -> tickWander(sl);
            case 1 -> tickNoticed(sl);
            case 2 -> tickChase(sl);
            case 3 -> tickKill(sl);
            default -> this.phase = 0;
        }
        if (this.phase == 0 || this.phase == 2) {
            Vec3 v = getDeltaMovement();
            anim((v.x * v.x + v.z * v.z > 0.0015D) ? A_RUN : A_IDLE, false);
        }
        updateMusic(sl);
    }

    private void anim(int a, boolean restart) {
        if (restart || a != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, a);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void setPhase(int p) {
        this.phase = p;
        this.phaseTick = 0;
    }

    private void faceTo(Entity e) {
        float yaw = (float) (Mth.atan2(-(e.getX() - getX()), e.getZ() - getZ()) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private ServerPlayer prey(ServerLevel sl) {
        return this.preyId == null ? null : sl.getServer().getPlayerList().getPlayer(this.preyId);
    }

    /** It sees a player: bone crack and its voice. */
    private void tickWander(ServerLevel sl) {
        if (this.cooldown > 0) {
            return;
        }
        if (getTarget() instanceof ServerPlayer sp && sp.isAlive() && hasLineOfSight(sp)) {
            this.preyId = sp.getUUID();
            setPhase(1);
            getNavigation().stop();
            setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
            anim(A_TALK, true);
            sl.playSound(null, getX(), getY() + 6.0D, getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 5.0F, 0.8F);
            sl.playSound(null, getX(), getY() + 6.0D, getZ(), ModSounds.SUFFERING_VOICE.get(), SoundSource.HOSTILE, 6.0F, 1.0F);
        }
    }

    /** Voice (talking), then 5 seconds standing still, then it twists its body. */
    private void tickNoticed(ServerLevel sl) {
        ServerPlayer sp = prey(sl);
        if (sp == null || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            setPhase(0);
            return;
        }
        getNavigation().stop();
        faceTo(sp);
        getLookControl().setLookAt(sp, 30.0F, 30.0F);
        int t = this.phaseTick;
        if (t == VOICE_TICKS) {
            anim(A_IDLE, true);
        } else if (t == VOICE_TICKS + STAND_TICKS) {
            anim(A_TWIST, true);
            sl.playSound(null, getX(), getY() + 10.0D, getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 5.0F, 0.6F);
        } else if (t >= VOICE_TICKS + STAND_TICKS + TWIST_TICKS) {
            setTarget(sp);
            setPhase(2);
            this.musicFor = sp.getUUID();
            this.musicTick = 0;
        }
    }

    private void tickChase(ServerLevel sl) {
        ServerPlayer sp = prey(sl);
        boolean gone = sp == null || !sp.isAlive() || sp.isCreative() || sp.isSpectator() || sp.level() != this.level();
        if (!gone && distanceToSqr(sp) > 110.0D * 110.0D) {
            this.lostTicks++;
        } else {
            this.lostTicks = 0;
        }
        if (gone || this.lostTicks > 200) {
            endChase();
            return;
        }
        if (getTarget() != sp) {
            setTarget(sp);
        }
    }

    private void endChase() {
        stopMusic();
        this.preyId = null;
        setTarget(null);
        setPhase(0);
        this.cooldown = 200;
    }

    /** One touch: it screams in his face and he is dead. */
    private void strike(LivingEntity target) {
        if (this.phase != 2) {
            return;
        }
        if (!(target instanceof ServerPlayer)) {
            doHurtTarget(target);
            return;
        }
        setPhase(3);
        getNavigation().stop();
        anim(A_SCREAM, true);
    }

    private void tickKill(ServerLevel sl) {
        ServerPlayer sp = prey(sl);
        if (sp != null) {
            faceTo(sp);
        }
        if (this.phaseTick == 1 && sp != null && sp.isAlive()) {
            sl.playSound(null, getX(), getY() + 8.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 6.0F, 0.6F);
            sl.playSound(null, sp.getX(), sp.getY() + 1.0D, sp.getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.9F);
            Blood.spray(sl, sp.getX(), sp.getY() + 1.2D, sp.getZ(), 90, 0.6D);
            sp.invulnerableTime = 0;
            sp.hurt(this.level().damageSources().mobAttack(this), 100000.0F);
            if (sp.isAlive()) {
                sp.kill();
            }
        }
        if (this.phaseTick >= 40) {
            endChase();
        }
    }

    // ------------------------------ chase music ------------------------------
    private void updateMusic(ServerLevel sl) {
        if (this.phase != 2 && this.phase != 3 || this.musicFor == null) {
            return;
        }
        ServerPlayer p = sl.getServer().getPlayerList().getPlayer(this.musicFor);
        if (p == null) {
            return;
        }
        if (this.musicTick % CHASE_MUSIC_TICKS == 0) {
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.CU_CHASE.get(), SoundSource.MASTER, 1.0F, 1.0F);
        }
        this.musicTick++;
    }

    private void stopMusic() {
        if (this.musicFor != null && this.level() instanceof ServerLevel sl) {
            ServerPlayer p = sl.getServer().getPlayerList().getPlayer(this.musicFor);
            if (p != null) {
                p.connection.send(new ClientboundStopSoundPacket(CHASE_ID, SoundSource.MASTER));
            }
        }
        this.musicFor = null;
    }

    @Override
    public void remove(RemovalReason reason) {
        stopMusic();
        super.remove(reason);
    }

    // ------------------------------ sounds ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 3.0F;
    }
}
