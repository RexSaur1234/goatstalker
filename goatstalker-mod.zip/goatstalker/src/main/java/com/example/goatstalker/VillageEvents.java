package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * In a village (a normal Minecraft village) the hunched creature sometimes stands behind a house, leaning out from
 * its corner. Look at it for 10 seconds and it turns into the bipedal stalker (bone crack) and attacks.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class VillageEvents {
    private static final Map<UUID, Long> NEXT = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.HOUSE_ENABLED.get()) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        if (!level.isVillage(p.blockPosition())) {
            return;
        }
        long now = level.getGameTime();
        long avg = StalkerConfig.HOUSE_MINUTES.get() * 1200L;
        long next = NEXT.computeIfAbsent(p.getUUID(), k -> now + avg / 2 + level.random.nextInt((int) Math.max(1, avg)));
        if (now < next) {
            return;
        }
        boolean ok = !alreadyThere(p, level) && spawn(p, level);
        NEXT.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1, avg)) : 400L));
    }

    private static boolean alreadyThere(ServerPlayer p, ServerLevel level) {
        for (BipedalEntity e : level.getEntitiesOfClass(BipedalEntity.class, p.getBoundingBox().inflate(100.0D))) {
            if (e.getKind() == BipedalEntity.HOUSE) {
                return true;
            }
        }
        return false;
    }

    private static boolean solid(ServerLevel level, BlockPos pos) {
        return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    /** Ground height (the first free block) of a column outdoors. */
    private static int ground(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    /**
     * Looks for the corner of a building in front of the player: a column at least 3 blocks higher than the open
     * ground just to its right. The creature stands a little behind the corner, its left edge touching the wall, so it
     * seems to lean out from behind the house.
     */
    public static boolean spawn(ServerPlayer p, ServerLevel level) {
        RandomSource r = level.random;
        Vec3 eye = p.getEyePosition();
        for (int i = 0; i < 80; i++) {
            double dist = 12 + r.nextInt(17);
            double a = Math.toRadians(p.getYRot() + (r.nextDouble() - 0.5D) * 90.0D);
            int x = Mth.floor(p.getX() - Math.sin(a) * dist);
            int z = Mth.floor(p.getZ() + Math.cos(a) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
                continue;
            }
            double dx = x + 0.5D - p.getX();
            double dz = z + 0.5D - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            dx /= len;
            dz /= len;
            double rx = -dz; // to the player's right
            double rz = dx;

            // the spot beside the corner, a bit behind the near wall
            double sx = x + 0.5D + rx * (0.5D + BipedalEntity.HOUSE_W / 2.0D) + dx * 1.5D;
            double sz = z + 0.5D + rz * (0.5D + BipedalEntity.HOUSE_W / 2.0D) + dz * 1.5D;
            int gx = Mth.floor(sx);
            int gz = Mth.floor(sz);
            int g = ground(level, gx, gz);
            int top = ground(level, x, z);
            if (top - g < 3 || Math.abs(g - p.getY()) > 8) {
                continue; // not a building, or too far up or down
            }
            BlockPos wallBase = new BlockPos(x, g, z);
            if (!solid(level, wallBase) || !solid(level, wallBase.above()) || !solid(level, wallBase.above(2))) {
                continue; // the column must be a real wall from the ground up
            }
            BlockPos spot = new BlockPos(gx, g, gz);
            if (solid(level, spot) || solid(level, spot.above()) || solid(level, spot.above(2))
                    || !solid(level, spot.below()) || !level.getFluidState(spot.below()).isEmpty()) {
                continue;
            }
            // the right side of the picture must be visible from the player
            Vec3 aim = new Vec3(sx + rx * 0.4D, g + 1.8D, sz + rz * 0.4D);
            if (level.clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p))
                    .getType() != HitResult.Type.MISS) {
                continue;
            }
            BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
            if (e == null) {
                return false;
            }
            e.setup(BipedalEntity.HOUSE, p.getUUID());
            e.setPos(sx, g, sz);
            level.addFreshEntity(e);
            return true;
        }
        return false;
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("houseWatcher").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawn(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No house corner found in front of you. Face a building 12-28 blocks away."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd));
    }
}
