package com.example.goatstalker;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GoatStalkerMod.MODID);

    public static final RegistryObject<EntityType<StalkerEntity>> STALKER = ENTITIES.register("goat_stalker",
            () -> EntityType.Builder.of(StalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.9F)
                    .clientTrackingRange(12)
                    .build("goat_stalker"));

    public static final RegistryObject<EntityType<StalkerPartEntity>> PART = ENTITIES.register("stalker_part",
            () -> EntityType.Builder.<StalkerPartEntity>of(StalkerPartEntity::new, MobCategory.MISC)
                    .sized(0.8F, 1.6F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .noSave()
                    .build("stalker_part"));

    public static final RegistryObject<EntityType<BipedalEntity>> BIPEDAL = ENTITIES.register("bipedal_stalker",
            () -> EntityType.Builder.<BipedalEntity>of(BipedalEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.0F)
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .noSave()
                    .build("bipedal_stalker"));

    public static final RegistryObject<EntityType<BipedalMobEntity>> BIPEDAL_MOB = ENTITIES.register("bipedal_stalker_mob",
            () -> EntityType.Builder.of(BipedalMobEntity::new, MobCategory.MONSTER)
                    .sized(1.2F, 5.2F)
                    .clientTrackingRange(10)
                    .build("bipedal_stalker_mob"));
}
