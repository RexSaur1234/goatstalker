package com.example.goatstalker;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GoatStalkerMod.MODID);

    public static final RegistryObject<EntityType<StalkerEntity>> STALKER = ENTITIES.register("goat_stalker",
            () -> EntityType.Builder.of(StalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.9F)
                    .clientTrackingRange(12)
                    .build("goat_stalker"));

    public static final RegistryObject<EntityType<StalkerPartEntity>> PART = ENTITIES.register("stalker_part",
            () -> EntityType.Builder.<StalkerPartEntity>of(StalkerPartEntity::new, MobCategory.MISC)
                    .sized(0.8F, 1.6F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .noSave()
                    .build("stalker_part"));

    public static final RegistryObject<EntityType<BipedalEntity>> BIPEDAL = ENTITIES.register("bipedal_stalker",
            () -> EntityType.Builder.<BipedalEntity>of(BipedalEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.0F)
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .noSave()
                    .build("bipedal_stalker"));

    public static final RegistryObject<EntityType<BipedalMobEntity>> BIPEDAL_MOB = ENTITIES.register("bipedal_stalker_mob",
            () -> EntityType.Builder.of(BipedalMobEntity::new, MobCategory.MONSTER)
                    .sized(1.2F, 5.2F)
                    .clientTrackingRange(10)
                    .build("bipedal_stalker_mob"));

    public static final RegistryObject<EntityType<EvilDarkTormentorEntity>> EVIL_TORMENTOR = ENTITIES.register("evil_dark_tormentor",
            () -> EntityType.Builder.of(EvilDarkTormentorEntity::new, MobCategory.MONSTER)
                    .sized(1.2F, 8.4F)
                    .clientTrackingRange(12)
                    .build("evil_dark_tormentor"));

    public static final RegistryObject<EntityType<BipedalStalker2Entity>> BIPEDAL_2 = ENTITIES.register("bipedal_stalker_2",
            () -> EntityType.Builder.of(BipedalStalker2Entity::new, MobCategory.MONSTER)
                    .sized(0.9F, 6.2F)
                    .clientTrackingRange(10)
                    .build("bipedal_stalker_2"));

    /** The model is ~25 blocks tall; the hitbox is smaller so that it can still find its way through the world. */
    public static final RegistryObject<EntityType<SufferingEntity>> SUFFERING = ENTITIES.register("sufferings",
            () -> EntityType.Builder.of(SufferingEntity::new, MobCategory.MONSTER)
                    .sized(2.0F, 9.0F)
                    .clientTrackingRange(20)
                    .build("sufferings"));

    public static final RegistryObject<EntityType<AnguishEntity>> ANGUISH = ENTITIES.register("anguish",
            () -> EntityType.Builder.of(AnguishEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 4.4F)
                    .clientTrackingRange(10)
                    .build("anguish"));

    public static final RegistryObject<EntityType<QuadrupedStalkerEntity>> QUADRUPED = ENTITIES.register("quadruped_stalker",
            () -> EntityType.Builder.of(QuadrupedStalkerEntity::new, MobCategory.MONSTER)
                    .sized(1.4F, 3.8F)
                    .clientTrackingRange(10)
                    .build("quadruped_stalker"));

    public static final RegistryObject<EntityType<TormentorEntity>> TORMENTOR = ENTITIES.register("tormentor",
            () -> EntityType.Builder.of(TormentorEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 5.4F)
                    .clientTrackingRange(10)
                    .build("tormentor"));
}
