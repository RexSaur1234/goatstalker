package com.example.goatstalker;

import org.joml.Vector3f;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

/** Blood: dark red dust and red "chunks" (redstone block particles). */
public final class Blood {
    private static final DustParticleOptions DARK = new DustParticleOptions(new Vector3f(0.45F, 0.0F, 0.0F), 2.0F);
    private static final DustParticleOptions BRIGHT = new DustParticleOptions(new Vector3f(0.75F, 0.02F, 0.02F), 1.4F);
    private static final BlockParticleOption CHUNKS =
            new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState());

    private Blood() {
    }

    public static void spray(ServerLevel level, double x, double y, double z, int amount, double spread) {
        level.sendParticles(DARK, x, y, z, amount, spread, spread, spread, 0.0D);
        level.sendParticles(BRIGHT, x, y, z, amount / 2 + 1, spread * 0.7D, spread * 0.7D, spread * 0.7D, 0.0D);
        level.sendParticles(CHUNKS, x, y, z, amount / 2 + 1, spread * 0.5D, spread * 0.5D, spread * 0.5D, 0.25D);
    }
}
