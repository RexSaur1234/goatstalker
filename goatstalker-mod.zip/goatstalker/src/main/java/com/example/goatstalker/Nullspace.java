package com.example.goatstalker;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Nullspace 1 "Island": a plain flat world, a tower at the edge of it.
 * Nullspace 2 "Village": a small finite village. Two gravel streets cross like a plus (+); houses stand along
 * all four arms and also fill the four corners between them. One special house with the exit stands at the east end.
 * The ground (grass) is at y = 3 in both worlds.
 */
public class Nullspace {
    public static final ResourceKey<Level> DIM =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(GoatStalkerMod.MODID, "village"));
    public static final ResourceKey<Level> ISLAND =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(GoatStalkerMod.MODID, "island"));

    public static final int G = 3;                 // y of the grass layer
    public static final double GROUND_TOP = 4.0D;  // y where a player stands on the ground

    // ---- Island
    public static final int TOWER_Z = 140;         // the tower stands at x=0, z=140
    public static final BlockPos GLITCH_STONE_POS = new BlockPos(0, G, TOWER_Z);

    // ---- Village
    public static final int N = 5;                 // houses along each arm, in each of the four quarters
    public static final int PITCH = 9;             // distance between house centres (7 wide + 2 gap)
    public static final int FIRST = 7;             // first house centre is 7 blocks from a street axis
    public static final int SPECIAL_X = 58;        // the special house (exit) centre: east end of the east street
    public static final BlockPos EXIT_POS = new BlockPos(SPECIAL_X, G + 1, 0);

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState COBBLE = Blocks.COBBLESTONE.defaultBlockState();
    private static final BlockState PLANKS = Blocks.OAK_PLANKS.defaultBlockState();
    private static final Direction[] LADDER_DIR = {Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.NORTH};

    public static boolean isNullspace(ResourceKey<Level> key) {
        return key == DIM || key == ISLAND;
    }

    /** Centres {x, z} of all ordinary houses of the village. */
    public static List<int[]> houseCenters() {
        List<int[]> list = new ArrayList<>();
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                for (int i = 0; i < N; i++) {
                    for (int j = 0; j < N; j++) {
                        list.add(new int[] {sx * (FIRST + PITCH * i), sz * (FIRST + PITCH * j)});
                    }
                }
            }
        }
        return list;
    }

    // =========================================================================================
    // Village
    // =========================================================================================
    /** Builds the village the first time somebody comes (the exit block is placed last as a marker). */
    public static void ensureBuilt(ServerLevel l) {
        if (l.getBlockState(EXIT_POS).is(ModBlocks.EXIT.get())) {
            return;
        }
        List<BlockPos> refresh = new ArrayList<>();
        RandomSource r = RandomSource.create(1234L);
        int reach = FIRST + PITCH * (N - 1) + 4; // 47

        // the plus: a street along Z (x -2..2) and a street along X (z -2..2), the east one goes up to the special house
        for (int z = -reach; z <= reach; z++) {
            for (int x = -2; x <= 2; x++) {
                street(l, x, z, r);
            }
        }
        for (int x = -reach; x <= SPECIAL_X - 5; x++) {
            for (int z = -2; z <= 2; z++) {
                street(l, x, z, r);
            }
        }
        // houses in all four quarters (this also fills the empty corners of the plus)
        for (int[] c : houseCenters()) {
            house(l, c[0], c[1], doorRotation(c[0], c[1]), refresh);
        }
        specialHouse(l, refresh);

        // second pass: fences, glass panes and stairs connect to their neighbours
        for (BlockPos p : refresh) {
            l.setBlock(p, Block.updateFromNeighbourShapes(l.getBlockState(p), l, p), 2);
        }
        l.setBlock(EXIT_POS, ModBlocks.EXIT.get().defaultBlockState(), 3);
    }

    private static void street(ServerLevel l, int x, int z, RandomSource r) {
        set(l, x, G, z, r.nextInt(5) == 0 ? COBBLE : Blocks.GRAVEL.defaultBlockState());
    }

    /** 0 = door to the east (+x), 1 = south (+z), 2 = west (-x), 3 = north (-z): toward the nearer street. */
    private static int doorRotation(int cx, int cz) {
        if (Math.abs(cx) <= Math.abs(cz)) {
            return cx < 0 ? 0 : 2;
        }
        return cz < 0 ? 1 : 3;
    }

    // local house coordinates (u, v), both -3..3, door on u = +3; rotated into the world by r
    private static int wx(int cx, int u, int v, int r) {
        return cx + switch (r) {
            case 0 -> u;
            case 1 -> -v;
            case 2 -> -u;
            default -> v;
        };
    }

    private static int wz(int cz, int u, int v, int r) {
        return cz + switch (r) {
            case 0 -> v;
            case 1 -> u;
            case 2 -> -v;
            default -> -u;
        };
    }

    /** 7x7 house with a door, windows, a ladder to a flat roof with a fence, and a torch inside. */
    private static void house(ServerLevel l, int cx, int cz, int r, List<BlockPos> refresh) {
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();

        for (int u = -3; u <= 3; u++) {
            for (int v = -3; v <= 3; v++) {
                int x = wx(cx, u, v, r);
                int z = wz(cz, u, v, r);
                boolean perim = Math.abs(u) == 3 || Math.abs(v) == 3;
                boolean corner = Math.abs(u) == 3 && Math.abs(v) == 3;
                set(l, x, G, z, COBBLE);
                for (int y = G + 1; y <= G + 3; y++) {
                    BlockState s = !perim ? AIR : corner ? COBBLE : (y == G + 1 ? COBBLE : PLANKS);
                    set(l, x, y, z, s);
                }
                set(l, x, G + 4, z, perim ? log : PLANKS);
                if (perim) {
                    setRefresh(l, x, G + 5, z, fence, refresh);
                }
            }
        }
        // door (an open doorway) and windows
        set(l, wx(cx, 3, 0, r), G + 1, wz(cz, 3, 0, r), AIR);
        set(l, wx(cx, 3, 0, r), G + 2, wz(cz, 3, 0, r), AIR);
        setRefresh(l, wx(cx, -3, 0, r), G + 2, wz(cz, -3, 0, r), pane, refresh);
        setRefresh(l, wx(cx, 0, 3, r), G + 2, wz(cz, 0, 3, r), pane, refresh);
        setRefresh(l, wx(cx, 0, -3, r), G + 2, wz(cz, 0, -3, r), pane, refresh);
        // ladder up to the roof (attached to the back wall)
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, LADDER_DIR[r]);
        for (int y = G + 1; y <= G + 4; y++) {
            set(l, wx(cx, -2, -2, r), y, wz(cz, -2, -2, r), ladder);
        }
        set(l, wx(cx, 2, 2, r), G + 1, wz(cz, 2, 2, r), Blocks.TORCH.defaultBlockState());
    }

    /** The only house with the exit: cobblestone gable roof, bookshelves, the exit block in the middle. */
    private static void specialHouse(ServerLevel l, List<BlockPos> refresh) {
        int cx = SPECIAL_X;
        int cz = 0;
        int x0 = cx - 4, x1 = cx + 4, z0 = cz - 4, z1 = cz + 4;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean perim = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                set(l, x, G, z, COBBLE);
                for (int y = G + 1; y <= G + 4; y++) {
                    BlockState s = !perim ? AIR : corner ? COBBLE : (y <= G + 2 ? COBBLE : PLANKS);
                    set(l, x, y, z, s);
                }
            }
        }
        // door in the west wall (toward the street), windows in the other walls
        set(l, x0, G + 1, cz, AIR);
        set(l, x0, G + 2, cz, AIR);
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();
        setRefresh(l, x1, G + 3, cz, pane, refresh);
        setRefresh(l, cx, G + 3, z0, pane, refresh);
        setRefresh(l, cx, G + 3, z1, pane, refresh);
        setRefresh(l, x0, G + 3, cz - 2, pane, refresh);
        setRefresh(l, x0, G + 3, cz + 2, pane, refresh);

        // gable roof made of stairs (the ridge runs along Z), with cobblestone gable ends
        for (int k = 0; k <= 5; k++) {
            int y = G + 5 + k;
            for (int x = cx - 5 + k; x <= cx + 5 - k; x++) {
                for (int z = cz - 5; z <= cz + 5; z++) {
                    boolean edgeZ = z == cz - 5 || z == cz + 5;
                    if (k < 5 && x == cx - 5 + k) {
                        setRefresh(l, x, y, z, stairs(Direction.EAST), refresh);
                    } else if (k < 5 && x == cx + 5 - k) {
                        setRefresh(l, x, y, z, stairs(Direction.WEST), refresh);
                    } else {
                        set(l, x, y, z, (k < 5 && edgeZ) ? COBBLE : PLANKS);
                    }
                }
            }
        }

        // interior: bookshelves, crafting table, torches
        BlockState books = Blocks.BOOKSHELF.defaultBlockState();
        for (int z = cz - 3; z <= cz + 3; z++) {
            set(l, cx + 3, G + 1, z, books);
            set(l, cx + 3, G + 2, z, books);
        }
        for (int x = cx - 2; x <= cx + 2; x++) {
            set(l, x, G + 1, cz - 3, books);
            set(l, x, G + 2, cz - 3, books);
            set(l, x, G + 1, cz + 3, books);
            set(l, x, G + 2, cz + 3, books);
        }
        set(l, cx - 2, G + 1, cz - 2, Blocks.CRAFTING_TABLE.defaultBlockState());
        BlockState torch = Blocks.TORCH.defaultBlockState();
        set(l, cx + 3, G + 3, cz - 3, torch);
        set(l, cx + 3, G + 3, cz + 3, torch);
        set(l, cx - 2, G + 3, cz - 3, torch);
        set(l, cx - 2, G + 3, cz + 3, torch);
    }

    private static BlockState stairs(Direction facing) {
        return Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, facing);
    }

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 2);
    }

    private static void setRefresh(ServerLevel l, int x, int y, int z, BlockState s, List<BlockPos> refresh) {
        set(l, x, y, z, s);
        refresh.add(new BlockPos(x, y, z));
    }

    // =========================================================================================
    // Island
    // =========================================================================================
    /** Island (Nullspace 1): a plain flat world, a tower far away, a stone path leading to it. */
    public static void ensureIslandBuilt(ServerLevel l) {
        if (l.getBlockState(GLITCH_STONE_POS).is(ModBlocks.GLITCH_STONE.get())) {
            return;
        }
        RandomSource r = RandomSource.create(4321L);
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState pale = Blocks.DIORITE.defaultBlockState();
        int x0 = -4, x1 = 4, z0 = TOWER_Z - 4, z1 = TOWER_Z + 4;
        int height = 22;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean perim = x == x0 || x == x1 || z == z0 || z == z1;
                set(l, x, G, z, Blocks.SMOOTH_STONE.defaultBlockState());
                for (int y = G + 1; y <= G + height; y++) {
                    BlockState s;
                    if (!perim) {
                        s = AIR;
                    } else if (y <= G + 4) {
                        s = pale;
                    } else {
                        s = r.nextInt(3) == 0 ? COBBLE : brick;
                    }
                    set(l, x, y, z, s);
                }
                if (perim && (x + z) % 2 == 0) { // battlements on top
                    set(l, x, G + height + 1, z, brick);
                }
            }
        }
        for (int y = G + 1; y <= G + 3; y++) { // door in the south wall (the side you come from)
            set(l, 0, y, z0, AIR);
        }
        for (int y = G + 7; y <= G + 19; y += 4) { // irregular windows
            set(l, x0, y, TOWER_Z + r.nextInt(5) - 2, AIR);
            set(l, x1, y, TOWER_Z + r.nextInt(5) - 2, AIR);
            set(l, r.nextInt(5) - 2, y, z1, AIR);
            set(l, r.nextInt(5) - 2, y, z0, AIR);
        }
        for (int i = 0; i < 14; i++) { // blocks sticking out of the walls
            int y = G + 5 + r.nextInt(height - 5);
            int off = r.nextInt(7) - 3;
            switch (r.nextInt(4)) {
                case 0 -> set(l, x0 - 1, y, TOWER_Z + off, COBBLE);
                case 1 -> set(l, x1 + 1, y, TOWER_Z + off, COBBLE);
                case 2 -> set(l, off, y, z0 - 1, COBBLE);
                default -> set(l, off, y, z1 + 1, COBBLE);
            }
        }
        for (int z = z0 - 40; z < z0; z++) { // stone path from the tower door out into the field
            for (int x = -1; x <= 1; x++) {
                set(l, x, G, z, Blocks.ANDESITE.defaultBlockState());
            }
        }
        // the glowing broken stone in the middle (placed last: it is also the "already built" marker)
        l.setBlock(GLITCH_STONE_POS, ModBlocks.GLITCH_STONE.get().defaultBlockState(), 3);
    }
}
