package com.example.goatstalker.client;

import org.lwjgl.glfw.GLFW;

import com.example.goatstalker.Crawl;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The "Crawl" key (C by default; it can be changed in Options - Controls - Key Binds - Goat Stalker). */
public class CrawlKey {
    public static final KeyMapping KEY = new KeyMapping("key.goatstalker.crawl", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_C, "key.categories.goatstalker");

    @Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModEvents {
        @SubscribeEvent
        public static void onKeys(RegisterKeyMappingsEvent event) {
            event.register(KEY);
        }
    }

    @Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID, value = Dist.CLIENT)
    public static class GameEvents {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) {
                Crawl.clientCrawling = false;
                return;
            }
            Crawl.clientPlayerId = mc.player.getUUID();
            while (KEY.consumeClick()) {
                Crawl.clientCrawling = !Crawl.clientCrawling;
                Crawl.CHANNEL.sendToServer(new Crawl.Toggle(Crawl.clientCrawling));
                mc.player.displayClientMessage(Component.translatable(
                        Crawl.clientCrawling ? "message.goatstalker.crawl_on" : "message.goatstalker.crawl_off"), true);
            }
        }
    }
}
