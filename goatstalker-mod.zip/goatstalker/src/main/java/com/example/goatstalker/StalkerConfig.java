package com.example.goatstalker;

import net.minecraftforge.common.ForgeConfigSpec;

public class StalkerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue HAUNTS_ENABLED;
    public static final ForgeConfigSpec.BooleanValue DAY_WATCHERS;
    public static final ForgeConfigSpec.BooleanValue EYE_CONTACT_KILL;
    public static final ForgeConfigSpec.IntValue AVERAGE_SECONDS;
    public static final ForgeConfigSpec.IntValue EYE_CONTACT_TICKS;
    public static final ForgeConfigSpec.IntValue LIFETIME_SECONDS;
    public static final ForgeConfigSpec.IntValue HEAD_CHANCE;
    public static final ForgeConfigSpec.IntValue HAND_CHANCE;
    public static final ForgeConfigSpec.BooleanValue TREE_ENABLED;
    public static final ForgeConfigSpec.IntValue TREE_MINUTES;
    public static final ForgeConfigSpec.BooleanValue NULLSPACE_ENABLED;
    public static final ForgeConfigSpec.IntValue NULLSPACE_MINUTES;
    public static final ForgeConfigSpec.IntValue NULLSPACE_MAX_STAY_MINUTES;
    public static final ForgeConfigSpec.BooleanValue GLITCH_ENABLED;
    public static final ForgeConfigSpec.IntValue GLITCH_MINUTES;
    public static final ForgeConfigSpec.BooleanValue ONLOOKER_ENABLED;
    public static final ForgeConfigSpec.IntValue ONLOOKER_MINUTES;
    public static final ForgeConfigSpec.BooleanValue BIPEDAL_MOB_ENABLED;
    public static final ForgeConfigSpec.IntValue BIPEDAL_MOB_MINUTES;
    public static final ForgeConfigSpec.BooleanValue SHAFT_ENABLED;
    public static final ForgeConfigSpec.IntValue SHAFT_GOAT_PERCENT;
    public static final ForgeConfigSpec.IntValue SHAFT_FACE_PERCENT;
    public static final ForgeConfigSpec.BooleanValue CAVE_ENABLED;
    public static final ForgeConfigSpec.IntValue CAVE_MINUTES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        HAUNTS_ENABLED = b.comment("Enable automatic haunts (stalker appears on its own)")
                .define("hauntsEnabled", true);
        AVERAGE_SECONDS = b.comment("Average seconds between haunts for each player")
                .defineInRange("averageSecondsBetweenHaunts", 180, 10, 36000);
        DAY_WATCHERS = b.comment("During the day the stalker appears far away and only watches")
                .define("daytimeWatchers", true);
        EYE_CONTACT_KILL = b.comment("The hunting stalker kills a player who keeps looking at it")
                .define("eyeContactKills", true);
        EYE_CONTACT_TICKS = b.comment("How many ticks of looking at it are needed to die (20 ticks = 1 second)")
                .defineInRange("eyeContactTicks", 40, 1, 1200);
        LIFETIME_SECONDS = b.comment("Stalker disappears after this many seconds (0 = never)")
                .defineInRange("lifetimeSeconds", 90, 0, 36000);
        HEAD_CHANCE = b.comment("Percent chance that the head shows up under the ceiling during a night haunt (player must be indoors)")
                .defineInRange("ceilingHeadChancePercent", 80, 0, 100);
        HAND_CHANCE = b.comment("Percent chance that the hand shows up in a window before the stalker appears")
                .defineInRange("windowHandChancePercent", 70, 0, 100);
        TREE_ENABLED = b.comment("The creature peeks from behind a tree every few minutes")
                .define("treeEventEnabled", true);
        TREE_MINUTES = b.comment("Minutes between tree events")
                .defineInRange("treeEventMinutes", 10, 1, 600);
        NULLSPACE_ENABLED = b.comment("Teleport the player to Nullspace 2 (the village) every few minutes")
                .define("nullspaceEnabled", true);
        NULLSPACE_MINUTES = b.comment("Minutes between teleports to Nullspace 2")
                .defineInRange("nullspaceMinutes", 10, 1, 600);
        NULLSPACE_MAX_STAY_MINUTES = b.comment("If the player does not leave Nullspace 2 by himself, he is sent back after this many minutes")
                .defineInRange("nullspaceMaxStayMinutes", 15, 1, 600);
        GLITCH_ENABLED = b.comment("A glowing glitched grass block sometimes appears near the player and leads to Nullspace 1 (Island)")
                .define("glitchGrassEnabled", true);
        GLITCH_MINUTES = b.comment("Average minutes between glitched grass blocks (the real time is random, 0.5x to 1.5x)")
                .defineInRange("glitchGrassMinutes", 15, 1, 600);
        ONLOOKER_ENABLED = b.comment("The Onlooker stands in the distance and calls 'hey' until you look at it")
                .define("onlookerEnabled", true);
        ONLOOKER_MINUTES = b.comment("Average minutes between Onlooker appearances (real time is 0.5x to 1.5x)")
                .defineInRange("onlookerMinutes", 12, 1, 600);
        BIPEDAL_MOB_ENABLED = b.comment("The real bipedal stalker (200 health) sometimes appears in the normal world and hunts you")
                .define("bipedalStalkerEnabled", true);
        BIPEDAL_MOB_MINUTES = b.comment("Average minutes between bipedal stalker appearances (it stays about 8 minutes)")
                .defineInRange("bipedalStalkerMinutes", 30, 1, 600);
        SHAFT_ENABLED = b.comment("Heads peek over the top of the shaft when you dig straight down")
                .define("shaftEventsEnabled", true);
        SHAFT_GOAT_PERCENT = b.comment("Chance (percent) that the goat head appears at the top of a shaft that is 8+ blocks deep")
                .defineInRange("shaftGoatHeadPercent", 30, 0, 100);
        SHAFT_FACE_PERCENT = b.comment("Chance (percent) that the little stalker's face watches you when you look up out of a deep shaft")
                .defineInRange("shaftFacePercent", 20, 0, 100);
        CAVE_ENABLED = b.comment("Rarely, in mines, the creature leans out from behind a corner (like the one behind the tree)")
                .define("caveCornerEnabled", true);
        CAVE_MINUTES = b.comment("Average minutes between corner appearances while you are underground")
                .defineInRange("caveCornerMinutes", 14, 1, 600);
        SPEC = b.build();
    }
}
