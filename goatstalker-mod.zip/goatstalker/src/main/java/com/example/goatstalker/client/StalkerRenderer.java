package com.example.goatstalker.client;

import java.util.Set;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.StalkerEntity;
import com.example.goatstalker.TormentorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The Goat Stalker: the Tormentor's model and animations with the goat's head, about 3 blocks tall. */
public class StalkerRenderer extends EntityRenderer<StalkerEntity> {
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/goat_stalker_model.png");
    /** 6.8 blocks in Blockbench -> about 3 blocks. */
    public static final float MODEL_SCALE = 0.441F;
    private static final Set<String> HIDDEN = Set.of("crawl_head");
    private static final Set<String> HIDDEN_CRAWL = Set.of("head", "neck");
    private static final Set<String> HIDDEN_HEADLESS = Set.of("head", "neck", "crawl_head");

    public StalkerRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(StalkerEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the model's front (+X) looks where the goat looks
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, TormentorEntity.ANIM_NAMES.length - 1);
        String anim = TormentorEntity.ANIM_NAMES[index];
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        Set<String> hidden = HIDDEN;
        if (entity.isCrawling()) {
            anim = "crawl";
            seconds = (entity.tickCount + partialTick) / 20.0F;
            hidden = HIDDEN_CRAWL;
        }
        if (entity.isHeadless()) {
            hidden = HIDDEN_HEADLESS;
        }
        TormentorRenderer.MODEL.render(pose, vc, anim, seconds, light, OverlayTexture.NO_OVERLAY, hidden);
        pose.popPose();
        super.render(entity, yaw, partialTick, pose, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerEntity entity) {
        return TEXTURE;
    }
}
