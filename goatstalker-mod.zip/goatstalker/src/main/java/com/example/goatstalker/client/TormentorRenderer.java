package com.example.goatstalker.client;

import java.util.Set;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.TormentorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * The Tormentor: the StalkerGoat model (a flat figure in the YZ plane, its front is +X) with its animations.
 * The second head ("crawl_head") belongs to the crawling animations only and is never drawn.
 */
public class TormentorRenderer extends EntityRenderer<TormentorEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/tormentor.png");
    private static final ResourceLocation TEXTURE_ONE_HORN =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/tormentor_one_horn.png");
    /** The StalkerGoat model, shared by the Tormentor, the Evil Dark Tormentor and the Goat Stalker. */
    public static final SkeletalModel MODEL = new SkeletalModel("tormentor/model.json", "tormentor/animations.json");
    private static final ResourceLocation TEXTURE_NO_HORNS =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/tormentor_no_horns.png");
    private static final Set<String> HIDDEN = Set.of("crawl_head");
    /** Crawling it uses the second head that lies on its body; the normal neck and head are not drawn. */
    private static final Set<String> HIDDEN_CRAWL = Set.of("head", "neck");

    /** The model is 6.8 blocks tall in Blockbench; 0.8 makes it about 5.4 blocks. */
    private static final float MODEL_SCALE = 0.8F;

    public TormentorRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(TormentorEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-yaw - 90.0F)); // the model's front (+X) looks where the entity looks
        if (entity.isFallen()) { // lies on its back
            pose.translate(0.0D, 0.3D, 0.0D);
            pose.mulPose(Axis.ZP.rotationDegrees(90.0F));
        }
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.XP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        int index = Mth.clamp(entity.getAnim(), 0, TormentorEntity.ANIM_NAMES.length - 1);
        String anim = TormentorEntity.ANIM_NAMES[index];
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        Set<String> hidden = HIDDEN;
        if (entity.isCrawling()) {
            anim = "crawl";
            seconds = (entity.tickCount + partialTick) / 20.0F;
            hidden = HIDDEN_CRAWL;
        }
        int lost = entity.getLost();
        if (lost != 0) { // parts torn off by the Evil Dark Tormentor
            Set<String> h = new java.util.HashSet<>(hidden);
            if ((lost & TormentorEntity.LOST_ARM_L) != 0) {
                h.add("arm_l");
            }
            if ((lost & TormentorEntity.LOST_ARM_R) != 0) {
                h.add("arm_r");
            }
            if ((lost & TormentorEntity.LOST_LEGS) != 0) {
                h.add("leg_l");
                h.add("leg_r");
            }
            if ((lost & TormentorEntity.LOST_HEAD) != 0) {
                h.add("head");
                h.add("crawl_head");
            }
            hidden = h;
        }
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, anim, seconds, light, overlay, hidden);
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(TormentorEntity entity) {
        return entity.hasNoHorns() ? TEXTURE_NO_HORNS : entity.hasOneHorn() ? TEXTURE_ONE_HORN : TEXTURE;
    }
}
