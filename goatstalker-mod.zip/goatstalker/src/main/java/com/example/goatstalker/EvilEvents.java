package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The Evil Dark Tormentor comes every 40 minutes (40-55 blocks from the player) and stays about 10 minutes. */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class EvilEvents {
    private static final Map<UUID, Long> NEXT = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.EVIL_ENABLED.get()) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long now = level.getGameTime();
        long every = StalkerConfig.EVIL_MINUTES.get() * 1200L;
        long next = NEXT.computeIfAbsent(p.getUUID(), k -> now + every);
        if (now < next) {
            return;
        }
        boolean ok = level.getEntitiesOfClass(EvilDarkTormentorEntity.class, p.getBoundingBox().inflate(200.0D)).isEmpty()
                && spawnNear(p, level) != null;
        NEXT.put(p.getUUID(), now + (ok ? every : 1200L));
    }

    private static Vec3 ground(ServerLevel level, double x, double z) {
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
        return new Vec3(x, y, z);
    }

    static EvilDarkTormentorEntity spawnNear(ServerPlayer p, ServerLevel level) {
        for (int i = 0; i < 20; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0D;
            double d = 40.0D + level.random.nextDouble() * 15.0D;
            Vec3 at = ground(level, p.getX() + Math.cos(a) * d, p.getZ() + Math.sin(a) * d);
            if (Math.abs(at.y - p.getY()) > 20.0D || !level.getFluidState(net.minecraft.core.BlockPos.containing(at).below()).isEmpty()) {
                continue;
            }
            EvilDarkTormentorEntity e = ModEntities.EVIL_TORMENTOR.get().create(level);
            if (e == null) {
                return null;
            }
            e.moveTo(at.x, at.y, at.z, level.random.nextFloat() * 360.0F, 0.0F);
            e.setTimedLife(12000);
            if (!p.isCreative() && !p.isSpectator()) {
                e.setTarget(p);
            }
            level.addFreshEntity(e);
            return e;
        }
        return null;
    }

    // ------------------------------ commands (tests) ------------------------------
    private static Vec3 ahead(ServerPlayer p, double dist, double side) {
        double a = Math.toRadians(p.getYRot());
        double fx = -Math.sin(a);
        double fz = Math.cos(a);
        return ground(p.serverLevel(), p.getX() + fx * dist - fz * side, p.getZ() + fz * dist + fx * side);
    }

    private static <T extends Mob> T put(ServerLevel level, T m, Vec3 at, float yaw) {
        m.moveTo(at.x, at.y, at.z, yaw, 0.0F);
        level.addFreshEntity(m);
        return m;
    }

    /** /goatstalker evilBattle bipedal|tormentor|goat|two|three: the Evil Dark Tormentor and its enemies, fight now. */
    private static LiteralArgumentBuilder<CommandSourceStack> battle(String name, boolean bip, boolean tor, boolean goat) {
        return Commands.literal(name).executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            float back = p.getYRot() + 180.0F;
            EvilDarkTormentorEntity e = put(level, ModEntities.EVIL_TORMENTOR.get().create(level), ahead(p, 30.0D, 0.0D), back);
            BipedalMobEntity b = bip ? put(level, ModEntities.BIPEDAL_MOB.get().create(level), ahead(p, 16.0D, -4.0D), p.getYRot()) : null;
            TormentorEntity t = tor ? put(level, ModEntities.TORMENTOR.get().create(level), ahead(p, 16.0D, 4.0D), p.getYRot()) : null;
            StalkerEntity g = null;
            if (goat) {
                g = put(level, ModEntities.STALKER.get().create(level), ahead(p, 14.0D, 0.0D), p.getYRot());
                g.setHunting(false);
            }
            e.startTestFight(b, t, g);
            return 1;
        });
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var spawn = Commands.literal("evilTormentor").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            EvilDarkTormentorEntity e = put(level, ModEntities.EVIL_TORMENTOR.get().create(level), ahead(p, 20.0D, 0.0D),
                    p.getYRot() + 180.0F);
            e.setTimedLife(12000);
            return 1;
        });
        var battle = Commands.literal("evilBattle")
                .then(battle("bipedal", true, false, false))
                .then(battle("tormentor", false, true, false))
                .then(battle("goat", false, false, true))
                .then(battle("two", true, true, false))
                .then(battle("three", true, true, true));
        var b2 = Commands.literal("bipedal2").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            put(level, ModEntities.BIPEDAL_2.get().create(level), ahead(p, 14.0D, 0.0D), p.getYRot() + 180.0F);
            return 1;
        });
        var b2goat = Commands.literal("bipedal2Goat").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ServerLevel level = p.serverLevel();
            put(level, ModEntities.BIPEDAL_2.get().create(level), ahead(p, 20.0D, 3.0D), p.getYRot() + 180.0F);
            StalkerEntity g = put(level, ModEntities.STALKER.get().create(level), ahead(p, 12.0D, -2.0D), p.getYRot());
            g.setHunting(false);
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(spawn).then(battle).then(b2).then(b2goat));
    }
}
