package com.example.goatstalker.client;

import java.util.Collections;

import com.example.goatstalker.AnguishEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Anguish: the player's Blockbench model (StalkerAnsiedad.geo.json), 4.5 blocks tall, front -Z. */
public class AnguishRenderer extends EntityRenderer<AnguishEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/anguish.png");
    public static final SkeletalModel MODEL = new SkeletalModel("anguish/model.json", "anguish/animations.json");

    public AnguishRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.6F;
    }

    @Override
    public void render(AnguishEntity entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw)); // the model's front is -Z
        if (entity.deathTime > 0) {
            float f = Math.min(1.0F, Mth.sqrt(((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F));
            pose.mulPose(Axis.ZP.rotationDegrees(f * 90.0F));
        }
        float s = 1.0F / 16.0F;
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int index = Mth.clamp(entity.getAnim(), 0, AnguishEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F), OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        MODEL.render(pose, vc, AnguishEntity.ANIM_NAMES[index], seconds, light, overlay, Collections.emptySet());
        pose.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(AnguishEntity entity) {
        return TEXTURE;
    }
}
