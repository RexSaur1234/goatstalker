package com.example.goatstalker.client;

import com.example.goatstalker.BipedalEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * TREE, ROOF, ONLOOKER and the goat halves are flat pictures that face the camera (feet at the entity position).
 * RUNNER is the 3D model StalkerRun with the "terror" (run) and "grito" (roar) animations.
 */
public class BipedalRenderer extends EntityRenderer<BipedalEntity> {
    private static final ResourceLocation TREE_TEX = tex("bipedal_tree");
    private static final ResourceLocation ROOF_TEX = tex("bipedal_roof");
    private static final ResourceLocation ONLOOKER_TEX = tex("onlooker");
    private static final ResourceLocation GOAT_TOP_TEX = tex("goat_top");
    private static final ResourceLocation GOAT_BOTTOM_TEX = tex("goat_bottom");
    private static final ResourceLocation CAVE_TEX = tex("cave_corner");
    private static final ResourceLocation SHAFT_GOAT_TEX = tex("shaft_goat");
    private static final ResourceLocation SHAFT_FACE_TEX = tex("shaft_face");
    private static final ResourceLocation DOOR_TEX = tex("door_creature");
    private static final ResourceLocation WINDOW_TEX = tex("window_creature");
    private static final ResourceLocation HOUSE_TEX = tex("house_watcher");
    private static final ResourceLocation PEEKER_TEX = tex("window_peeker");
    private static final ResourceLocation DARK_HEAD_TEX = tex("dark_door_head");
    private static final ResourceLocation DARK_HAND_TEX = tex("dark_door_hand");

    // picture sizes in blocks = height * picture ratio
    private static final float TREE_H = BipedalEntity.TREE_H, TREE_W = BipedalEntity.TREE_W;
    private static final float ROOF_H = 2.6F, ROOF_W = 2.128F;           // ratio 0.8184 (head and shoulders)
    private static final float ONLOOKER_H = 4.6F, ONLOOKER_W = 3.767F;   // ratio 0.819 (the goat and the little one)
    private static final float GOAT_W = 3.2F;                            // the goat picture is 3.2 x 3.2 blocks
    private static final float GOAT_TOP_H = 1.8125F, GOAT_BOTTOM_H = 1.3875F;
    private static final float CAVE_H = BipedalEntity.CAVE_H, CAVE_W = BipedalEntity.CAVE_W;
    private static final float SHAFT_GOAT_H = 2.6F, SHAFT_GOAT_W = 1.249F;  // ratio 0.4805
    private static final float SHAFT_FACE_H = 1.4F, SHAFT_FACE_W = 1.143F;  // ratio 0.8164

    /** 1.0 = the size drawn in Blockbench (about 6 blocks tall). Make it smaller to shrink the creature. */
    private static final float MODEL_SCALE = 1.0F;

    public BipedalRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/" + name + ".png");
    }

    @Override
    public void render(BipedalEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        int kind = entity.getKind();
        if (kind == BipedalEntity.RUNNER) {
            renderRunner(entity, yaw, partialTick, pose, buffer, light);
            return;
        }
        if (kind == BipedalEntity.DARK_DOOR) {
            renderDarkDoor(entity, partialTick, pose, buffer, light);
            return;
        }
        float w;
        float h;
        switch (kind) {
            case BipedalEntity.TREE -> { w = TREE_W; h = TREE_H; }
            case BipedalEntity.ROOF -> { w = ROOF_W; h = ROOF_H; }
            case BipedalEntity.ONLOOKER -> { w = ONLOOKER_W; h = ONLOOKER_H; }
            case BipedalEntity.GOAT_TOP -> { w = GOAT_W; h = GOAT_TOP_H; }
            case BipedalEntity.CAVE -> { w = CAVE_W; h = CAVE_H; }
            case BipedalEntity.SHAFT_GOAT -> { w = SHAFT_GOAT_W; h = SHAFT_GOAT_H; }
            case BipedalEntity.SHAFT_FACE -> { w = SHAFT_FACE_W; h = SHAFT_FACE_H; }
            case BipedalEntity.DOOR -> { w = BipedalEntity.DOOR_W; h = BipedalEntity.DOOR_H; }
            case BipedalEntity.WINDOW -> { w = BipedalEntity.WINDOW_W; h = BipedalEntity.WINDOW_H; }
            case BipedalEntity.HOUSE -> { w = BipedalEntity.HOUSE_W; h = BipedalEntity.HOUSE_H; }
            case BipedalEntity.PEEKER -> { w = BipedalEntity.PEEKER_W; h = BipedalEntity.PEEKER_H; }
            default -> { w = GOAT_W; h = GOAT_BOTTOM_H; }
        }
        // the heads over a shaft are seen from far below: they face the camera in every direction and are centred on the entity
        boolean head = kind == BipedalEntity.SHAFT_GOAT || kind == BipedalEntity.SHAFT_FACE;
        float y0 = head ? -h / 2 : 0.0F;
        float y1 = head ? h / 2 : h;
        // the door and window creatures lie flat against the wall and do not turn with the camera
        boolean wall = kind == BipedalEntity.DOOR || kind == BipedalEntity.WINDOW || kind == BipedalEntity.PEEKER;
        float anchor = kind == BipedalEntity.DOOR ? BipedalEntity.DOOR_ANCHOR
                : kind == BipedalEntity.WINDOW ? BipedalEntity.WINDOW_ANCHOR : 0.5F;
        float x0 = -w * anchor;
        float x1 = w * (1.0F - anchor);

        pose.pushPose();
        if (head) {
            pose.mulPose(this.entityRenderDispatcher.cameraOrientation());
        } else if (wall) {
            pose.mulPose(Axis.YP.rotationDegrees(180.0F - entity.getYRot()));
        } else {
            pose.mulPose(Axis.YP.rotationDegrees(180.0F - this.entityRenderDispatcher.camera.getYRot()));
        }
        if (kind == BipedalEntity.GOAT_TOP || kind == BipedalEntity.GOAT_BOTTOM) {
            float spin = (entity.tickCount + partialTick) * (kind == BipedalEntity.GOAT_TOP ? -14.0F : 11.0F);
            if (entity.tickCount > 40) {
                spin = 40 * (kind == BipedalEntity.GOAT_TOP ? -14.0F : 11.0F); // the halves lie on the ground
            }
            pose.translate(0.0D, h / 2.0D, 0.0D);
            pose.mulPose(Axis.ZP.rotationDegrees(spin));
            pose.translate(0.0D, -h / 2.0D, 0.0D);
        }
        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));

        vertex(vc, matrix, normal, x0, y0, 0.0F, 1.0F, light);
        vertex(vc, matrix, normal, x1, y0, 1.0F, 1.0F, light);
        vertex(vc, matrix, normal, x1, y1, 1.0F, 0.0F, light);
        vertex(vc, matrix, normal, x0, y1, 0.0F, 0.0F, light);
        pose.popPose();
    }

    /**
     * The dark doorway. Local frame: +Z points into the room, +X to the right of someone in the room looking at the
     * door. The door blocks are z -0.5..0.5, the doorway (two doors) is x -1..1, y 0..2.
     */
    private void renderDarkDoor(BipedalEntity entity, float partialTick, PoseStack pose, MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - entity.getYRot()));
        PoseStack.Pose last = pose.last();
        Matrix4f m = last.pose();
        Matrix3f n = last.normal();

        // 1. nothing but black behind the doors: a black box just outside the doorway
        VertexConsumer black = buffer.getBuffer(RenderType.entityCutoutNoCull(DARK_HEAD_TEX));
        float x0 = -0.995F, x1 = 0.995F, y0 = 0.002F, y1 = 1.998F, zf = -0.5F, zb = -3.5F;
        int full = 0xF000F0;
        // front (seen from the room), back, left, right, top, bottom
        quad(black, m, n, x0, y0, zf, x1, y0, zf, x1, y1, zf, x0, y1, zf, full);
        quad(black, m, n, x0, y0, zb, x1, y0, zb, x1, y1, zb, x0, y1, zb, full);
        quad(black, m, n, x0, y0, zb, x0, y0, zf, x0, y1, zf, x0, y1, zb, full);
        quad(black, m, n, x1, y0, zb, x1, y0, zf, x1, y1, zf, x1, y1, zb, full);
        quad(black, m, n, x0, y1, zb, x1, y1, zb, x1, y1, zf, x0, y1, zf, full);
        quad(black, m, n, x0, y0, zb, x1, y0, zb, x1, y0, zf, x0, y0, zf, full);

        // the arms come out of the doorway and lie along the wall, one to each side (slow, small movement)
        float t = entity.tickCount + partialTick;
        float sway = (float) Math.sin(t * 0.05F) * 0.04F;
        VertexConsumer hand = buffer.getBuffer(RenderType.entityCutoutNoCull(DARK_HAND_TEX));
        float len = 2.7F;
        float hh = len / 2.2396F;  // picture ratio
        float armLine = 0.26F;     // the straight part of the arm is 26 % from the top of the picture
        float zr = 0.53F;          // just in front of the inner face of the wall
        // right arm: shoulder at the doorway, fingers to the right
        float top = 1.0F + sway + armLine * hh;
        picture(hand, m, n, 0.75F, top - hh, 0.75F + len, top, zr, 0.0F, 1.0F, light);
        // left arm: mirrored, fingers to the left, a bit lower
        top = 0.8F - sway + armLine * hh;
        picture(hand, m, n, -0.75F - len, top - hh, -0.75F, top, zr, 1.0F, 0.0F, light);

        // the head peeks out of the doorway, tilted
        pose.pushPose();
        pose.translate(-0.3D, 1.45D + sway, 0.05D);
        pose.mulPose(Axis.ZP.rotationDegrees(-18.0F + (float) Math.sin(t * 0.03F) * 3.0F));
        PoseStack.Pose hp = pose.last();
        VertexConsumer head = buffer.getBuffer(RenderType.entityCutoutNoCull(DARK_HEAD_TEX));
        float h = 0.95F;
        float w = h * 0.8233F;
        picture(head, hp.pose(), hp.normal(), -w / 2, -h / 2, w / 2, h / 2, 0.0F, 0.0F, 1.0F, light);
        pose.popPose();
        pose.popPose();
    }

    /** A black quad (the colour is 0, the texture only gives the alpha: its middle is opaque). */
    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, int light) {
        float[][] p = {{ax, ay, az}, {bx, by, bz}, {cx, cy, cz}, {dx, dy, dz}};
        for (float[] v : p) {
            vc.vertex(m, v[0], v[1], v[2]).color(0, 0, 0, 255).uv(0.5F, 0.5F)
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        }
    }

    /** A textured picture in the XY plane at depth z; u0/u1 swapped mirrors it. */
    private static void picture(VertexConsumer vc, Matrix4f m, Matrix3f n, float x0, float y0, float x1, float y1,
                                float z, float u0, float u1, int light) {
        vc.vertex(m, x0, y0, z).color(255, 255, 255, 255).uv(u0, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x1, y0, z).color(255, 255, 255, 255).uv(u1, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x1, y1, z).color(255, 255, 255, 255).uv(u1, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x0, y1, z).color(255, 255, 255, 255).uv(u0, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
    }

    private void renderRunner(BipedalEntity entity, float yaw, float partialTick, PoseStack pose,
                              MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw)); // the model's front is -Z
        float s = MODEL_SCALE / 16.0F;                         // model units are pixels
        pose.scale(s, s, s);
        boolean roar = entity.getAnim() == BipedalEntity.ANIM_SCREAM;
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(
                roar ? StalkerRunModel.TEXTURE_SCREAM : StalkerRunModel.TEXTURE));
        String anim;
        float seconds;
        if (roar) {
            anim = "grito";
            seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        } else {
            anim = "terror";
            seconds = (entity.tickCount + partialTick) / 20.0F;
        }
        StalkerRunModel.render(pose, vc, anim, seconds, light);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f matrix, Matrix3f normal,
                               float x, float y, float u, float v, int light) {
        vc.vertex(matrix, x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(BipedalEntity entity) {
        return switch (entity.getKind()) {
            case BipedalEntity.TREE -> TREE_TEX;
            case BipedalEntity.ROOF -> ROOF_TEX;
            case BipedalEntity.ONLOOKER -> ONLOOKER_TEX;
            case BipedalEntity.GOAT_TOP -> GOAT_TOP_TEX;
            case BipedalEntity.GOAT_BOTTOM -> GOAT_BOTTOM_TEX;
            case BipedalEntity.CAVE -> CAVE_TEX;
            case BipedalEntity.SHAFT_GOAT -> SHAFT_GOAT_TEX;
            case BipedalEntity.SHAFT_FACE -> SHAFT_FACE_TEX;
            case BipedalEntity.DOOR -> DOOR_TEX;
            case BipedalEntity.WINDOW -> WINDOW_TEX;
            case BipedalEntity.HOUSE -> HOUSE_TEX;
            case BipedalEntity.PEEKER -> PEEKER_TEX;
            case BipedalEntity.DARK_DOOR -> DARK_HEAD_TEX;
            default -> StalkerRunModel.TEXTURE;
        };
    }
}
