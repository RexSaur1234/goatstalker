package com.example.goatstalker.client;

import com.example.goatstalker.BipedalEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * TREE and ROOF are flat pictures that face the camera (the feet are at the entity position).
 * RUNNER is the 3D model StalkerRun with the "terror" (run) and "grito" (scream) animations.
 */
public class BipedalRenderer extends EntityRenderer<BipedalEntity> {
    private static final ResourceLocation TREE_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_tree.png");
    private static final ResourceLocation ROOF_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_roof.png");

    // sizes in blocks = height * picture ratio
    private static final float TREE_H = BipedalEntity.TREE_H, TREE_W = BipedalEntity.TREE_W;
    private static final float ROOF_H = 2.6F, ROOF_W = 2.128F; // ratio 0.8184 (head and shoulders)

    /** 1.0 = the size drawn in Blockbench (about 6 blocks tall). Make it smaller to shrink the creature. */
    private static final float MODEL_SCALE = 1.0F;

    public BipedalRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(BipedalEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        int kind = entity.getKind();
        if (kind == BipedalEntity.RUNNER) {
            renderRunner(entity, yaw, partialTick, pose, buffer, light);
            return;
        }
        boolean tree = kind == BipedalEntity.TREE;
        float w = tree ? TREE_W : ROOF_W;
        float h = tree ? TREE_H : ROOF_H;

        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - this.entityRenderDispatcher.camera.getYRot()));
        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(tree ? TREE_TEX : ROOF_TEX));

        vertex(vc, matrix, normal, -w / 2, 0.0F, 0.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, 0.0F, 1.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, h, 1.0F, 0.0F, light);
        vertex(vc, matrix, normal, -w / 2, h, 0.0F, 0.0F, light);
        pose.popPose();
    }

    private void renderRunner(BipedalEntity entity, float yaw, float partialTick, PoseStack pose,
                              MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw)); // the model's front is -Z
        float s = MODEL_SCALE / 16.0F;                         // model units are pixels
        pose.scale(s, s, s);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(StalkerRunModel.TEXTURE));
        String anim;
        float seconds;
        if (entity.getAnim() == BipedalEntity.ANIM_SCREAM) {
            anim = "grito";
            seconds = (entity.tickCount - entity.getAnimStart() + partialTick) / 20.0F;
        } else {
            anim = "terror";
            seconds = (entity.tickCount + partialTick) / 20.0F;
        }
        StalkerRunModel.render(pose, vc, anim, seconds, light);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f matrix, Matrix3f normal,
                               float x, float y, float u, float v, int light) {
        vc.vertex(matrix, x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(BipedalEntity entity) {
        return entity.getKind() == BipedalEntity.TREE ? TREE_TEX
                : entity.getKind() == BipedalEntity.ROOF ? ROOF_TEX : StalkerRunModel.TEXTURE;
    }
}
