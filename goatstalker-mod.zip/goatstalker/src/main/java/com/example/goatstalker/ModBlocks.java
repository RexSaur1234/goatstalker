package com.example.goatstalker;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, GoatStalkerMod.MODID);

    public static final RegistryObject<Block> EXIT = BLOCKS.register("nullspace_exit",
            () -> new ExitBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_MAGENTA)
                    .strength(-1.0F, 3600000.0F)
                    .noLootTable()
                    .sound(SoundType.STONE)));

    public static final RegistryObject<Block> GLITCH_GRASS = BLOCKS.register("glitch_grass",
            () -> new GlitchGrassBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GRASS)
                    .noCollission()
                    .noOcclusion()
                    .lightLevel(state -> 15)
                    .strength(-1.0F, 3600000.0F)
                    .noLootTable()
                    .sound(SoundType.GRASS)));

    public static final RegistryObject<Block> GLITCH_STONE = BLOCKS.register("glitch_stone",
            () -> new GlitchStoneBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SNOW)
                    .lightLevel(state -> 15)
                    .strength(-1.0F, 3600000.0F)
                    .noLootTable()
                    .sound(SoundType.STONE)));

    public static final RegistryObject<Block> TV = BLOCKS.register("tv",
            () -> new TvBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.METAL)));
}
