package com.example.goatstalker;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Holds the cassette and the moment the video started (the client draws the frame for the current time). */
public class TvBlockEntity extends BlockEntity {
    /** The video: 239 frames at 10 per second (23.9 s), in textures/tv/cassette_atlas.png (16 x 15 frames). */
    public static final int FRAMES = 239;
    public static final int FPS = 10;
    public static final int LENGTH_TICKS = FRAMES * 20 / FPS + 2;
    private static final ResourceLocation SOUND_ID = new ResourceLocation(GoatStalkerMod.MODID, "tv_cassette");

    private boolean cassette;
    private long startTime = -1L;

    public TvBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TV.get(), pos, state);
    }

    public boolean hasCassette() {
        return this.cassette;
    }

    public boolean isPlaying() {
        return this.cassette && this.startTime >= 0L;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public void insertAndPlay() {
        if (this.level == null) {
            return;
        }
        this.cassette = true;
        this.startTime = this.level.getGameTime();
        this.level.playSound(null, this.worldPosition, ModSounds.TV_CASSETTE.get(), SoundSource.RECORDS, 2.0F, 1.0F);
        changed();
    }

    /** Gives the cassette back (it pops out in front of the TV) and stops the sound. */
    public void ejectAndStop() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (this.cassette) {
            Block.popResource(this.level, this.worldPosition.above(), new ItemStack(ModItems.CASSETTE.get()));
        }
        this.cassette = false;
        this.startTime = -1L;
        if (this.level instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) {
                if (p.blockPosition().distSqr(this.worldPosition) < 80 * 80) {
                    p.connection.send(new ClientboundStopSoundPacket(SOUND_ID, SoundSource.RECORDS));
                }
            }
        }
        changed();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, TvBlockEntity tv) {
        if (tv.isPlaying() && level.getGameTime() - tv.startTime > LENGTH_TICKS) {
            tv.ejectAndStop(); // the video is over: the cassette comes out, the screen asks for one again
        }
    }

    private void changed() {
        setChanged();
        if (this.level != null) {
            this.level.sendBlockUpdated(this.worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("Cassette", this.cassette);
        tag.putLong("Start", this.startTime);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.cassette = tag.getBoolean("Cassette");
        this.startTime = tag.contains("Start") ? tag.getLong("Start") : -1L;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
