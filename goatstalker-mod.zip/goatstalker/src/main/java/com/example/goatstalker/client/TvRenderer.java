package com.example.goatstalker.client;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.TvBlock;
import com.example.goatstalker.TvBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws the TV screen: black when on, "INSERT CASSETTE" when empty, the video frame while a cassette plays. */
public class TvRenderer implements BlockEntityRenderer<TvBlockEntity> {
    private static final ResourceLocation BLACK = new ResourceLocation(GoatStalkerMod.MODID, "textures/tv/black.png");
    private static final ResourceLocation ATLAS = new ResourceLocation(GoatStalkerMod.MODID, "textures/tv/cassette_atlas.png");
    private static final int COLS = 16;
    private static final int ROWS = 15;
    private static final int FULL = 0xF000F0;

    // the screen on the front texture: pixels x 2..13, y 2..12 (from the top)
    private static final float SX0 = -6.0F / 16.0F, SX1 = 6.0F / 16.0F;
    private static final float SY0 = 0.5F - 13.0F / 16.0F, SY1 = 0.5F - 2.0F / 16.0F;
    private static final float VIDEO_RATIO = 102.0F / 150.0F; // width / height of a frame

    private final Font font;

    public TvRenderer(BlockEntityRendererProvider.Context ctx) {
        this.font = ctx.getFont();
    }

    @Override
    public void render(TvBlockEntity tv, float partialTick, PoseStack pose, MultiBufferSource buffer, int light, int overlay) {
        BlockState state = tv.getBlockState();
        if (!(state.getBlock() instanceof TvBlock) || !state.getValue(TvBlock.ON)) {
            return;
        }
        Direction facing = state.getValue(TvBlock.FACING);
        pose.pushPose();
        pose.translate(0.5D, 0.5D, 0.5D);
        pose.mulPose(Axis.YP.rotationDegrees(-facing.toYRot())); // the front is now +Z
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        float z = 0.5F + 0.002F;

        quad(buffer.getBuffer(RenderType.entitySolid(BLACK)), m, n, SX0, SY0, SX1, SY1, z, 0, 0, 1, 1);

        if (tv.isPlaying() && Minecraft.getInstance().level != null) {
            float ticks = Minecraft.getInstance().level.getGameTime() - tv.getStartTime() + partialTick;
            int frame = Math.max(0, Math.min(TvBlockEntity.FRAMES - 1, (int) (ticks / 20.0F * TvBlockEntity.FPS)));
            float u0 = (frame % COLS) / (float) COLS;
            float v0 = (frame / COLS) / (float) ROWS;
            float h = SY1 - SY0;
            float w = h * VIDEO_RATIO; // the video is upright: black bars left and right
            quad(buffer.getBuffer(RenderType.entitySolid(ATLAS)), m, n, -w / 2, SY0, w / 2, SY1, z + 0.001F,
                    u0, v0, u0 + 1.0F / COLS, v0 + 1.0F / ROWS);
        } else if (!tv.hasCassette()) {
            // "INSERT CASSETTE", blinking slowly
            long t = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
            if ((t / 20) % 3 != 2) {
                Component l1 = Component.translatable("tv.goatstalker.insert_1");
                Component l2 = Component.translatable("tv.goatstalker.insert_2");
                float scale = 0.0085F;
                pose.pushPose();
                pose.translate(0.0D, (SY0 + SY1) / 2.0D, z + 0.002D);
                pose.scale(scale, -scale, scale);
                Matrix4f tm = pose.last().pose();
                this.font.drawInBatch(l1, -this.font.width(l1) / 2.0F, -10.0F, 0xE0E0E0, false, tm, buffer,
                        Font.DisplayMode.POLYGON_OFFSET, 0, FULL);
                this.font.drawInBatch(l2, -this.font.width(l2) / 2.0F, 1.0F, 0xE0E0E0, false, tm, buffer,
                        Font.DisplayMode.POLYGON_OFFSET, 0, FULL);
                pose.popPose();
            }
        }
        pose.popPose();
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n, float x0, float y0, float x1, float y1, float z,
                             float u0, float v0, float u1, float v1) {
        vc.vertex(m, x0, y0, z).color(255, 255, 255, 255).uv(u0, v1).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(FULL).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x1, y0, z).color(255, 255, 255, 255).uv(u1, v1).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(FULL).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x1, y1, z).color(255, 255, 255, 255).uv(u1, v0).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(FULL).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
        vc.vertex(m, x0, y1, z).color(255, 255, 255, 255).uv(u0, v0).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(FULL).normal(n, 0.0F, 0.0F, 1.0F).endVertex();
    }
}
