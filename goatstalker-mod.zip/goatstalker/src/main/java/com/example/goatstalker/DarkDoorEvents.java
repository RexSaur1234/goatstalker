package com.example.goatstalker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Dark doorway. Every ~15 minutes, if there is a double door near the player, both doors swing open and behind them
 * there is nothing but black. A head peeks out of the doorway and two long arms reach out along the wall, left and
 * right, while the music plays. The doors cannot be closed. After 2 minutes the creature is gone, the doors close and
 * behind them everything is normal again.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class DarkDoorEvents {
    private static final Map<UUID, Long> NEXT = new HashMap<>();
    private static final Map<UUID, Integer> TOKEN = new HashMap<>();
    private static final ResourceLocation MUSIC_ID = new ResourceLocation(GoatStalkerMod.MODID, "goat_evil_music");

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0 || !StalkerConfig.DARK_DOOR_ENABLED.get()) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long now = level.getGameTime();
        long avg = StalkerConfig.DARK_DOOR_MINUTES.get() * 1200L;
        long next = NEXT.computeIfAbsent(p.getUUID(), k -> now + avg / 2 + level.random.nextInt((int) Math.max(1, avg)));
        if (now < next) {
            return;
        }
        boolean ok = start(p, level);
        NEXT.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1, avg)) : 600L));
    }

    /** The nearest double door to the player (the lower half of one of its two doors), up to 12 blocks away. */
    private static BlockPos findDoubleDoor(ServerLevel level, ServerPlayer p) {
        BlockPos me = p.blockPosition();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos q : BlockPos.betweenClosed(me.offset(-12, -4, -12), me.offset(12, 4, 12))) {
            BlockState st = level.getBlockState(q);
            if (st.getBlock() instanceof DoorBlock && st.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                double d = q.distSqr(me);
                if (d < bestD && DoorEvents.partner(level, q) != null) {
                    bestD = d;
                    best = q.immutable();
                }
            }
        }
        return best;
    }

    private static void playMusic(ServerPlayer p, int token) {
        if (!p.isAlive() || TOKEN.getOrDefault(p.getUUID(), 0) != token) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.GOAT_EVIL_MUSIC.get(),
                SoundSource.MASTER, 1.0F, 1.0F);
        NullspaceEvents.schedule(p.server, ModSounds.GOAT_EVIL_TICKS, () -> playMusic(p, token));
    }

    private static void stopMusic(ServerPlayer p) {
        TOKEN.merge(p.getUUID(), 1, Integer::sum);
        p.connection.send(new ClientboundStopSoundPacket(MUSIC_ID, SoundSource.MASTER));
    }

    public static boolean start(ServerPlayer p, ServerLevel level) {
        if (DoorEvents.isBusy(p.getUUID())) {
            return false; // another door scene is running
        }
        BlockPos a = findDoubleDoor(level, p);
        if (a == null) {
            return false;
        }
        BlockPos b = DoorEvents.partner(level, a);
        if (b == null) {
            return false;
        }
        Direction f = level.getBlockState(a).getValue(DoorBlock.FACING);
        double cx = (a.getX() + b.getX()) / 2.0D + 0.5D;
        double cz = (a.getZ() + b.getZ()) / 2.0D + 0.5D;
        double dot = (p.getX() - cx) * f.getStepX() + (p.getZ() - cz) * f.getStepZ();
        Direction inside = dot >= 0 ? f : f.getOpposite();

        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return false;
        }
        float yaw = DoorEvents.yawFacing(inside);
        e.setup(BipedalEntity.DARK_DOOR, p.getUUID());
        e.moveTo(cx, a.getY(), cz, yaw, 0.0F);
        e.setYRot(yaw);
        e.yRotO = yaw;
        level.addFreshEntity(e);

        DoorEvents.openDoor(level, a);
        DoorEvents.openDoor(level, b);
        List<BlockPos> doors = new ArrayList<>();
        doors.add(a.immutable());
        doors.add(b.immutable());
        DoorEvents.lock(p.getUUID(), doors);

        stopMusic(p);
        int token = TOKEN.get(p.getUUID());
        playMusic(p, token);

        NullspaceEvents.schedule(p.server, StalkerConfig.DARK_DOOR_SECONDS.get() * 20, () -> {
            e.discard();
            DoorEvents.unlock(p.getUUID());
            DoorEvents.closeDoor(level, a);
            DoorEvents.closeDoor(level, b);
            if (TOKEN.getOrDefault(p.getUUID(), 0) == token) {
                stopMusic(p);
            }
        });
        return true;
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("darkDoor").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!start(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No double door within 12 blocks (or a door scene is already running)."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd));
    }
}
