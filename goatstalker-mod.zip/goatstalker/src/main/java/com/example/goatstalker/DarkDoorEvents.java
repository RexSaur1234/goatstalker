package com.example.goatstalker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Dark doorway. Every ~15 minutes, if there is a double door near the player, both doors swing open and behind them
 * there is nothing but black. A head peeks out of the doorway and two long arms reach out along the wall, left and
 * right, while the music plays. The doors cannot be closed. After 2 minutes the creature is gone, the doors close and
 * behind them everything is normal again.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class DarkDoorEvents {
    private static final Map<UUID, Long> NEXT = new HashMap<>();
    private static final Map<UUID, Integer> TOKEN = new HashMap<>();
    private static final Map<UUID, Long> NEXT_TALL = new HashMap<>();
    private static final ResourceLocation[] MUSIC_IDS = {
            new ResourceLocation(GoatStalkerMod.MODID, "goat_evil_music"),
            new ResourceLocation(GoatStalkerMod.MODID, "door_music"),
            new ResourceLocation(GoatStalkerMod.MODID, "tormentor_r"),
            new ResourceLocation(GoatStalkerMod.MODID, "peeker_music")};
    /** How to end the running scene of each player (doors closed, music off, creature gone). */
    private static final Map<UUID, Runnable> FINISH = new HashMap<>();

    /** The player walked up to the doorway: the alt jumpscare, he dies, and it is all gone. */
    public static void caught(ServerPlayer p, BipedalEntity e) {
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
        p.kill();
        e.discard();
        Runnable f = FINISH.remove(p.getUUID());
        if (f != null) {
            f.run();
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient() || !(event.player instanceof ServerPlayer p)
                || p.tickCount % 20 != 0) {
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || p.isCreative() || p.isSpectator()) {
            return;
        }
        long now = level.getGameTime();
        if (StalkerConfig.DARK_DOOR_ENABLED.get()) { // head and arms, darkness behind (about every 15 minutes)
            long avg = StalkerConfig.DARK_DOOR_MINUTES.get() * 1200L;
            long next = NEXT.computeIfAbsent(p.getUUID(), k -> now + avg / 2 + level.random.nextInt((int) Math.max(1, avg)));
            if (now >= next) {
                boolean ok = start(p, level, BipedalEntity.DARK_DOOR);
                NEXT.put(p.getUUID(), now + (ok ? avg / 2 + level.random.nextInt((int) Math.max(1, avg)) : 600L));
            }
        }
        if (StalkerConfig.TALL_DOOR_ENABLED.get()) { // the tall one standing in the doorway (every 18 minutes)
            long every = StalkerConfig.TALL_DOOR_MINUTES.get() * 1200L;
            long next = NEXT_TALL.computeIfAbsent(p.getUUID(), k -> now + every);
            if (now >= next) {
                boolean ok = start(p, level, BipedalEntity.DOOR_TALL);
                NEXT_TALL.put(p.getUUID(), now + (ok ? every : 600L));
            }
        }
    }

    /** The nearest double door to the player (the lower half of one of its two doors), up to 12 blocks away. */
    static BlockPos findDoubleDoor(ServerLevel level, ServerPlayer p) {
        BlockPos me = p.blockPosition();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos q : BlockPos.betweenClosed(me.offset(-12, -4, -12), me.offset(12, 4, 12))) {
            BlockState st = level.getBlockState(q);
            if (st.getBlock() instanceof DoorBlock && st.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                double d = q.distSqr(me);
                if (d < bestD && DoorEvents.partner(level, q) != null) {
                    bestD = d;
                    best = q.immutable();
                }
            }
        }
        return best;
    }

    /** Dark doorway: its music, repeated. */
    private static void playMusic(ServerPlayer p, int token) {
        if (!p.isAlive() || TOKEN.getOrDefault(p.getUUID(), 0) != token) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.GOAT_EVIL_MUSIC.get(),
                SoundSource.MASTER, 1.0F, 1.0F);
        NullspaceEvents.schedule(p.server, ModSounds.GOAT_EVIL_TICKS, () -> playMusic(p, token));
    }

    private static void playOnce(ServerPlayer p, int token, net.minecraftforge.registries.RegistryObject<net.minecraft.sounds.SoundEvent> s) {
        if (p.isAlive() && TOKEN.getOrDefault(p.getUUID(), 0) == token) {
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), s.get(), SoundSource.MASTER, 1.0F, 1.0F);
        }
    }

    private static void stopMusic(ServerPlayer p) {
        TOKEN.merge(p.getUUID(), 1, Integer::sum);
        for (ResourceLocation id : MUSIC_IDS) {
            p.connection.send(new ClientboundStopSoundPacket(id, SoundSource.MASTER));
        }
    }

    /**
     * Blocks put in front of or behind the doors (a barricade) are broken: only in the doorway itself, at door
     * height, one block deep on each side. Nothing unbreakable, no other doors.
     */
    private static void breakBarricade(ServerLevel level, BlockPos a, BlockPos b, Direction facing) {
        boolean broke = false;
        for (BlockPos door : new BlockPos[] {a, b}) {
            for (Direction side : new Direction[] {facing, facing.getOpposite()}) {
                for (int h = 0; h <= 1; h++) {
                    BlockPos q = door.relative(side).above(h);
                    BlockState st = level.getBlockState(q);
                    if (st.isAir() || st.getBlock() instanceof DoorBlock || st.getDestroySpeed(level, q) < 0.0F
                            || !st.getFluidState().isEmpty()) {
                        continue;
                    }
                    level.destroyBlock(q, true);
                    broke = true;
                }
            }
        }
        if (broke) {
            level.playSound(null, a, SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.BLOCKS, 2.5F, 0.7F);
        }
    }

    /** @param kind BipedalEntity.DARK_DOOR (head and arms) or BipedalEntity.DOOR_TALL (the tall one standing there) */
    public static boolean start(ServerPlayer p, ServerLevel level, int kind) {
        if (DoorEvents.isBusy(p.getUUID())) {
            return false; // another door scene is running
        }
        BlockPos a = findDoubleDoor(level, p);
        if (a == null) {
            return false;
        }
        BlockPos b = DoorEvents.partner(level, a);
        if (b == null) {
            return false;
        }
        Direction f = level.getBlockState(a).getValue(DoorBlock.FACING);
        double cx = (a.getX() + b.getX()) / 2.0D + 0.5D;
        double cz = (a.getZ() + b.getZ()) / 2.0D + 0.5D;
        double dot = (p.getX() - cx) * f.getStepX() + (p.getZ() - cz) * f.getStepZ();
        Direction inside = dot >= 0 ? f : f.getOpposite();

        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return false;
        }
        float yaw = DoorEvents.yawFacing(inside);
        e.setup(kind, p.getUUID());
        e.moveTo(cx, a.getY(), cz, yaw, 0.0F);
        e.setYRot(yaw);
        e.yRotO = yaw;
        level.addFreshEntity(e);

        breakBarricade(level, a, b, f);
        DoorEvents.openDoor(level, a);
        DoorEvents.openDoor(level, b);
        // a long, loud creak: the doors are pushed open from the dark, heard all over the house
        for (BlockPos d : new BlockPos[] {a, b}) {
            level.playSound(null, d, SoundEvents.WOODEN_DOOR_OPEN, SoundSource.BLOCKS, 3.0F, 0.55F);
        }
        NullspaceEvents.schedule(level.getServer(), 6, () -> level.playSound(null, a, SoundEvents.WOODEN_DOOR_OPEN,
                SoundSource.BLOCKS, 2.5F, 0.45F));
        List<BlockPos> doors = new ArrayList<>();
        doors.add(a.immutable());
        doors.add(b.immutable());
        DoorEvents.lock(p.getUUID(), doors);

        stopMusic(p);
        int token = TOKEN.get(p.getUUID());
        int ticks;
        if (kind == BipedalEntity.DOOR_TALL) { // "tormentor door", right after it "tormentor R"; when R ends it is gone
            playOnce(p, token, ModSounds.DOOR_MUSIC);
            NullspaceEvents.schedule(p.server, ModSounds.DOOR_MUSIC_TICKS, () -> playOnce(p, token, ModSounds.TORMENTOR_R));
            ticks = BipedalEntity.TALL_DOOR_TICKS;
        } else {
            playMusic(p, token);
            ticks = StalkerConfig.DARK_DOOR_SECONDS.get() * 20;
        }

        Runnable finish = () -> {
            e.discard();
            DoorEvents.unlock(p.getUUID());
            DoorEvents.closeDoor(level, a);
            DoorEvents.closeDoor(level, b);
            if (TOKEN.getOrDefault(p.getUUID(), 0) == token) {
                stopMusic(p);
            }
        };
        FINISH.put(p.getUUID(), finish);
        NullspaceEvents.schedule(p.server, ticks, () -> {
            if (FINISH.get(p.getUUID()) == finish) {
                FINISH.remove(p.getUUID());
                finish.run();
            }
        });
        return true;
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var cmd = Commands.literal("darkDoor").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!start(p, p.serverLevel(), BipedalEntity.DARK_DOOR)) {
                ctx.getSource().sendFailure(Component.literal("No double door within 12 blocks (or a door scene is already running)."));
                return 0;
            }
            return 1;
        });
        var tall = Commands.literal("tallDoor").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!start(p, p.serverLevel(), BipedalEntity.DOOR_TALL)) {
                ctx.getSource().sendFailure(Component.literal("No double door within 12 blocks (or a door scene is already running)."));
                return 0;
            }
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(cmd).then(tall));
    }
}
