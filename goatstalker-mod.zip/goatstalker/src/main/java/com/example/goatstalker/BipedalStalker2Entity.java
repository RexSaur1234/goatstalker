package com.example.goatstalker;

import java.util.List;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Bipedal Stalker 2: one block taller than the bipedal stalker (6.2 blocks) and faster. It breaks wooden blocks and
 * planks in its way. Two hits and the player is dead: the first takes half of his health, the second is its screamer -
 * it lifts him and tears off his arms, his legs and then his head.
 * It runs from the Tormentor; it screams and runs from the Evil Dark Tormentor; a Goat Stalker it catches and kills by
 * tearing its head off.
 */
public class BipedalStalker2Entity extends Monster {
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(BipedalStalker2Entity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(BipedalStalker2Entity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Boolean> DATA_HEADLESS =
            SynchedEntityData.defineId(BipedalStalker2Entity.class, EntityDataSerializers.BOOLEAN);

    private int clientAnimStart;
    private int forcedAnim = -1;
    private int animUntil = -1;
    private int stuckTicks = 0;
    private int lifetime = -1;

    /** It goes away after this many ticks (when it came on its own). */
    public void setTimedLife(int ticks) {
        this.lifetime = ticks;
    }
    private int screamCooldown = 0;

    // the screamer
    private UUID capturedId;
    private int captureTick;
    private boolean releasing;

    // killing a Goat Stalker
    private UUID goatId;
    private int goatPhase = 0;
    private int goatTick = 0;
    private int goatCooldown = 0;

    public BipedalStalker2Entity(EntityType<? extends BipedalStalker2Entity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 250.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.40D)   // the bipedal stalker has 0.33
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, TormentorEntity.A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_HEADLESS, false);
    }

    public boolean isHeadless() {
        return this.entityData.get(DATA_HEADLESS);
    }

    /** Its head has been torn off (by the quadruped stalker): it falls dead. */
    public void loseHead() {
        if (this.level() instanceof ServerLevel sl && this.capturedId != null) {
            endCapture(sl);
        }
        this.entityData.set(DATA_HEADLESS, true);
        kill();
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    @Override
    public float maxUpStep() {
        return 1.25F;
    }

    private boolean busy() {
        return this.capturedId != null || this.goatPhase == 2;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || busy();
    }

    public boolean isHolding(Entity e) {
        return !this.releasing && this.capturedId != null && this.capturedId.equals(e.getUUID());
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        // it is afraid of the Evil Dark Tormentor and of the Tormentor
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, EvilDarkTormentorEntity.class, 40.0F, 1.5D, 1.9D,
                e -> e.isAlive() && !((EvilDarkTormentorEntity) e).isTorn()) {
            @Override
            public boolean canUse() {
                return !BipedalStalker2Entity.this.busy() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, TormentorEntity.class, 24.0F, 1.4D, 1.8D,
                e -> e.isAlive() && !((TormentorEntity) e).isCorpse()) {
            @Override
            public boolean canUse() {
                return !BipedalStalker2Entity.this.busy() && super.canUse();
            }
        });
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.2D, true) {
            @Override
            public boolean canUse() {
                return !BipedalStalker2Entity.this.busy() && BipedalStalker2Entity.this.goatPhase == 0 && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !BipedalStalker2Entity.this.busy() && BipedalStalker2Entity.this.goatPhase == 0 && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 13.0D;
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (distSqr <= getAttackReachSqr(target) && isTimeToAttack()) {
                    resetAttackCooldown();
                    BipedalStalker2Entity.this.strike(target);
                }
            }
        });
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false,
                e -> e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.lifetime >= 0 && this.tickCount > this.lifetime && this.capturedId == null && this.goatPhase == 0) {
            discard();
            return;
        }
        if (this.screamCooldown > 0) {
            this.screamCooldown--;
        }
        if (this.goatCooldown > 0) {
            this.goatCooldown--;
        }
        if (this.animUntil >= 0 && this.tickCount >= this.animUntil) {
            this.animUntil = -1;
            this.forcedAnim = -1;
        }
        if (this.capturedId != null) {
            tickCapture(sl);
        } else if (this.goatPhase != 0) {
            tickGoat(sl);
        } else if (this.tickCount % 10 == 0) {
            seeEvil(sl);
            lookForGoat(sl);
            breakWood(sl);
        }
        updateAnim();
    }

    private void updateAnim() {
        int anim;
        if (this.forcedAnim >= 0) {
            anim = this.forcedAnim;
        } else {
            Vec3 v = getDeltaMovement();
            anim = (v.x * v.x + v.z * v.z > 0.002D) ? TormentorEntity.A_RUN : TormentorEntity.A_IDLE;
        }
        if (anim != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    /** -1 = back to walking/standing; otherwise this animation (for the given ticks, or until changed). */
    private void anim(int a, int ticks) {
        this.forcedAnim = a;
        this.animUntil = ticks > 0 ? this.tickCount + ticks : -1;
        if (a >= 0) {
            this.entityData.set(DATA_ANIM, a);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void faceTo(double dx, double dz) {
        float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private Vec3 forward() {
        double r = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(r), 0.0D, Math.cos(r));
    }

    private void crack(ServerLevel sl, Vec3 at) {
        sl.playSound(null, at.x, at.y, at.z, ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 3.0F, 0.9F + this.random.nextFloat() * 0.2F);
    }

    /** It sees the Evil Dark Tormentor: it screams (and the avoid goal makes it run). */
    private void seeEvil(ServerLevel sl) {
        if (this.screamCooldown > 0) {
            return;
        }
        List<EvilDarkTormentorEntity> list = sl.getEntitiesOfClass(EvilDarkTormentorEntity.class, getBoundingBox().inflate(40.0D),
                e -> e.isAlive() && !e.isTorn() && hasLineOfSight(e));
        if (!list.isEmpty()) {
            anim(TormentorEntity.A_SCREAM, 30);
            sl.playSound(null, getX(), getY() + 5.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 5.0F, 1.2F);
            sl.playSound(null, getX(), getY() + 5.0D, getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 1.1F);
            this.screamCooldown = 400;
        }
    }

    // ------------------------------ breaking wood ------------------------------
    private void breakWood(ServerLevel sl) {
        LivingEntity t = getTarget();
        if (t == null || !sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            this.stuckTicks = 0;
            return;
        }
        Vec3 v = getDeltaMovement();
        boolean still = v.x * v.x + v.z * v.z < 0.0009D;
        boolean noPath = getNavigation().isDone() || getNavigation().getPath() == null || !getNavigation().getPath().canReach();
        this.stuckTicks = distanceToSqr(t) > 9.0D && (this.horizontalCollision || still || noPath) ? this.stuckTicks + 10 : 0;
        if (this.stuckTicks < 30) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5D) {
            return;
        }
        dx /= len;
        dz /= len;
        int broken = 0;
        for (double step = 0.8D; step <= 2.8D && broken < 10; step += 0.5D) {
            for (int h = 0; h <= 6 && broken < 10; h++) {
                BlockPos pos = BlockPos.containing(getX() + dx * step, getY() + h + 0.1D, getZ() + dz * step);
                BlockState st = sl.getBlockState(pos);
                if (st.isAir() || st.getDestroySpeed(sl, pos) < 0.0F
                        || !(st.is(BlockTags.MINEABLE_WITH_AXE) || st.is(BlockTags.PLANKS) || st.is(BlockTags.LOGS))) {
                    continue; // only wooden blocks and planks
                }
                sl.destroyBlock(pos, true, this);
                broken++;
            }
        }
        if (broken > 0) {
            sl.playSound(null, getX(), getY() + 2.0D, getZ(), SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.HOSTILE, 1.6F, 0.7F);
            getNavigation().stop();
            this.stuckTicks = 0;
        }
    }

    // ------------------------------ two hits ------------------------------
    /** First hit: half of the player's health. Second hit: the screamer. Other creatures just get hurt. */
    private void strike(LivingEntity target) {
        swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        if (target instanceof ServerPlayer sp) {
            if (sp.getHealth() > sp.getMaxHealth() * 0.55F && !SufferingEntity.empowers(this)) {
                anim(TormentorEntity.A_KICK, 16);
                sp.hurt(this.level().damageSources().magic(), sp.getMaxHealth() * 0.5F); // armour does not help
                if (this.level() instanceof ServerLevel sl) {
                    Blood.spray(sl, sp.getX(), sp.getY() + 1.2D, sp.getZ(), 12, 0.3D);
                }
            } else {
                startCapture(sp);
            }
        } else {
            doHurtTarget(target);
        }
    }

    private void startCapture(ServerPlayer sp) {
        if (this.capturedId != null || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            return;
        }
        this.capturedId = sp.getUUID();
        this.captureTick = 0;
        getNavigation().stop();
        sp.startRiding(this, true);
        anim(TormentorEntity.A_GRAB, 0);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) {
            return;
        }
        Vec3 f = forward();
        callback.accept(passenger, getX() + f.x * 1.4D, getY() + 4.6D, getZ() + f.z * 1.4D);
    }

    private void tickCapture(ServerLevel sl) {
        ServerPlayer sp = this.capturedId == null ? null : sl.getServer().getPlayerList().getPlayer(this.capturedId);
        this.captureTick++;
        getNavigation().stop();
        if (sp == null || !sp.isAlive()) {
            if (this.captureTick > 20 || sp == null) {
                endCapture(sl);
            }
            return;
        }
        if (sp.getVehicle() != this) {
            sp.startRiding(this, true);
        }
        faceTo(sp.getX() - getX() + forward().x * 0.001D, sp.getZ() - getZ() + forward().z * 0.001D);
        Vec3 body = sp.position().add(0.0D, 1.0D, 0.0D);
        int t = this.captureTick;
        if (t == 18) {
            anim(TormentorEntity.A_HOLD, 0);
            sl.playSound(null, getX(), getY() + 5.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
        } else if (t == 30) {
            anim(TormentorEntity.A_TEAR, 0);
        }
        // the arms, the legs ... one after the other
        if (t == 38 || t == 52 || t == 66 || t == 80) {
            crack(sl, body);
            Blood.spray(sl, body.x, body.y + (t < 60 ? 0.4D : -0.6D), body.z, 40, 0.45D);
            sp.invulnerableTime = 0;
            sp.hurt(this.level().damageSources().mobAttack(this), 0.5F);
        }
        if (t == 98) { // ... and then the head
            sl.playSound(null, body.x, body.y, body.z, ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 0.9F);
            crack(sl, body.add(0.0D, 0.8D, 0.0D));
            Blood.spray(sl, body.x, body.y + 0.9D, body.z, 120, 0.7D);
            this.releasing = true;
            sp.stopRiding();
            this.releasing = false;
            sp.kill();
        }
    }

    private void endCapture(ServerLevel sl) {
        if (sl != null && this.capturedId != null) {
            ServerPlayer sp = sl.getServer().getPlayerList().getPlayer(this.capturedId);
            if (sp != null && sp.getVehicle() == this) {
                this.releasing = true;
                sp.stopRiding();
                this.releasing = false;
            }
        }
        this.capturedId = null;
        anim(-1, 0);
    }

    @Override
    public void remove(RemovalReason reason) {
        if (this.capturedId != null && this.level() instanceof ServerLevel sl) {
            endCapture(sl);
        }
        if (this.goatId != null && this.level() instanceof ServerLevel sl && sl.getEntity(this.goatId) instanceof StalkerEntity g
                && g.isAlive() && !g.isHeadless()) {
            g.releaseDirected();
        }
        super.remove(reason);
    }

    // ------------------------------ a Goat Stalker: its head comes off ------------------------------
    private void lookForGoat(ServerLevel sl) {
        if (this.goatCooldown > 0 || EvilDarkTormentorEntity.isNear(this, 40.0D)) {
            return;
        }
        StalkerEntity best = null;
        for (StalkerEntity g : sl.getEntitiesOfClass(StalkerEntity.class, getBoundingBox().inflate(24.0D),
                e -> e.canBeDirected() && hasLineOfSight(e))) {
            if (best == null || distanceToSqr(g) < distanceToSqr(best)) {
                best = g;
            }
        }
        if (best != null) {
            this.goatId = best.getUUID();
            this.goatPhase = 1;
            this.goatTick = 0;
            setTarget(null);
            best.joinDirected();
        }
    }

    private void endGoat() {
        this.goatId = null;
        this.goatPhase = 0;
        this.goatCooldown = 300;
        anim(-1, 0);
    }

    private void tickGoat(ServerLevel sl) {
        StalkerEntity g = this.goatId != null && sl.getEntity(this.goatId) instanceof StalkerEntity e ? e : null;
        this.goatTick++;
        if (g == null) {
            endGoat();
            return;
        }
        double dx = g.getX() - getX();
        double dz = g.getZ() - getZ();
        if (this.goatPhase == 1) { // runs at it
            g.faceTowards(this);
            if (this.goatTick % 10 == 1) {
                getNavigation().moveTo(g, 1.5D);
            }
            if (dx * dx + dz * dz < 12.0D) {
                this.goatPhase = 2;
                this.goatTick = 0;
                getNavigation().stop();
                g.setNoGravity(true);
            } else if (this.goatTick > 400) {
                g.releaseDirected();
                endGoat();
            }
            return;
        }
        Vec3 f = forward();
        int t = this.goatTick;
        if (t < 45) { // holds it up by the body, in front of its face
            faceTo(dx, dz);
            g.setPos(getX() + f.x * 1.9D, getY() + Math.min(2.6D, t * 0.12D), getZ() + f.z * 1.9D);
            g.setDeltaMovement(Vec3.ZERO);
            g.faceTowards(this);
        }
        switch (t) {
            case 1 -> {
                anim(TormentorEntity.A_GRAB, 0);
                g.dAnim(TormentorEntity.A_HURT);
            }
            case 22 -> anim(TormentorEntity.A_TEAR, 0);
            case 40 -> { // the head is torn off
                Vec3 head = g.position().add(0.0D, 2.6D, 0.0D);
                crack(sl, head);
                sl.playSound(null, head.x, head.y, head.z, ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 3.0F, 1.4F);
                Blood.spray(sl, head.x, head.y, head.z, 80, 0.5D);
                g.loseHead();
                g.setNoGravity(false);
            }
            case 60 -> {
                anim(TormentorEntity.A_SCREAM, 30);
                sl.playSound(null, getX(), getY() + 5.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
            }
            case 100 -> endGoat();
            default -> { }
        }
    }

    // ------------------------------ misc ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 6, getY() - 1, getZ() - 6, getX() + 6, getY() + 9, getZ() + 6);
    }
}
