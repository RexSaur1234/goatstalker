package com.example.goatstalker;

import java.util.UUID;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Quadruped stalker: as big as the bipedal stalker (about 5.2 blocks), a little faster, 250 health.
 * Its screamer: it knocks the player down and tramples him to death.
 * It is stronger only than the Goat Stalker, the bipedal stalker and Bipedal Stalker 2: it simply tears their heads off.
 * The Tormentor, the Evil Dark Tormentor and Sufferings kill it (Anguish makes it kill itself, like every monster).
 */
public class QuadrupedStalkerEntity extends Monster {
    public static final int A_IDLE = 0;
    public static final int A_RUN = 1;
    public static final String[] ANIM_NAMES = {"idle", "run"};

    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(QuadrupedStalkerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(QuadrupedStalkerEntity.class, EntityDataSerializers.INT);
    /** The renderer plays the run animation fast while it tramples. */
    private static final EntityDataAccessor<Boolean> DATA_TRAMPLE =
            SynchedEntityData.defineId(QuadrupedStalkerEntity.class, EntityDataSerializers.BOOLEAN);
    private int clientAnimStart;

    // the screamer
    private UUID preyId;
    private int trampleTick = -1;
    private Vec3 pinAt = Vec3.ZERO;
    private int cooldown = 0;

    // tearing heads off
    private UUID victimId;
    private int victimTick = 0;
    private int victimCooldown = 0;

    private int lifetime = -1;

    public QuadrupedStalkerEntity(EntityType<? extends QuadrupedStalkerEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 250.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D)   // the bipedal stalker has 0.33
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D);
    }

    public void setTimedLife(int ticks) {
        this.lifetime = ticks;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
        this.entityData.define(DATA_TRAMPLE, false);
    }

    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    public boolean isTrampling() {
        return this.entityData.get(DATA_TRAMPLE);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    private boolean busy() {
        return this.trampleTick >= 0 || this.victimTick > 0 && this.victimId != null;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.trampleTick >= 0;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 5, getY() - 1, getZ() - 5, getX() + 5, getY() + 7, getZ() + 5);
    }

    @Override
    public float maxUpStep() {
        return 1.25F;
    }

    // ------------------------------ goals ------------------------------
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true) {
            @Override
            public boolean canUse() {
                return !QuadrupedStalkerEntity.this.busy() && QuadrupedStalkerEntity.this.victimId == null && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !QuadrupedStalkerEntity.this.busy() && QuadrupedStalkerEntity.this.victimId == null && super.canContinueToUse();
            }

            @Override
            protected double getAttackReachSqr(LivingEntity target) {
                return 9.0D;
            }

            @Override
            protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
                if (distSqr <= getAttackReachSqr(target)) {
                    if (target instanceof ServerPlayer sp) {
                        QuadrupedStalkerEntity.this.startTrample(sp);
                    } else if (isTimeToAttack()) {
                        resetAttackCooldown();
                        doHurtTarget(target);
                    }
                }
            }
        });
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                e -> e instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    // ------------------------------ tick ------------------------------
    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        if (this.lifetime >= 0 && this.tickCount > this.lifetime && !busy()) {
            discard();
            return;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
        }
        if (this.victimCooldown > 0) {
            this.victimCooldown--;
        }
        if (this.trampleTick >= 0) {
            tickTrample(sl);
        } else if (this.victimId != null) {
            tickVictim(sl);
        } else if (this.tickCount % 10 == 3) {
            lookForVictim(sl);
            callKillers(sl);
        }
        if (this.tickCount % 5 == 0) {
            checkKillers(sl);
        }
        if (this.trampleTick < 0) {
            Vec3 v = getDeltaMovement();
            anim(v.x * v.x + v.z * v.z > 0.002D ? A_RUN : A_IDLE);
        }
    }

    private void anim(int a) {
        if (a != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, a);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    private void faceTo(Entity e) {
        float yaw = (float) (Mth.atan2(-(e.getX() - getX()), e.getZ() - getZ()) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private Vec3 forward() {
        double r = Math.toRadians(getYRot());
        return new Vec3(-Math.sin(r), 0.0D, Math.cos(r));
    }

    // ------------------------------ the screamer: knocked down and trampled ------------------------------
    private void startTrample(ServerPlayer sp) {
        if (this.trampleTick >= 0 || this.cooldown > 0 || !sp.isAlive() || sp.isCreative() || sp.isSpectator()) {
            return;
        }
        this.preyId = sp.getUUID();
        this.trampleTick = 0;
        getNavigation().stop();
        faceTo(sp);
        ServerLevel sl = (ServerLevel) this.level();
        // it rams him: he flies back and falls
        Vec3 f = forward();
        sp.setDeltaMovement(f.x * 1.1D, 0.35D, f.z * 1.1D);
        sp.hurtMarked = true;
        sl.playSound(null, getX(), getY() + 3.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 4.0F, 1.2F);
        sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 2.0F, 0.6F);
    }

    private void tickTrample(ServerLevel sl) {
        ServerPlayer sp = this.preyId == null ? null : sl.getServer().getPlayerList().getPlayer(this.preyId);
        this.trampleTick++;
        int t = this.trampleTick;
        if (sp == null || sp.level() != this.level() || (!sp.isAlive() && t > 10)) {
            endTrample();
            return;
        }
        if (t == 12) { // he is down: it climbs over him
            this.pinAt = sp.position();
            Vec3 f = forward();
            setPos(this.pinAt.x - f.x * 0.6D, this.pinAt.y, this.pinAt.z - f.z * 0.6D);
            this.entityData.set(DATA_TRAMPLE, true);
            anim(A_RUN);
            sl.playSound(null, getX(), getY() + 3.0D, getZ(), ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 4.0F, 1.0F);
        }
        if (t >= 12 && sp.isAlive()) {
            // he cannot get up
            sp.teleportTo(this.pinAt.x, this.pinAt.y, this.pinAt.z);
            sp.setDeltaMovement(Vec3.ZERO);
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 10, false, false));
            sp.addEffect(new MobEffectInstance(MobEffects.JUMP, 10, 128, false, false));
            sp.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 25, 0, false, false));
            faceTo(sp);
            getNavigation().stop();
            if (t % 6 == 0) { // a stamp
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 1.6F, 0.5F);
                Blood.spray(sl, sp.getX(), sp.getY() + 0.4D, sp.getZ(), 14, 0.35D);
                if (t % 12 == 0) {
                    sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 3.0F,
                            0.8F + this.random.nextFloat() * 0.4F);
                }
                sp.invulnerableTime = 0;
                sp.hurt(this.level().damageSources().mobAttack(this), 1.0F);
            }
            if (t >= 72) { // trampled to death
                Blood.spray(sl, sp.getX(), sp.getY() + 0.4D, sp.getZ(), 90, 0.7D);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.6F);
                sp.invulnerableTime = 0;
                sp.hurt(this.level().damageSources().mobAttack(this), 100000.0F);
                if (sp.isAlive()) {
                    sp.kill();
                }
            }
        }
        if (t >= 95) {
            endTrample();
        }
    }

    private void endTrample() {
        this.trampleTick = -1;
        this.preyId = null;
        this.entityData.set(DATA_TRAMPLE, false);
        this.cooldown = 100;
        setTarget(null);
    }

    // ------------------------------ weaker monsters: their heads come off ------------------------------
    private static boolean isPrey(Entity e) {
        if (e instanceof StalkerEntity g) {
            return g.canBeDirected();
        }
        if (e instanceof BipedalMobEntity b) {
            return b.isAlive() && b.canStartTormentorFight();
        }
        if (e instanceof BipedalStalker2Entity b2) {
            return b2.isAlive() && !b2.isHeadless();
        }
        return false;
    }

    private void lookForVictim(ServerLevel sl) {
        if (this.victimCooldown > 0 || EvilDarkTormentorEntity.isNear(this, 32.0D)) {
            return;
        }
        Mob best = null;
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(24.0D), m -> isPrey(m) && hasLineOfSight(m))) {
            if (best == null || distanceToSqr(m) < distanceToSqr(best)) {
                best = m;
            }
        }
        if (best == null) {
            return;
        }
        this.victimId = best.getUUID();
        this.victimTick = 0;
        setTarget(null);
        if (best instanceof StalkerEntity g) {
            g.joinDirected();
        } else if (best instanceof BipedalMobEntity b) {
            b.joinDirected(this);
        }
    }

    private void tickVictim(ServerLevel sl) {
        Entity e = sl.getEntity(this.victimId);
        if (!(e instanceof Mob m) || !m.isAlive()) {
            endVictim(e);
            return;
        }
        this.victimTick++;
        double d2 = distanceToSqr(m);
        if (this.victimTick < 400 && d2 > 7.0D && this.victimTick < 1000) {
            if (this.victimTick % 10 == 1) {
                getNavigation().moveTo(m, 1.4D);
            }
            getLookControl().setLookAt(m);
            if (m instanceof StalkerEntity g) {
                g.faceTowards(this);
            } else if (m instanceof BipedalMobEntity b) {
                b.faceTowards(this);
            }
            return;
        }
        if (d2 > 7.0D) { // could not reach it
            endVictim(m);
            return;
        }
        // it pounces on it and tears the head off
        getNavigation().stop();
        faceTo(m);
        Vec3 head = m.position().add(0.0D, m.getBbHeight() * 0.85D, 0.0D);
        sl.playSound(null, head.x, head.y, head.z, ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.9F);
        sl.playSound(null, head.x, head.y, head.z, ModSounds.SCREAM_ALT.get(), SoundSource.HOSTILE, 3.0F, 1.3F);
        Blood.spray(sl, head.x, head.y, head.z, 90, 0.6D);
        if (m instanceof StalkerEntity g) {
            g.loseHead();
        } else if (m instanceof BipedalMobEntity b) {
            b.losePart(BipedalMobEntity.LOST_HEAD);
            b.fallDown();
            b.dieByTormentor();
        } else if (m instanceof BipedalStalker2Entity b2) {
            b2.loseHead();
        }
        sl.playSound(null, getX(), getY() + 3.0D, getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 4.0F, 1.2F);
        this.victimId = null;
        this.victimTick = 0;
        this.victimCooldown = 200;
    }

    private void endVictim(Entity e) {
        if (e instanceof StalkerEntity g && g.isAlive() && !g.isHeadless()) {
            g.releaseDirected();
        } else if (e instanceof BipedalMobEntity b && b.isAlive() && !b.isDeadByTormentor()) {
            b.leaveTormentorFight();
        }
        this.victimId = null;
        this.victimTick = 0;
        this.victimCooldown = 200;
    }

    // ------------------------------ the stronger ones kill it ------------------------------
    private static boolean isKiller(Entity e) {
        return e instanceof TormentorEntity t && !t.isCorpse()
                || e instanceof EvilDarkTormentorEntity edt && !edt.isTorn()
                || e instanceof SufferingEntity;
    }

    /** The stronger monsters that see it come for it. */
    private void callKillers(ServerLevel sl) {
        for (Mob k : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(32.0D), m -> m.isAlive() && isKiller(m)
                && m.hasLineOfSight(this))) {
            if (!(k.getTarget() instanceof Player)) {
                k.getNavigation().moveTo(this, 1.3D);
                k.getLookControl().setLookAt(this);
            }
        }
    }

    /** One of them has reached it: it is killed at once. */
    private void checkKillers(ServerLevel sl) {
        if (!isAlive()) {
            return;
        }
        for (Mob k : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(12.0D), m -> m.isAlive() && isKiller(m))) {
            double reach = k instanceof SufferingEntity ? 7.0D : k instanceof EvilDarkTormentorEntity ? 4.5D : 3.5D;
            double dx = k.getX() - getX();
            double dz = k.getZ() - getZ();
            if (dx * dx + dz * dz > reach * reach) {
                continue;
            }
            k.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
            if (k instanceof TormentorEntity t) {
                t.getLookControl().setLookAt(this);
            }
            if (this.trampleTick >= 0) {
                endTrample();
            }
            Vec3 mid = position().add(0.0D, 2.0D, 0.0D);
            Blood.spray(sl, mid.x, mid.y, mid.z, 120, 0.8D);
            sl.playSound(null, mid.x, mid.y, mid.z, ModSounds.BONE_CRACKED.get(), SoundSource.HOSTILE, 4.0F, 0.7F);
            sl.playSound(null, k.getX(), k.getY() + 3.0D, k.getZ(), ModSounds.STALKER_ROAR.get(), SoundSource.HOSTILE, 4.0F, 0.8F);
            this.invulnerableTime = 0;
            hurt(sl.damageSources().mobAttack(k), 100000.0F);
            return;
        }
    }

    // ------------------------------ sounds ------------------------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SPIDER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }
}
