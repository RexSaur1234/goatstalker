package com.example.goatstalker.client;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.goatstalker.GoatStalkerMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * The Blockbench model "StalkerRun" (flat parts on a skeleton) with its Bedrock animations.
 * The model and the animations are read from assets/goatstalker/stalker/*.json, which were converted from
 * StalkerRun_geo.bbmodel and stalker_run.animation.json. Units are pixels (1/16 block); Y is up, the front is -Z.
 */
public class StalkerRunModel {
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/stalker_run.png");

    public static final ResourceLocation TEXTURE_SCREAM =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/stalker_run_scream.png");

    private static final float DEG = (float) (Math.PI / 180.0D);

    private static final class Cube {
        float[] from, to, origin, rot;
        float[] north, south;
    }

    private static final class Bone {
        String name;
        float[] pivot, rot;
        final List<Cube> cubes = new ArrayList<>();
        final List<Bone> children = new ArrayList<>();
    }

    private static final class Key {
        float t;
        float[] pre, post;
        boolean smooth;
    }

    private static final class Channel {
        float[] constant;
        List<Key> keys;
    }

    private static final class BoneAnim {
        Channel rot, pos, scale;
    }

    private static final class Anim {
        float length;
        String loop;
        final Map<String, BoneAnim> bones = new HashMap<>();
    }

    private static int currentOverlay = OverlayTexture.NO_OVERLAY;
    private static boolean loaded;
    private static final List<Bone> ROOTS = new ArrayList<>();
    private static final Map<String, Anim> ANIMS = new HashMap<>();

    // ------------------------------ loading ------------------------------
    private static synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            ResourceManager rm = Minecraft.getInstance().getResourceManager();
            JsonObject model = readJson(rm, new ResourceLocation(GoatStalkerMod.MODID, "stalker/model.json"));
            Map<String, Bone> byName = new HashMap<>();
            List<JsonObject> raw = new ArrayList<>();
            for (JsonElement e : model.getAsJsonArray("bones")) {
                JsonObject o = e.getAsJsonObject();
                raw.add(o);
                Bone b = new Bone();
                b.name = o.get("name").getAsString();
                b.pivot = floats(o.getAsJsonArray("pivot"));
                b.rot = floats(o.getAsJsonArray("rotation"));
                for (JsonElement ce : o.getAsJsonArray("cubes")) {
                    JsonObject co = ce.getAsJsonObject();
                    Cube c = new Cube();
                    c.from = floats(co.getAsJsonArray("from"));
                    c.to = floats(co.getAsJsonArray("to"));
                    c.origin = floats(co.getAsJsonArray("origin"));
                    c.rot = floats(co.getAsJsonArray("rotation"));
                    if (co.has("north")) {
                        c.north = floats(co.getAsJsonArray("north"));
                    }
                    if (co.has("south")) {
                        c.south = floats(co.getAsJsonArray("south"));
                    }
                    b.cubes.add(c);
                }
                byName.put(b.name, b);
            }
            for (JsonObject o : raw) {
                Bone b = byName.get(o.get("name").getAsString());
                if (o.get("parent").isJsonNull()) {
                    ROOTS.add(b);
                } else {
                    byName.get(o.get("parent").getAsString()).children.add(b);
                }
            }

            JsonObject anims = readJson(rm, new ResourceLocation(GoatStalkerMod.MODID, "stalker/animations.json"));
            for (Map.Entry<String, JsonElement> en : anims.entrySet()) {
                JsonObject ao = en.getValue().getAsJsonObject();
                Anim a = new Anim();
                a.length = ao.get("length").getAsFloat();
                a.loop = ao.get("loop").getAsString();
                for (Map.Entry<String, JsonElement> be : ao.getAsJsonObject("bones").entrySet()) {
                    JsonObject bo = be.getValue().getAsJsonObject();
                    BoneAnim ba = new BoneAnim();
                    ba.rot = channel(bo, "rotation");
                    ba.pos = channel(bo, "position");
                    ba.scale = channel(bo, "scale");
                    a.bones.put(be.getKey(), ba);
                }
                ANIMS.put(en.getKey(), a);
            }
        } catch (Exception ex) {
            ROOTS.clear(); // the creature simply will not be drawn if the files cannot be read
        }
    }

    private static JsonObject readJson(ResourceManager rm, ResourceLocation id) throws Exception {
        try (Reader r = rm.openAsReader(id)) {
            return JsonParser.parseReader(r).getAsJsonObject();
        }
    }

    private static float[] floats(JsonArray arr) {
        float[] f = new float[arr.size()];
        for (int i = 0; i < f.length; i++) {
            f[i] = arr.get(i).getAsFloat();
        }
        return f;
    }

    private static Channel channel(JsonObject bone, String name) {
        if (!bone.has(name)) {
            return null;
        }
        JsonObject o = bone.getAsJsonObject(name);
        Channel c = new Channel();
        if (o.has("const")) {
            c.constant = floats(o.getAsJsonArray("const"));
        } else {
            c.keys = new ArrayList<>();
            for (JsonElement ke : o.getAsJsonArray("keys")) {
                JsonObject ko = ke.getAsJsonObject();
                Key k = new Key();
                k.t = ko.get("t").getAsFloat();
                k.pre = floats(ko.getAsJsonArray("pre"));
                k.post = floats(ko.getAsJsonArray("post"));
                k.smooth = ko.get("smooth").getAsBoolean();
                c.keys.add(k);
            }
        }
        return c;
    }

    // ------------------------------ animation sampling ------------------------------
    private static float[] sample(Channel c, float t, float[] def) {
        if (c == null) {
            return def;
        }
        if (c.constant != null) {
            return c.constant;
        }
        List<Key> ks = c.keys;
        if (ks.isEmpty()) {
            return def;
        }
        if (t <= ks.get(0).t) {
            return ks.get(0).post;
        }
        for (int i = 0; i < ks.size() - 1; i++) {
            Key a = ks.get(i);
            Key b = ks.get(i + 1);
            if (t >= a.t && t < b.t) {
                float f = (t - a.t) / (b.t - a.t);
                float[] out = new float[3];
                if (a.smooth) {
                    float[] p0 = i > 0 ? ks.get(i - 1).post : a.post;
                    float[] p3 = i + 2 < ks.size() ? ks.get(i + 2).pre : b.pre;
                    for (int j = 0; j < 3; j++) {
                        out[j] = catmull(p0[j], a.post[j], b.pre[j], p3[j], f);
                    }
                } else {
                    for (int j = 0; j < 3; j++) {
                        out[j] = a.post[j] + (b.pre[j] - a.post[j]) * f;
                    }
                }
                return out;
            }
        }
        return ks.get(ks.size() - 1).pre;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5F * ((2.0F * p1) + (-p0 + p2) * t + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t2
                + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t3);
    }

    // ------------------------------ rendering ------------------------------
    /** Draws the whole creature. The pose must already be scaled to 1/16 (pixels). */
    public static void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light) {
        render(pose, vc, animName, seconds, light, OverlayTexture.NO_OVERLAY);
    }

    /** Same, with an overlay (used to flash the creature red when it is hurt). */
    public static void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light, int overlay) {
        currentOverlay = overlay;
        load();
        Anim anim = ANIMS.get(animName);
        float t = 0.0F;
        if (anim != null) {
            float len = Math.max(anim.length, 0.0001F);
            float s = Math.max(0.0F, seconds); // a negative time made the bones jump
            t = "true".equals(anim.loop) ? (s % len) : Math.min(s, len);
        }
        for (Bone b : ROOTS) {
            renderBone(b, pose, vc, anim, t, light);
        }
    }

    private static void renderBone(Bone b, PoseStack pose, VertexConsumer vc, Anim anim, float t, int light) {
        float[] arot = {0, 0, 0};
        float[] apos = {0, 0, 0};
        float[] ascale = {1, 1, 1};
        if (anim != null) {
            BoneAnim ba = anim.bones.get(b.name);
            if (ba != null) {
                arot = sample(ba.rot, t, arot);
                apos = sample(ba.pos, t, apos);
                ascale = sample(ba.scale, t, ascale);
            }
        }
        if (ascale[0] <= 0.001F && ascale[1] <= 0.001F && ascale[2] <= 0.001F) {
            return; // scaled to zero: this part (and everything on it) is hidden
        }
        pose.pushPose();
        pose.translate(b.pivot[0] + apos[0], b.pivot[1] + apos[1], b.pivot[2] + apos[2]);
        pose.mulPose(rotation(b.rot[0] + arot[0], b.rot[1] + arot[1], b.rot[2] + arot[2]));
        if (ascale[0] != 1.0F || ascale[1] != 1.0F || ascale[2] != 1.0F) {
            pose.scale(ascale[0], ascale[1], ascale[2]);
        }
        pose.translate(-b.pivot[0], -b.pivot[1], -b.pivot[2]);
        for (Cube c : b.cubes) {
            renderCube(c, pose, vc, light);
        }
        for (Bone child : b.children) {
            renderBone(child, pose, vc, anim, t, light);
        }
        pose.popPose();
    }

    /** Blockbench (Bedrock) rotation: degrees, X and Y inverted, applied in the order Z, Y, X. */
    private static Quaternionf rotation(float x, float y, float z) {
        return new Quaternionf().rotationZYX(z * DEG, -y * DEG, -x * DEG);
    }

    private static void renderCube(Cube c, PoseStack pose, VertexConsumer vc, int light) {
        pose.pushPose();
        pose.translate(c.origin[0], c.origin[1], c.origin[2]);
        pose.mulPose(rotation(c.rot[0], c.rot[1], c.rot[2]));
        pose.translate(-c.origin[0], -c.origin[1], -c.origin[2]);
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        float x0 = Math.min(c.from[0], c.to[0]);
        float x1 = Math.max(c.from[0], c.to[0]);
        float y0 = Math.min(c.from[1], c.to[1]);
        float y1 = Math.max(c.from[1], c.to[1]);
        float z = c.from[2];
        if (c.north != null) { // seen from -Z: the left side of the picture is +X
            float zz = z - 0.1F;
            float[] u = c.north;
            quad(vc, m, n, light, 0.0F, 0.0F, -1.0F,
                    x1, y0, zz, u[0], u[3],
                    x0, y0, zz, u[2], u[3],
                    x0, y1, zz, u[2], u[1],
                    x1, y1, zz, u[0], u[1]);
        }
        if (c.south != null) { // seen from +Z: the left side of the picture is -X
            float zz = z + 0.1F;
            float[] u = c.south;
            quad(vc, m, n, light, 0.0F, 0.0F, 1.0F,
                    x0, y0, zz, u[0], u[3],
                    x1, y0, zz, u[2], u[3],
                    x1, y1, zz, u[2], u[1],
                    x0, y1, zz, u[0], u[1]);
        }
        pose.popPose();
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float au, float av,
                             float bx, float by, float bz, float bu, float bv,
                             float cx, float cy, float cz, float cu, float cv,
                             float dx, float dy, float dz, float du, float dv) {
        vertex(vc, m, n, light, nx, ny, nz, ax, ay, az, au, av);
        vertex(vc, m, n, light, nx, ny, nz, bx, by, bz, bu, bv);
        vertex(vc, m, n, light, nx, ny, nz, cx, cy, cz, cu, cv);
        vertex(vc, m, n, light, nx, ny, nz, dx, dy, dz, du, dv);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, int light, float nx, float ny, float nz,
                               float x, float y, float z, float u, float v) {
        vc.vertex(m, x, y, z)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(currentOverlay)
                .uv2(light)
                .normal(n, nx, ny, nz)
                .endVertex();
    }
}
