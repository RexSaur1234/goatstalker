package com.example.goatstalker.client;

import java.util.Collections;
import java.util.Set;

import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The Blockbench model "StalkerRun" (the bipedal stalker) with its animations, from assets/goatstalker/stalker/.
 * The front of the model is -Z.
 */
public class StalkerRunModel {
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/stalker_run.png");

    public static final ResourceLocation TEXTURE_SCREAM =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/stalker_run_scream.png");

    private static final SkeletalModel MODEL = new SkeletalModel("stalker/model.json", "stalker/animations.json");

    public static void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light) {
        render(pose, vc, animName, seconds, light, OverlayTexture.NO_OVERLAY);
    }

    public static void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light, int overlay) {
        MODEL.render(pose, vc, animName, seconds, light, overlay, Collections.emptySet());
    }

    public static void render(PoseStack pose, VertexConsumer vc, String animName, float seconds, int light, int overlay,
                              Set<String> hidden) {
        MODEL.render(pose, vc, animName, seconds, light, overlay, hidden);
    }
}
