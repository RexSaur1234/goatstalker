package com.example.goatstalker.client;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.example.goatstalker.BipedalMobEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The real (killable) bipedal stalker drawn with the StalkerRun model and the animation that matches its state. */
public class BipedalMobRenderer extends EntityRenderer<BipedalMobEntity> {
    /** 0.85 of the Blockbench size, so the standing model (6.2 blocks) fits the 5.2 block hitbox. */
    private static final float MODEL_SCALE = 0.85F;

    public BipedalMobRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(BipedalMobEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        if (entity.isCeiling()) { // it crawls on the ceiling: hang the model from the top of its box
            pose.translate(0.0D, entity.getBbHeight(), 0.0D);
        }
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw)); // the model's front is -Z
        if (entity.isCeiling()) {
            pose.mulPose(Axis.ZP.rotationDegrees(180.0F));   // upside down
        }
        if (entity.isFallen()) { // knocked down by the Tormentor: lies on its back
            pose.translate(0.0D, 0.25D, 0.0D);
            pose.mulPose(Axis.XP.rotationDegrees(90.0F));
        }
        if (entity.deathTime > 0) { // falls over when it dies
            float f = ((float) entity.deathTime + partialTick - 1.0F) / 20.0F * 1.6F;
            f = Mth.sqrt(f);
            if (f > 1.0F) {
                f = 1.0F;
            }
            pose.mulPose(Axis.ZP.rotationDegrees(f * 90.0F));
        }
        float s = MODEL_SCALE / 16.0F;
        pose.scale(s, s, s);

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        int index = Mth.clamp(entity.getAnim(), 0, BipedalMobEntity.ANIM_NAMES.length - 1);
        float seconds = (entity.tickCount - entity.getClientAnimStart() + partialTick) / 20.0F;
        int overlay = OverlayTexture.pack(OverlayTexture.u(0.0F),
                OverlayTexture.v(entity.hurtTime > 0 || entity.deathTime > 0));
        StalkerRunModel.render(pose, vc, BipedalMobEntity.ANIM_NAMES[index], seconds, light, overlay, hidden(entity.getLost()));
        pose.popPose();
    }

    /** The parts the Tormentor has torn off are not drawn. */
    private static Set<String> hidden(int lost) {
        if (lost == 0) {
            return Collections.emptySet();
        }
        Set<String> s = new HashSet<>();
        if ((lost & BipedalMobEntity.LOST_ARM) != 0) {
            s.add("arm_r");
        }
        if ((lost & BipedalMobEntity.LOST_LEG) != 0) {
            s.add("leg_r");
        }
        if ((lost & BipedalMobEntity.LOST_HEAD) != 0) {
            s.add("head");
        }
        return s;
    }

    @Override
    public ResourceLocation getTextureLocation(BipedalMobEntity entity) {
        return entity.isRoaring() ? StalkerRunModel.TEXTURE_SCREAM : StalkerRunModel.TEXTURE;
    }
}
