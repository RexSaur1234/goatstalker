package com.example.goatstalker;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * The Goat Stalker: the StalkerGoat model (like the Tormentor) with the goat's head, about 3 blocks tall.
 * It crawls through low gaps and breaks wooden blocks in its way when it hunts.
 */
public class StalkerEntity extends Monster {
    private static final EntityDataAccessor<Integer> DATA_ANIM =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM_START =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);

    private boolean hunting = true;
    private int lookTicks = 0;
    private boolean inFight = false;
    private int forcedAnim = -1;
    private int clientAnimStart;
    private int stuckTicks = 0;

    public StalkerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 1000.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIM, TormentorEntity.A_IDLE);
        this.entityData.define(DATA_ANIM_START, 0);
    }

    // ------------------------------ animation (same names as the Tormentor's) ------------------------------
    public int getAnim() {
        return this.entityData.get(DATA_ANIM);
    }

    public int getClientAnimStart() {
        return this.clientAnimStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (this.level().isClientSide && (DATA_ANIM.equals(key) || DATA_ANIM_START.equals(key))) {
            this.clientAnimStart = this.tickCount;
        }
    }

    private void updateAnim() {
        int anim;
        if (this.forcedAnim >= 0) {
            anim = this.forcedAnim;
        } else {
            Vec3 v = getDeltaMovement();
            anim = (v.x * v.x + v.z * v.z > 0.002D) ? TormentorEntity.A_RUN : TormentorEntity.A_IDLE;
        }
        if (anim != this.entityData.get(DATA_ANIM)) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    /** An animation chosen by a fight (-1 = back to its own). */
    public void dAnim(int anim) {
        this.forcedAnim = anim;
        if (anim >= 0) {
            this.entityData.set(DATA_ANIM, anim);
            this.entityData.set(DATA_ANIM_START, this.tickCount);
        }
    }

    public void faceTowards(Entity e) {
        float yaw = (float) (Mth.atan2(-(e.getX() - getX()), e.getZ() - getZ()) * 57.29577951308232D);
        setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    // ------------------------------ fights led by others ------------------------------
    public boolean canBeDirected() {
        return isAlive() && !this.inFight;
    }

    public void joinDirected() {
        this.inFight = true;
        setTarget(null);
        getNavigation().stop();
        if (isCrawling() && canFit(Pose.STANDING)) {
            setPose(Pose.STANDING);
        }
    }

    public void releaseDirected() {
        this.inFight = false;
        setNoGravity(false);
        this.forcedAnim = -1;
    }

    // ------------------------------ crawling and breaking wood ------------------------------
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return pose == Pose.SWIMMING ? EntityDimensions.scalable(0.8F, 0.9F) : EntityDimensions.scalable(0.9F, 2.9F);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) {
        return dims.height * 0.9F;
    }

    public boolean isCrawling() {
        return getPose() == Pose.SWIMMING;
    }

    private boolean canFit(Pose pose) {
        return this.level().noCollision(this, getDimensions(pose).makeBoundingBox(position()));
    }

    /** Stands when there is room, crawls when standing it cannot reach its target but crawling it can. */
    private void adaptPose() {
        LivingEntity t = getTarget();
        if (t == null) {
            if (isCrawling() && canFit(Pose.STANDING)) {
                setPose(Pose.STANDING);
            }
            return;
        }
        Pose old = getPose();
        for (Pose want : new Pose[] {Pose.STANDING, Pose.SWIMMING}) {
            if (want != old && !canFit(want)) {
                continue;
            }
            setPose(want);
            Path path = getNavigation().createPath(t, 0);
            if (path != null && path.canReach()) {
                if (want != old) {
                    getNavigation().stop();
                }
                return;
            }
        }
        setPose(old);
    }

    /** Hunting and stuck: it breaks wooden blocks (planks, logs, doors, fences...) between it and its prey. */
    private void breakWood(ServerLevel sl) {
        LivingEntity t = getTarget();
        if (t == null || !sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            this.stuckTicks = 0;
            return;
        }
        Vec3 v = getDeltaMovement();
        boolean still = v.x * v.x + v.z * v.z < 0.0009D;
        boolean noPath = getNavigation().isDone() || getNavigation().getPath() == null || !getNavigation().getPath().canReach();
        this.stuckTicks = distanceToSqr(t) > 4.0D && (this.horizontalCollision || still || noPath) ? this.stuckTicks + 10 : 0;
        if (this.stuckTicks < 30) {
            return;
        }
        double dx = t.getX() - getX();
        double dz = t.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.5D) {
            return;
        }
        dx /= len;
        dz /= len;
        int broken = 0;
        for (double step = 0.7D; step <= 2.5D && broken < 4; step += 0.5D) {
            for (int h = 0; h <= (isCrawling() ? 0 : 2) && broken < 4; h++) {
                BlockPos pos = BlockPos.containing(getX() + dx * step, getY() + h + 0.1D, getZ() + dz * step);
                BlockState st = sl.getBlockState(pos);
                if (st.isAir() || !st.is(BlockTags.MINEABLE_WITH_AXE) || st.getDestroySpeed(sl, pos) < 0.0F) {
                    continue; // only wood
                }
                sl.destroyBlock(pos, true, this);
                broken++;
            }
        }
        if (broken > 0) {
            sl.playSound(null, getX(), getY() + 1.0D, getZ(), SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.HOSTILE, 1.2F, 0.8F);
            getNavigation().stop();
            this.stuckTicks = 0;
        }
    }

    public void setHunting(boolean hunting) {
        this.hunting = hunting;
    }

    public boolean isHunting() {
        return hunting;
    }

    /** True while the bipedal stalker is fighting this goat: it stands still and cannot kill anybody. */
    public boolean isInFight() {
        return inFight;
    }

    public void setInFight(boolean inFight) {
        this.inFight = inFight;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.inFight;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PeekAtShelterGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false) {
            @Override
            public boolean canUse() {
                return StalkerEntity.this.hunting && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return StalkerEntity.this.hunting && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 64.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 0, false, false,
                target -> this.hunting && target instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        updateAnim();
        if (!this.inFight && this.tickCount % 10 == 0 && this.level() instanceof ServerLevel sl) {
            adaptPose();
            breakWood(sl);
        }
        int life = StalkerConfig.LIFETIME_SECONDS.get() * 20;
        if (life > 0 && this.tickCount > life && !this.inFight) {
            this.discard();
            return;
        }
        if (this.hunting && !this.inFight && StalkerConfig.EYE_CONTACT_KILL.get() && this.tickCount % 2 == 0) {
            checkEyeContact();
        }
    }

    private void checkEyeContact() {
        List<Player> watchers = new ArrayList<>();
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(32.0D))) {
            if (p.isCreative() || p.isSpectator() || !p.isAlive()) {
                continue;
            }
            if (isLookedAtBy(p)) {
                watchers.add(p);
            }
        }
        if (watchers.isEmpty()) {
            this.lookTicks = Math.max(0, this.lookTicks - 2);
            return;
        }
        this.lookTicks += 2;
        if (this.lookTicks >= StalkerConfig.EYE_CONTACT_TICKS.get()) {
            this.lookTicks = 0;
            for (Player p : watchers) {
                p.hurt(this.level().damageSources().genericKill(), 1000.0F);
            }
        }
    }

    /** True if the player is looking at the stalker; glass and panes do not block the view. */
    private boolean isLookedAtBy(Player p) {
        Vec3 from = p.getEyePosition();
        Vec3 to = this.getEyePosition();
        Vec3 dir = to.subtract(from);
        double dist = dir.length();
        if (dist < 0.001D) {
            return true;
        }
        double dot = p.getViewVector(1.0F).normalize().dot(dir.scale(1.0D / dist));
        if (dot < 0.97D) {
            return false;
        }
        return this.level().clip(new ClipContext(from, to, ClipContext.Block.VISUAL,
                ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (target instanceof LivingEntity living) {
            return living.hurt(this.level().damageSources().genericKill(), 1000.0F);
        }
        return false;
    }

    /** Only /kill and the void can hurt it. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Hunting", this.hunting);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Hunting")) {
            this.hunting = tag.getBoolean("Hunting");
        }
    }
}
