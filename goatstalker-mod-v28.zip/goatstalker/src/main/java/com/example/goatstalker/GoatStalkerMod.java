package com.example.goatstalker;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GoatStalkerMod.MODID)
public class GoatStalkerMod {
    public static final String MODID = "goatstalker";

    public GoatStalkerMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener(this::onCreativeTab);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, StalkerConfig.SPEC);
        Crawl.register();
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.STALKER.get(), StalkerEntity.createAttributes().build());
        event.put(ModEntities.BIPEDAL_MOB.get(), BipedalMobEntity.createAttributes().build());
        event.put(ModEntities.TORMENTOR.get(), TormentorEntity.createAttributes().build());
        event.put(ModEntities.EVIL_TORMENTOR.get(), EvilDarkTormentorEntity.createAttributes().build());
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.STALKER_EGG);
            event.accept(ModItems.BIPEDAL_EGG);
            event.accept(ModItems.TORMENTOR_EGG);
            event.accept(ModItems.EVIL_TORMENTOR_EGG);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.EXIT_ITEM);
            event.accept(ModItems.GLITCH_GRASS_ITEM);
            event.accept(ModItems.GLITCH_STONE_ITEM);
            event.accept(ModItems.TV_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.CASSETTE);
        }
    }
}
