package com.example.goatstalker;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class StalkerEntity extends Monster {
    private boolean hunting = true;
    private int lookTicks = 0;

    public StalkerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 1000.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    public void setHunting(boolean hunting) {
        this.hunting = hunting;
    }

    public boolean isHunting() {
        return hunting;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PeekAtShelterGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false) {
            @Override
            public boolean canUse() {
                return StalkerEntity.this.hunting && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return StalkerEntity.this.hunting && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 64.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 0, false, false,
                target -> this.hunting && target instanceof Player p && !p.isCreative() && !p.isSpectator()));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        int life = StalkerConfig.LIFETIME_SECONDS.get() * 20;
        if (life > 0 && this.tickCount > life) {
            this.discard();
            return;
        }
        if (this.hunting && StalkerConfig.EYE_CONTACT_KILL.get() && this.tickCount % 2 == 0) {
            checkEyeContact();
        }
    }

    private void checkEyeContact() {
        List<Player> watchers = new ArrayList<>();
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(32.0D))) {
            if (p.isCreative() || p.isSpectator() || !p.isAlive()) {
                continue;
            }
            if (isLookedAtBy(p)) {
                watchers.add(p);
            }
        }
        if (watchers.isEmpty()) {
            this.lookTicks = Math.max(0, this.lookTicks - 2);
            return;
        }
        this.lookTicks += 2;
        if (this.lookTicks >= StalkerConfig.EYE_CONTACT_TICKS.get()) {
            this.lookTicks = 0;
            for (Player p : watchers) {
                p.hurt(this.level().damageSources().genericKill(), 1000.0F);
            }
        }
    }

    /** True if the player is looking at the stalker; glass and panes do not block the view. */
    private boolean isLookedAtBy(Player p) {
        Vec3 from = p.getEyePosition();
        Vec3 to = this.getEyePosition();
        Vec3 dir = to.subtract(from);
        double dist = dir.length();
        if (dist < 0.001D) {
            return true;
        }
        double dot = p.getViewVector(1.0F).normalize().dot(dir.scale(1.0D / dist));
        if (dot < 0.97D) {
            return false;
        }
        return this.level().clip(new ClipContext(from, to, ClipContext.Block.VISUAL,
                ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (target instanceof LivingEntity living) {
            return living.hurt(this.level().damageSources().genericKill(), 1000.0F);
        }
        return false;
    }

    /** Only /kill and the void can hurt it. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Hunting", this.hunting);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Hunting")) {
            this.hunting = tag.getBoolean("Hunting");
        }
    }
}
