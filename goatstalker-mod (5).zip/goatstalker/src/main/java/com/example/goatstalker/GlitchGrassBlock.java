package com.example.goatstalker;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** A glowing grass block you can walk through. Touch it and you are pulled into Nullspace 1 (Island). */
public class GlitchGrassBlock extends Block {
    public static final int LIFETIME_TICKS = 1800; // 90 seconds, then it turns back into normal grass

    public GlitchGrassBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, LIFETIME_TICKS);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.setBlock(pos, Blocks.GRASS_BLOCK.defaultBlockState(), 3);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            if (NullspaceEvents.enterIsland(sp)) {
                level.setBlock(pos, Blocks.GRASS_BLOCK.defaultBlockState(), 3);
            }
        }
    }
}
