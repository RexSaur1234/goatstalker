package com.example.goatstalker.client;

import com.example.goatstalker.BipedalEntity;
import com.example.goatstalker.GoatStalkerMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Flat picture of the tall creature, always turned to the camera. The feet are at the entity position. */
public class BipedalRenderer extends EntityRenderer<BipedalEntity> {
    private static final ResourceLocation TREE_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_tree.png");
    private static final ResourceLocation ROOF_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_roof.png");
    private static final ResourceLocation RUNNER_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/bipedal_runner.png");

    // sizes in blocks = height * picture ratio
    private static final float TREE_H = BipedalEntity.TREE_H, TREE_W = BipedalEntity.TREE_W;
    private static final float ROOF_H = 2.6F, ROOF_W = 2.128F;     // ratio 0.8184 (head and shoulders)
    private static final float RUNNER_H = 4.4F, RUNNER_W = 3.360F; // ratio 0.7637 (whole figure)

    public BipedalRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(BipedalEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        int kind = entity.getKind();
        float w = kind == BipedalEntity.TREE ? TREE_W : kind == BipedalEntity.ROOF ? ROOF_W : RUNNER_W;
        float h = kind == BipedalEntity.TREE ? TREE_H : kind == BipedalEntity.ROOF ? ROOF_H : RUNNER_H;

        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - this.entityRenderDispatcher.camera.getYRot()));
        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));

        vertex(vc, matrix, normal, -w / 2, 0.0F, 0.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, 0.0F, 1.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, h, 1.0F, 0.0F, light);
        vertex(vc, matrix, normal, -w / 2, h, 0.0F, 0.0F, light);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f matrix, Matrix3f normal,
                               float x, float y, float u, float v, int light) {
        vc.vertex(matrix, x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(BipedalEntity entity) {
        int kind = entity.getKind();
        return kind == BipedalEntity.TREE ? TREE_TEX : kind == BipedalEntity.ROOF ? ROOF_TEX : RUNNER_TEX;
    }
}
