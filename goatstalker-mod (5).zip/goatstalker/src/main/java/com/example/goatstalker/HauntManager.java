package com.example.goatstalker;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Night haunt, step by step:
 * 1. "GO OUTSIDE" + darkness; if the player is indoors the head shows under the ceiling, then goes up and vanishes.
 * 2. After ~4 s the hand appears in a window (if there is one nearby).
 * 3. Then the stalker itself appears outside.
 * Day: the stalker stands far away in the field and just watches.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class HauntManager {
    private record Pending(long time, int step) {}

    private static final Map<UUID, Long> NEXT_HAUNT = new HashMap<>();
    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        if (!(event.player instanceof ServerPlayer player) || player.tickCount % 10 != 0) {
            return;
        }
        if (!StalkerConfig.HAUNTS_ENABLED.get()) {
            return;
        }
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            return;
        }

        UUID id = player.getUUID();
        long now = level.getGameTime();

        Pending pending = PENDING.get(id);
        if (pending != null) {
            if (now >= pending.time()) {
                PENDING.remove(id);
                continueNightHaunt(player, level, now, pending.step());
            }
            return;
        }
        if (player.isCreative() || player.isSpectator()) {
            return;
        }

        long next = NEXT_HAUNT.computeIfAbsent(id, k -> now + randomInterval(level));
        if (now < next) {
            return;
        }

        boolean night = isNight(level);
        if (!night && !StalkerConfig.DAY_WATCHERS.get()) {
            NEXT_HAUNT.put(id, now + 600);
            return;
        }
        boolean stalkerNearby = !level.getEntitiesOfClass(StalkerEntity.class,
                player.getBoundingBox().inflate(96.0D)).isEmpty();
        int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, player.getBlockX(), player.getBlockZ());
        if (stalkerNearby || player.getY() < surface - 12) {
            NEXT_HAUNT.put(id, now + 400);
            return;
        }

        NEXT_HAUNT.put(id, now + randomInterval(level));
        if (night) {
            startNightHaunt(player, level, now);
        } else {
            spawnStalker(player, level, false);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        NEXT_HAUNT.remove(event.getEntity().getUUID());
        PENDING.remove(event.getEntity().getUUID());
    }

    /** Test commands: /goatstalker haunt | title | head | hand | stalker | watcher */
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("haunt").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    startNightHaunt(p, p.serverLevel(), p.serverLevel().getGameTime());
                    return 1;
                }))
                .then(Commands.literal("title").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 50, 20));
                    p.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("message.goatstalker.go_outside")));
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 160, 0, false, false));
                    return 1;
                }))
                .then(Commands.literal("head").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    if (!spawnHead(p, p.serverLevel())) {
                        ctx.getSource().sendFailure(Component.literal("No ceiling found. Stand indoors under a roof."));
                        return 0;
                    }
                    return 1;
                }))
                .then(Commands.literal("hand").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    if (!spawnHand(p, p.serverLevel())) {
                        ctx.getSource().sendFailure(Component.literal("No window found within 6 blocks."));
                        return 0;
                    }
                    return 1;
                }))
                .then(Commands.literal("stalker").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    spawnStalker(p, p.serverLevel(), true);
                    return 1;
                }))
                .then(Commands.literal("watcher").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    spawnStalker(p, p.serverLevel(), false);
                    return 1;
                })));
    }

    private static long randomInterval(ServerLevel level) {
        int avg = StalkerConfig.AVERAGE_SECONDS.get() * 20;
        return avg / 2 + level.random.nextInt(Math.max(1, avg));
    }

    private static boolean isNight(ServerLevel level) {
        long t = level.getDayTime() % 24000L;
        return t >= 13000L && t < 23000L;
    }

    private static void startNightHaunt(ServerPlayer player, ServerLevel level, long now) {
        player.connection.send(new ClientboundSetTitlesAnimationPacket(5, 50, 20));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("message.goatstalker.go_outside")));
        player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 160, 0, false, false));
        if (roll(level, StalkerConfig.HEAD_CHANCE.get())) {
            spawnHead(player, level);
        }
        PENDING.put(player.getUUID(), new Pending(now + 80, 0));
    }

    private static void continueNightHaunt(ServerPlayer player, ServerLevel level, long now, int step) {
        if (step == 0 && roll(level, StalkerConfig.HAND_CHANCE.get()) && spawnHand(player, level)) {
            PENDING.put(player.getUUID(), new Pending(now + 50, 1));
            return;
        }
        spawnStalker(player, level, true);
    }

    private static boolean roll(ServerLevel level, int percent) {
        return level.random.nextInt(100) < percent;
    }

    private static void spawnPart(ServerLevel level, int part, double x, double centerY, double z) {
        StalkerPartEntity e = ModEntities.PART.get().create(level);
        if (e == null) {
            return;
        }
        e.setPart(part);
        e.setPos(x, centerY - 0.8D, z); // the entity box is 1.6 tall, the picture is drawn around its middle
        level.addFreshEntity(e);
    }

    /** The head comes out of the ceiling in front of the player. */
    private static boolean spawnHead(ServerPlayer player, ServerLevel level) {
        Vec3 eye = player.getEyePosition();
        RandomSource r = level.random;
        for (int i = 0; i < 12; i++) {
            double dist = i == 11 ? 0.8D : 2.0D + r.nextDouble() * 2.0D;
            double a = Math.toRadians(player.getYRot() + (r.nextDouble() - 0.5D) * 70.0D);
            double x = eye.x - Math.sin(a) * dist;
            double z = eye.z + Math.cos(a) * dist;
            BlockPos col = BlockPos.containing(x, eye.y, z);
            if (!level.getBlockState(col).getCollisionShape(level, col).isEmpty()) {
                continue;
            }
            int ceiling = Integer.MIN_VALUE;
            for (int dy = 1; dy <= 6; dy++) {
                BlockPos p = col.above(dy);
                if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) {
                    ceiling = dy >= 2 ? p.getY() : Integer.MIN_VALUE;
                    break;
                }
            }
            if (ceiling == Integer.MIN_VALUE) {
                continue;
            }
            // top of the picture is 0.5 inside the ceiling, so the head is "coming out of it"
            spawnPart(level, StalkerPartEntity.HEAD, x, ceiling - 0.3D, z);
            return true;
        }
        return false;
    }

    /** The hand appears right behind a window glass / glass pane near the player. */
    private static boolean spawnHand(ServerPlayer player, ServerLevel level) {
        Vec3 eye = player.getEyePosition();
        RandomSource r = level.random;
        for (int i = 0; i < 64; i++) {
            double angle = r.nextDouble() * Math.PI * 2.0D;
            double reach = 6.0D;
            Vec3 dir = new Vec3(Math.cos(angle), (r.nextDouble() - 0.5D) * 0.2D, Math.sin(angle)).normalize();
            for (double d = 0.5D; d < reach; d += 0.25D) {
                Vec3 p = eye.add(dir.scale(d));
                BlockPos bp = BlockPos.containing(p);
                BlockState st = level.getBlockState(bp);
                if (isWindow(st)) {
                    Vec3 out = p.add(dir.scale(0.8D));
                    BlockPos outPos = BlockPos.containing(out);
                    if (level.getBlockState(outPos).getCollisionShape(level, outPos).isEmpty()) {
                        spawnPart(level, StalkerPartEntity.HAND, out.x, out.y, out.z);
                        return true;
                    }
                    break;
                }
                if (!st.getCollisionShape(level, bp).isEmpty()) {
                    break; // a solid wall: this direction has no window
                }
            }
        }
        return false;
    }

    private static boolean isWindow(BlockState st) {
        return st.getBlock() instanceof IronBarsBlock || st.is(BlockTags.IMPERMEABLE);
    }

    private static void spawnStalker(ServerPlayer player, ServerLevel level, boolean night) {
        Vec3 eye = player.getEyePosition();
        RandomSource r = level.random;
        BlockPos best = null;
        BlockPos fallback = null;

        for (int i = 0; i < 32 && best == null; i++) {
            double angle = r.nextDouble() * Math.PI * 2.0D;
            double dist = night ? 6 + r.nextInt(7) : 24 + r.nextInt(13);
            int x = Mth.floor(player.getX() + Math.cos(angle) * dist);
            int z = Mth.floor(player.getZ() + Math.sin(angle) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (Math.abs(y - player.getY()) > 12) {
                continue;
            }
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.getFluidState(pos.below()).isEmpty()) {
                continue;
            }
            Vec3 target = new Vec3(x + 0.5D, y + 2.0D, z + 0.5D);
            boolean visible = level.clip(new ClipContext(eye, target, ClipContext.Block.VISUAL,
                    ClipContext.Fluid.NONE, player)).getType() == HitResult.Type.MISS;
            if (visible) {
                best = pos;
            } else if (fallback == null) {
                fallback = pos;
            }
        }

        BlockPos spawn = best != null ? best : fallback;
        if (spawn == null) {
            return;
        }
        StalkerEntity stalker = ModEntities.STALKER.get().create(level);
        if (stalker == null) {
            return;
        }
        stalker.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, r.nextFloat() * 360.0F, 0.0F);
        stalker.setHunting(night);
        stalker.setPersistenceRequired();
        if (night) {
            stalker.setTarget(player);
        }
        level.addFreshEntity(stalker);
    }
}
