package com.example.goatstalker;

import net.minecraftforge.common.ForgeConfigSpec;

public class StalkerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue HAUNTS_ENABLED;
    public static final ForgeConfigSpec.BooleanValue DAY_WATCHERS;
    public static final ForgeConfigSpec.BooleanValue EYE_CONTACT_KILL;
    public static final ForgeConfigSpec.IntValue AVERAGE_SECONDS;
    public static final ForgeConfigSpec.IntValue EYE_CONTACT_TICKS;
    public static final ForgeConfigSpec.IntValue LIFETIME_SECONDS;
    public static final ForgeConfigSpec.IntValue HEAD_CHANCE;
    public static final ForgeConfigSpec.IntValue HAND_CHANCE;
    public static final ForgeConfigSpec.BooleanValue TREE_ENABLED;
    public static final ForgeConfigSpec.IntValue TREE_MINUTES;
    public static final ForgeConfigSpec.BooleanValue NULLSPACE_ENABLED;
    public static final ForgeConfigSpec.IntValue NULLSPACE_MINUTES;
    public static final ForgeConfigSpec.IntValue NULLSPACE_MAX_STAY_MINUTES;
    public static final ForgeConfigSpec.BooleanValue GLITCH_ENABLED;
    public static final ForgeConfigSpec.IntValue GLITCH_MINUTES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        HAUNTS_ENABLED = b.comment("Enable automatic haunts (stalker appears on its own)")
                .define("hauntsEnabled", true);
        AVERAGE_SECONDS = b.comment("Average seconds between haunts for each player")
                .defineInRange("averageSecondsBetweenHaunts", 180, 10, 36000);
        DAY_WATCHERS = b.comment("During the day the stalker appears far away and only watches")
                .define("daytimeWatchers", true);
        EYE_CONTACT_KILL = b.comment("The hunting stalker kills a player who keeps looking at it")
                .define("eyeContactKills", true);
        EYE_CONTACT_TICKS = b.comment("How many ticks of looking at it are needed to die (20 ticks = 1 second)")
                .defineInRange("eyeContactTicks", 40, 1, 1200);
        LIFETIME_SECONDS = b.comment("Stalker disappears after this many seconds (0 = never)")
                .defineInRange("lifetimeSeconds", 90, 0, 36000);
        HEAD_CHANCE = b.comment("Percent chance that the head shows up under the ceiling during a night haunt (player must be indoors)")
                .defineInRange("ceilingHeadChancePercent", 80, 0, 100);
        HAND_CHANCE = b.comment("Percent chance that the hand shows up in a window before the stalker appears")
                .defineInRange("windowHandChancePercent", 70, 0, 100);
        TREE_ENABLED = b.comment("The creature peeks from behind a tree every few minutes")
                .define("treeEventEnabled", true);
        TREE_MINUTES = b.comment("Minutes between tree events")
                .defineInRange("treeEventMinutes", 10, 1, 600);
        NULLSPACE_ENABLED = b.comment("Teleport the player to Nullspace 2 (the village) every few minutes")
                .define("nullspaceEnabled", true);
        NULLSPACE_MINUTES = b.comment("Minutes between teleports to Nullspace 2")
                .defineInRange("nullspaceMinutes", 10, 1, 600);
        NULLSPACE_MAX_STAY_MINUTES = b.comment("If the player does not leave Nullspace 2 by himself, he is sent back after this many minutes")
                .defineInRange("nullspaceMaxStayMinutes", 15, 1, 600);
        GLITCH_ENABLED = b.comment("A glowing glitched grass block sometimes appears near the player and leads to Nullspace 1 (Island)")
                .define("glitchGrassEnabled", true);
        GLITCH_MINUTES = b.comment("Average minutes between glitched grass blocks (the real time is random, 0.5x to 1.5x)")
                .defineInRange("glitchGrassMinutes", 15, 1, 600);
        SPEC = b.build();
    }
}
