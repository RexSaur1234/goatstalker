package com.example.goatstalker;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Nullspace 2: a flat night world with one gravel street and small village houses on both sides.
 * The ground (grass) is at y = 3. The street runs along +Z. The special house with the exit block is at the end.
 */
public class Nullspace {
    public static final ResourceKey<Level> DIM =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(GoatStalkerMod.MODID, "nullspace"));

    public static final ResourceKey<Level> ISLAND =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(GoatStalkerMod.MODID, "island"));

    public static final int TOWER_Z = 140;         // the tower on the Island stands at x=0, z=140
    public static final BlockPos GLITCH_STONE_POS = new BlockPos(0, 3, TOWER_Z);

    public static boolean isNullspace(ResourceKey<Level> key) {
        return key == DIM || key == ISLAND;
    }

    public static final int G = 3;                 // y of the grass layer
    public static final double GROUND_TOP = 4.0D;  // y where a player stands on the street
    public static final int FIRST_Z = 8;           // z of the first house
    public static final int STEP = 9;              // distance between houses along the street
    public static final int COUNT = 11;            // houses on each side
    public static final BlockPos EXIT_POS = new BlockPos(0, G + 1, 112);

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState COBBLE = Blocks.COBBLESTONE.defaultBlockState();
    private static final BlockState PLANKS = Blocks.OAK_PLANKS.defaultBlockState();

    /** Builds the village the first time somebody comes (the exit block is placed last as a marker). */
    public static void ensureBuilt(ServerLevel l) {
        if (l.getBlockState(EXIT_POS).is(ModBlocks.EXIT.get())) {
            return;
        }
        List<BlockPos> refresh = new ArrayList<>();
        RandomSource r = RandomSource.create(1234L);

        for (int x = -2; x <= 2; x++) {
            for (int z = -6; z <= 107; z++) {
                set(l, x, G, z, r.nextInt(5) == 0 ? COBBLE : Blocks.GRAVEL.defaultBlockState());
            }
        }
        for (int i = 0; i < COUNT; i++) {
            int z = FIRST_Z + STEP * i;
            house(l, -10, z, false, refresh);
            house(l, 4, z, true, refresh);
        }
        specialHouse(l, refresh);

        // second pass: fences, glass panes and stairs connect to their neighbours
        for (BlockPos p : refresh) {
            l.setBlock(p, Block.updateFromNeighbourShapes(l.getBlockState(p), l, p), 2);
        }
        l.setBlock(EXIT_POS, ModBlocks.EXIT.get().defaultBlockState(), 3);
    }

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 2);
    }

    private static void setRefresh(ServerLevel l, int x, int y, int z, BlockState s, List<BlockPos> refresh) {
        set(l, x, y, z, s);
        refresh.add(new BlockPos(x, y, z));
    }

    /** 7x7 house, door on the street side, ladder to a flat roof with a fence. */
    private static void house(ServerLevel l, int ox, int oz, boolean mirror, List<BlockPos> refresh) {
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();

        for (int lx = 0; lx <= 6; lx++) {
            for (int lz = 0; lz <= 6; lz++) {
                int wx = mirror ? ox + 6 - lx : ox + lx;
                int wz = oz + lz;
                boolean perim = lx == 0 || lx == 6 || lz == 0 || lz == 6;
                boolean corner = (lx == 0 || lx == 6) && (lz == 0 || lz == 6);
                set(l, wx, G, wz, COBBLE);
                for (int y = G + 1; y <= G + 3; y++) {
                    BlockState s = !perim ? AIR : corner ? COBBLE : (y == G + 1 ? COBBLE : PLANKS);
                    set(l, wx, y, wz, s);
                }
                set(l, wx, G + 4, wz, perim ? log : PLANKS);
                if (perim) {
                    setRefresh(l, wx, G + 5, wz, fence, refresh);
                }
            }
        }
        int doorX = mirror ? ox : ox + 6;
        set(l, doorX, G + 1, oz + 3, AIR);
        set(l, doorX, G + 2, oz + 3, AIR);

        int backX = mirror ? ox + 6 : ox;
        setRefresh(l, backX, G + 2, oz + 3, pane, refresh);
        setRefresh(l, ox + 3, G + 2, oz, pane, refresh);
        setRefresh(l, ox + 3, G + 2, oz + 6, pane, refresh);

        int ladderX = mirror ? ox + 5 : ox + 1;
        BlockState ladder = Blocks.LADDER.defaultBlockState()
                .setValue(LadderBlock.FACING, mirror ? Direction.WEST : Direction.EAST);
        for (int y = G + 1; y <= G + 4; y++) {
            set(l, ladderX, y, oz + 1, ladder);
        }
        set(l, mirror ? ox + 1 : ox + 5, G + 1, oz + 5, Blocks.TORCH.defaultBlockState());
    }

    /** The house at the end of the street: cobblestone gable, bookshelves, and the exit block inside. */
    private static void specialHouse(ServerLevel l, List<BlockPos> refresh) {
        int x0 = -4, x1 = 4, z0 = 108, z1 = 116;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean perim = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                set(l, x, G, z, COBBLE);
                for (int y = G + 1; y <= G + 4; y++) {
                    BlockState s = !perim ? AIR : corner ? COBBLE : (y <= G + 2 ? COBBLE : PLANKS);
                    set(l, x, y, z, s);
                }
            }
        }
        set(l, 0, G + 1, z0, AIR);
        set(l, 0, G + 2, z0, AIR);
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();
        setRefresh(l, x0, G + 3, 112, pane, refresh);
        setRefresh(l, x1, G + 3, 112, pane, refresh);
        setRefresh(l, 0, G + 3, z1, pane, refresh);
        setRefresh(l, -2, G + 3, z0, pane, refresh);
        setRefresh(l, 2, G + 3, z0, pane, refresh);

        // gable roof made of stairs, with cobblestone gable ends
        for (int k = 0; k <= 5; k++) {
            int y = G + 5 + k;
            for (int x = -5 + k; x <= 5 - k; x++) {
                for (int z = 107; z <= 117; z++) {
                    boolean edgeZ = z == 107 || z == 117;
                    if (k < 5 && x == -5 + k) {
                        setRefresh(l, x, y, z, stairs(Direction.EAST), refresh);
                    } else if (k < 5 && x == 5 - k) {
                        setRefresh(l, x, y, z, stairs(Direction.WEST), refresh);
                    } else {
                        set(l, x, y, z, (k < 5 && edgeZ) ? COBBLE : PLANKS);
                    }
                }
            }
        }

        // interior: bookshelves, crafting table, torches
        BlockState books = Blocks.BOOKSHELF.defaultBlockState();
        for (int x = -3; x <= 3; x++) {
            set(l, x, G + 1, 115, books);
            set(l, x, G + 2, 115, books);
        }
        for (int z = 110; z <= 114; z++) {
            set(l, -3, G + 1, z, books);
            set(l, -3, G + 2, z, books);
            set(l, 3, G + 1, z, books);
            set(l, 3, G + 2, z, books);
        }
        set(l, -2, G + 1, 110, Blocks.CRAFTING_TABLE.defaultBlockState());
        BlockState torch = Blocks.TORCH.defaultBlockState();
        set(l, -3, G + 3, 115, torch);
        set(l, 3, G + 3, 115, torch);
        set(l, -3, G + 3, 110, torch);
        set(l, 3, G + 3, 110, torch);
    }

    private static BlockState stairs(Direction facing) {
        return Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, facing);
    }

    /** Island (Nullspace 1): a plain flat world, a tower far away, a stone path leading to it. */
    public static void ensureIslandBuilt(ServerLevel l) {
        if (l.getBlockState(GLITCH_STONE_POS).is(ModBlocks.GLITCH_STONE.get())) {
            return;
        }
        RandomSource r = RandomSource.create(4321L);
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState cobble = COBBLE;
        BlockState pale = Blocks.DIORITE.defaultBlockState();
        int x0 = -4, x1 = 4, z0 = TOWER_Z - 4, z1 = TOWER_Z + 4;
        int height = 22;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean perim = x == x0 || x == x1 || z == z0 || z == z1;
                set(l, x, G, z, Blocks.SMOOTH_STONE.defaultBlockState());
                for (int y = G + 1; y <= G + height; y++) {
                    BlockState s;
                    if (!perim) {
                        s = AIR;
                    } else if (y <= G + 4) {
                        s = pale;
                    } else {
                        s = r.nextInt(3) == 0 ? cobble : brick;
                    }
                    set(l, x, y, z, s);
                }
                // battlements on top
                if (perim && (x + z) % 2 == 0) {
                    set(l, x, G + height + 1, z, brick);
                }
            }
        }
        // door in the south wall (the side you come from)
        for (int y = G + 1; y <= G + 3; y++) {
            set(l, 0, y, z0, AIR);
        }
        // irregular windows
        for (int y = G + 7; y <= G + 19; y += 4) {
            set(l, x0, y, TOWER_Z + r.nextInt(5) - 2, AIR);
            set(l, x1, y, TOWER_Z + r.nextInt(5) - 2, AIR);
            set(l, r.nextInt(5) - 2, y, z1, AIR);
            set(l, r.nextInt(5) - 2, y, z0, AIR);
        }
        // blocks sticking out of the walls
        for (int i = 0; i < 14; i++) {
            int y = G + 5 + r.nextInt(height - 5);
            int side = r.nextInt(4);
            int off = r.nextInt(7) - 3;
            switch (side) {
                case 0 -> set(l, x0 - 1, y, TOWER_Z + off, cobble);
                case 1 -> set(l, x1 + 1, y, TOWER_Z + off, cobble);
                case 2 -> set(l, off, y, z0 - 1, cobble);
                default -> set(l, off, y, z1 + 1, cobble);
            }
        }
        // stone path from the tower door out into the field
        for (int z = z0 - 40; z < z0; z++) {
            for (int x = -1; x <= 1; x++) {
                set(l, x, G, z, Blocks.ANDESITE.defaultBlockState());
            }
        }
        // the glowing broken stone in the middle (placed last: it is also the "already built" marker)
        l.setBlock(GLITCH_STONE_POS, ModBlocks.GLITCH_STONE.get().defaultBlockState(), 3);
    }
}
