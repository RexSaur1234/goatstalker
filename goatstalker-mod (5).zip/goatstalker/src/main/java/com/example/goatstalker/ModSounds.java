package com.example.goatstalker;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, GoatStalkerMod.MODID);

    public static final RegistryObject<SoundEvent> SCREAM = SOUNDS.register("stalker_scream",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "stalker_scream")));

    /** Music that plays while you run from the creature on the Island (53 seconds, repeated by the mod). */
    public static final RegistryObject<SoundEvent> ISLAND_CHASE = SOUNDS.register("island_chase",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(GoatStalkerMod.MODID, "island_chase")));
}
