package com.example.goatstalker;

import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;

/**
 * The tall thin creature, in three roles:
 * TREE   - peeks from behind a tree, hits for half of your health if you come close, after 10 s slides left and vanishes.
 * ROOF   - stands on a roof in Nullspace 2, then sinks down.
 * RUNNER - runs along the street after the player; when it catches him he screams and is sent back.
 */
public class BipedalEntity extends Entity {
    public static final int TREE = 0;
    public static final int ROOF = 1;
    public static final int RUNNER = 2;

    /** Size of the tree picture in blocks (height * ratio 0.4521); the renderer and the spawn code both use it. */
    public static final float TREE_H = 4.2F;
    public static final float TREE_W = 1.899F;

    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(BipedalEntity.class, EntityDataSerializers.INT);

    private UUID target;
    private double slideX;
    private double slideZ;
    private boolean hit;

    public BipedalEntity(EntityType<? extends BipedalEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_KIND, TREE);
    }

    public int getKind() {
        return this.entityData.get(DATA_KIND);
    }

    public void setup(int kind, UUID target) {
        this.entityData.set(DATA_KIND, kind);
        this.target = target;
    }

    public void setSlide(double x, double z) {
        this.slideX = x;
        this.slideZ = z;
    }

    /** The picture is taller than the entity box, so make the culling box big enough. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return new AABB(getX() - 3, getY() - 1, getZ() - 3, getX() + 3, getY() + 6, getZ() + 3);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel sl)) {
            return;
        }
        ServerPlayer p = this.target == null ? null : sl.getServer().getPlayerList().getPlayer(this.target);
        if (p == null || p.level() != this.level() || !p.isAlive()) {
            this.discard();
            return;
        }
        switch (getKind()) {
            case TREE -> tickTree(p);
            case ROOF -> tickRoof(sl, p);
            default -> tickRunner(sl, p);
        }
    }

    private void tickTree(ServerPlayer p) {
        if (this.tickCount < 200) {
            if (!this.hit) {
                double dx = p.getX() - getX();
                double dz = p.getZ() - getZ();
                if (dx * dx + dz * dz < 25.0D) { // the player came closer than 5 blocks
                    this.hit = true;
                    halveHealth(p);
                    this.tickCount = 200;        // and it leaves right away
                }
            }
            return;
        }
        if (this.tickCount < 214) {
            setPos(getX() + this.slideX * 0.07D, getY(), getZ() + this.slideZ * 0.07D);
            return;
        }
        this.discard();
    }

    private void halveHealth(ServerPlayer p) {
        float cur = p.getHealth();
        float dmg = cur / 2.0F;
        if (cur - dmg < 1.0F) {
            dmg = cur - 1.0F;
        }
        if (dmg > 0.0F) {
            p.hurt(this.level().damageSources().magic(), dmg);
        }
    }

    private void tickRoof(ServerLevel sl, ServerPlayer p) {
        if (this.tickCount >= 60 && this.tickCount < 82) {
            setPos(getX(), getY() - 0.13D, getZ()); // head and shoulders go down behind the roof
        } else if (this.tickCount >= 82) {
            BipedalEntity runner = ModEntities.BIPEDAL.get().create(sl);
            if (runner != null) {
                runner.setup(RUNNER, p.getUUID());
                runner.setPos(0.5D, Nullspace.GROUND_TOP, getZ());
                sl.addFreshEntity(runner);
            }
            this.discard();
        }
    }

    private void tickRunner(ServerLevel sl, ServerPlayer p) {
        double dx = p.getX() - getX();
        double dz = p.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 2.6D) {
            NullspaceEvents.stopChaseMusic(p);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.SCREAM.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
            NullspaceEvents.schedule(sl.getServer(), 30, () -> NullspaceEvents.returnPlayerIfInNullspace(p));
            this.discard();
            return;
        }
        setPos(getX() + dx / d * 0.42D, Nullspace.GROUND_TOP, getZ() + dz / d * 0.42D);
        if (this.tickCount % 4 == 0) {
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GRAVEL_STEP, SoundSource.HOSTILE, 1.5F, 0.6F);
        }
        if (this.tickCount > 900) {
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
