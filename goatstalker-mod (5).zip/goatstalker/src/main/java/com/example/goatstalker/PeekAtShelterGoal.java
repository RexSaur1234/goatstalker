package com.example.goatstalker;

import java.util.EnumSet;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * When the player hides in a closed house and the stalker cannot reach him, it walks to the nearest window
 * (a place with a clear view into the room) or to the outside of the nearest door and stands there, staring in.
 */
public class PeekAtShelterGoal extends Goal {
    private final StalkerEntity mob;
    private BlockPos spot;
    private BlockPos playerPosAtPick;
    private int cooldown = 0;

    public PeekAtShelterGoal(StalkerEntity mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (!mob.isHunting()) {
            return false;
        }
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive()) {
            return false;
        }
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        cooldown = 10;
        if (isReachable(target)) {
            return false;
        }
        spot = findSpot(target);
        if (spot == null) {
            return false;
        }
        playerPosAtPick = target.blockPosition();
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity target = mob.getTarget();
        return mob.isHunting() && spot != null && target != null && target.isAlive()
                && target.blockPosition().distSqr(playerPosAtPick) < 25.0D;
    }

    @Override
    public void start() {
        moveToSpot();
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target != null) {
            mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        }
        if (mob.distanceToSqr(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D) < 2.0D) {
            mob.getNavigation().stop();
        } else if (mob.getNavigation().isDone()) {
            moveToSpot();
        }
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
        spot = null;
        cooldown = 20;
    }

    private void moveToSpot() {
        mob.getNavigation().moveTo(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D, 1.2D);
    }

    private boolean isReachable(LivingEntity target) {
        Path path = mob.getNavigation().createPath(target, 0);
        return path != null && path.canReach();
    }

    private BlockPos findSpot(LivingEntity target) {
        Level level = mob.level();
        Vec3 eye = target.getEyePosition();
        BlockPos origin = target.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;

        // 1) outside places with a clear view into the room (windows, glass panes)
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                if (dx * dx + dz * dz < 4) {
                    continue;
                }
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                if (!level.hasChunkAt(new BlockPos(x, origin.getY(), z))) {
                    continue;
                }
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (Math.abs(y - origin.getY()) > 2) {
                    continue;
                }
                BlockPos pos = new BlockPos(x, y, z);
                if (!isStandable(level, pos)) {
                    continue;
                }
                Vec3 head = new Vec3(x + 0.5D, y + 2.0D, z + 0.5D);
                if (level.clip(new ClipContext(eye, head, ClipContext.Block.VISUAL,
                        ClipContext.Fluid.NONE, target)).getType() != HitResult.Type.MISS) {
                    continue;
                }
                double d = pos.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = pos;
                }
            }
        }

        // 2) the outside of a door near the player
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-6, -2, -6), origin.offset(6, 2, 6))) {
            BlockState s = level.getBlockState(p);
            if (!s.is(BlockTags.DOORS) || !s.hasProperty(DoorBlock.HALF)
                    || s.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) {
                continue;
            }
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                BlockPos out = p.relative(dir);
                BlockPos in = p.relative(dir.getOpposite());
                if (out.distSqr(origin) <= in.distSqr(origin) || !isStandable(level, out)) {
                    continue;
                }
                double d = out.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = out.immutable();
                }
            }
        }
        return best;
    }

    private static boolean isStandable(Level level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                && level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()
                && level.getBlockState(pos.above(2)).getCollisionShape(level, pos.above(2)).isEmpty();
    }
}
