package com.example.goatstalker;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * A separate body part of the stalker used for scares:
 * HEAD hangs from the ceiling for a moment, then goes up into the ceiling and disappears.
 * HAND shows up in a window for a moment and disappears.
 */
public class StalkerPartEntity extends Entity {
    public static final int HEAD = 0;
    public static final int HAND = 1;

    public static final int HEAD_HOLD_TICKS = 60;
    public static final int HEAD_LIFE_TICKS = 80;
    public static final int HAND_LIFE_TICKS = 50;

    private static final EntityDataAccessor<Integer> DATA_PART =
            SynchedEntityData.defineId(StalkerPartEntity.class, EntityDataSerializers.INT);

    public StalkerPartEntity(EntityType<? extends StalkerPartEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_PART, HEAD);
    }

    public int getPart() {
        return this.entityData.get(DATA_PART);
    }

    public void setPart(int part) {
        this.entityData.set(DATA_PART, part);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        if (getPart() == HEAD) {
            if (this.tickCount > HEAD_HOLD_TICKS) {
                this.setPos(this.getX(), this.getY() + 0.12D, this.getZ());
            }
            if (this.tickCount > HEAD_LIFE_TICKS) {
                this.discard();
            }
        } else if (this.tickCount > HAND_LIFE_TICKS) {
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setPart(tag.getInt("Part"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Part", getPart());
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
