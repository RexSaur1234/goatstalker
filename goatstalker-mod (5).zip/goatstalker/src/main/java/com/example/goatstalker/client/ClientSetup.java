package com.example.goatstalker.client;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.ModEntities;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.STALKER.get(), StalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.PART.get(), StalkerPartRenderer::new);
        event.registerEntityRenderer(ModEntities.BIPEDAL.get(), BipedalRenderer::new);
    }
}
