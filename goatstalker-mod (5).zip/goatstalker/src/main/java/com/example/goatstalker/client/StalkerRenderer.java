package com.example.goatstalker.client;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.StalkerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Flat image of the creature that always turns to face the camera (like in the video). */
public class StalkerRenderer extends EntityRenderer<StalkerEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/goat_stalker.png");
    private static final float HALF_WIDTH = 1.6F;
    private static final float HEIGHT = 3.2F;

    public StalkerRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(StalkerEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - this.entityRenderDispatcher.camera.getYRot()));

        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int full = LightTexture.FULL_BRIGHT;

        vertex(vc, matrix, normal, -HALF_WIDTH, 0.0F, 0.0F, 1.0F, full);
        vertex(vc, matrix, normal, HALF_WIDTH, 0.0F, 1.0F, 1.0F, full);
        vertex(vc, matrix, normal, HALF_WIDTH, HEIGHT, 1.0F, 0.0F, full);
        vertex(vc, matrix, normal, -HALF_WIDTH, HEIGHT, 0.0F, 0.0F, full);

        pose.popPose();
        super.render(entity, yaw, partialTick, pose, buffer, light);
    }

    private static void vertex(VertexConsumer vc, Matrix4f matrix, Matrix3f normal,
                               float x, float y, float u, float v, int light) {
        vc.vertex(matrix, x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerEntity entity) {
        return TEXTURE;
    }
}
