package com.example.goatstalker;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** The glowing broken stone in the middle of the tower: step on it and you fall into Nullspace 2 (Village). */
public class GlitchStoneBlock extends Block {
    public GlitchStoneBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp && sp.level().dimension() == Nullspace.ISLAND) {
            NullspaceEvents.enter(sp);
        }
        super.stepOn(level, pos, state, entity);
    }
}
