package com.example.goatstalker.client;

import com.example.goatstalker.GoatStalkerMod;
import com.example.goatstalker.StalkerPartEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws the separate head / hand as a flat picture that faces the camera. */
public class StalkerPartRenderer extends EntityRenderer<StalkerPartEntity> {
    private static final ResourceLocation HEAD_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/goat_head.png");
    private static final ResourceLocation HAND_TEX =
            new ResourceLocation(GoatStalkerMod.MODID, "textures/entity/goat_hand.png");

    private static final float HEAD_W = 0.9F, HEAD_H = 1.6F;
    private static final float HAND_W = 2.2F, HAND_H = 1.54F;

    public StalkerPartRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(StalkerPartEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        boolean head = entity.getPart() == StalkerPartEntity.HEAD;
        float w = head ? HEAD_W : HAND_W;
        float h = head ? HEAD_H : HAND_H;
        float age = entity.tickCount + partialTick;
        float sway = head ? Mth.sin(age * 0.3F) * 3.0F : Mth.sin(age * 0.7F) * 6.0F;

        pose.pushPose();
        pose.translate(0.0D, entity.getBbHeight() / 2.0D, 0.0D);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - this.entityRenderDispatcher.camera.getYRot()));
        pose.mulPose(Axis.ZP.rotationDegrees(sway));

        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));

        vertex(vc, matrix, normal, -w / 2, -h / 2, 0.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, -h / 2, 1.0F, 1.0F, light);
        vertex(vc, matrix, normal, w / 2, h / 2, 1.0F, 0.0F, light);
        vertex(vc, matrix, normal, -w / 2, h / 2, 0.0F, 0.0F, light);

        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f matrix, Matrix3f normal,
                               float x, float y, float u, float v, int light) {
        vc.vertex(matrix, x, y, 0.0F)
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerPartEntity entity) {
        return entity.getPart() == StalkerPartEntity.HEAD ? HEAD_TEX : HAND_TEX;
    }
}
