package com.example.goatstalker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The whole chain of events:
 * - tree event: the creature leans out from behind a tree;
 * - glitched grass: a glowing walk-through block that pulls you into Nullspace 1 (Island);
 * - Island: flat world, a tower far away; close to it "RUN, IT'S BEHIND YOU" and the creature chases you;
 *   in the tower a glowing broken stone drops you into Nullspace 2 (Village);
 * - Village: on a roof the creature appears and chases you; the exit block (or being caught) sends you back.
 * Being sent back always means: to the place where you were before the first jump.
 */
@Mod.EventBusSubscriber(modid = GoatStalkerMod.MODID)
public class NullspaceEvents {
    private record Task(long time, Runnable run) {}

    private static final List<Task> TASKS = new ArrayList<>();
    private static final Map<UUID, Long> NEXT_TREE = new HashMap<>();
    private static final Map<UUID, Long> NEXT_NULLSPACE = new HashMap<>();
    private static final Map<UUID, Long> NEXT_GLITCH = new HashMap<>();
    private static final Map<UUID, Long> ENTERED = new HashMap<>();
    private static final Map<UUID, Long> ROOF_COOLDOWN = new HashMap<>();
    private static final Set<UUID> ISLAND_CHASE = new HashSet<>();
    private static final String RETURN_KEY = "goatstalker_return";

    private static final String MSG_1 = "Don't you remember? It's time to take a walk through memory lane one last time.";
    private static final String MSG_2 = "It's just the way you remember it, right? All those hours spent with those people, "
            + "all those good times, if only you could go back.";

    // ------------------------------ scheduler ------------------------------
    public static void schedule(MinecraftServer server, int ticks, Runnable run) {
        TASKS.add(new Task(server.overworld().getGameTime() + ticks, run));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || TASKS.isEmpty()) {
            return;
        }
        long now = event.getServer().overworld().getGameTime();
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(t -> {
            if (now >= t.time()) {
                due.add(t);
                return true;
            }
            return false;
        });
        for (Task t : due) {
            try {
                t.run().run();
            } catch (Exception ignored) {
                // a task must never crash the server
            }
        }
    }

    // ------------------------------ timers ------------------------------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) {
            return;
        }
        if (!(event.player instanceof ServerPlayer player) || player.tickCount % 10 != 0) {
            return;
        }
        ServerLevel level = player.serverLevel();
        UUID id = player.getUUID();
        long now = level.getGameTime();
        ResourceKey<Level> dim = level.dimension();

        if (dim == Nullspace.ISLAND) {
            inIsland(player, level, id, now);
            return;
        }
        ISLAND_CHASE.remove(id);
        if (dim == Nullspace.DIM) {
            inVillage(player, level, id, now);
            return;
        }
        ENTERED.remove(id);
        if (dim != Level.OVERWORLD || player.isCreative() || player.isSpectator()) {
            return;
        }

        if (StalkerConfig.TREE_ENABLED.get()) {
            long next = NEXT_TREE.computeIfAbsent(id, k -> now + StalkerConfig.TREE_MINUTES.get() * 600L);
            if (now >= next) {
                boolean ok = spawnTree(player, level);
                NEXT_TREE.put(id, now + (ok ? StalkerConfig.TREE_MINUTES.get() * 1200L : 600L));
            }
        }
        if (StalkerConfig.NULLSPACE_ENABLED.get()) {
            long next = NEXT_NULLSPACE.computeIfAbsent(id, k -> now + StalkerConfig.NULLSPACE_MINUTES.get() * 1200L);
            if (now >= next) {
                if (player.isSleeping() || player.isPassenger()) {
                    NEXT_NULLSPACE.put(id, now + 400L);
                } else {
                    boolean ok = enter(player);
                    NEXT_NULLSPACE.put(id, now + (ok ? StalkerConfig.NULLSPACE_MINUTES.get() * 1200L : 1200L));
                }
            }
        }
        if (StalkerConfig.GLITCH_ENABLED.get()) {
            long next = NEXT_GLITCH.computeIfAbsent(id, k -> now + randomGlitchDelay(level));
            if (now >= next) {
                boolean ok = placeGlitchGrass(player, level);
                NEXT_GLITCH.put(id, now + (ok ? randomGlitchDelay(level) : 600L));
            }
        }
    }

    private static long randomGlitchDelay(ServerLevel level) {
        long avg = StalkerConfig.GLITCH_MINUTES.get() * 1200L;
        return avg / 2 + level.random.nextInt((int) Math.min(Integer.MAX_VALUE, Math.max(1L, avg)));
    }

    private static boolean tooLong(UUID id, long now) {
        long entered = ENTERED.computeIfAbsent(id, k -> now);
        return now - entered > StalkerConfig.NULLSPACE_MAX_STAY_MINUTES.get() * 1200L;
    }

    // ------------------------------ Island (Nullspace 1) ------------------------------
    private static void inIsland(ServerPlayer player, ServerLevel level, UUID id, long now) {
        if (tooLong(id, now)) {
            returnPlayer(player);
            return;
        }
        if (ISLAND_CHASE.contains(id)) {
            return;
        }
        double dx = player.getX() - 0.5D;
        double dz = player.getZ() - Nullspace.TOWER_Z;
        if (dx * dx + dz * dz < 80.0D * 80.0D) { // a bit closer to the tower
            ISLAND_CHASE.add(id);
            startIslandChase(player, level);
        }
    }

    private static void startIslandChase(ServerPlayer p, ServerLevel level) {
        MinecraftServer server = p.server;
        for (int i = 0; i < 4; i++) {
            schedule(server, i * 30, () -> p.displayClientMessage(Component.literal("RUN, IT'S BEHIND YOU"), true));
        }
        // it starts far behind the player (on the side away from the tower)
        double dx = p.getX() - 0.5D;
        double dz = p.getZ() - Nullspace.TOWER_Z;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0D) {
            dx = 0.0D;
            dz = -1.0D;
            len = 1.0D;
        }
        dx /= len;
        dz /= len;
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e != null) {
            e.setup(BipedalEntity.RUNNER, p.getUUID());
            e.setPos(p.getX() + dx * 55.0D, Nullspace.GROUND_TOP, p.getZ() + dz * 55.0D);
            level.addFreshEntity(e);
        }
        playChaseMusic(p);
    }

    /** The chase music is 53 s long (1067 ticks); it repeats while the chase on the Island goes on. */
    private static void playChaseMusic(ServerPlayer p) {
        if (!p.isAlive() || p.level().dimension() != Nullspace.ISLAND || !ISLAND_CHASE.contains(p.getUUID())) {
            return;
        }
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ModSounds.ISLAND_CHASE.get(),
                SoundSource.MUSIC, 1.0F, 1.0F);
        schedule(p.server, 1067, () -> playChaseMusic(p));
    }

    public static void stopChaseMusic(ServerPlayer p) {
        p.connection.send(new ClientboundStopSoundPacket(
                new ResourceLocation(GoatStalkerMod.MODID, "island_chase"), SoundSource.MUSIC));
    }

    /** Pulls the player into the Island. Called by the glitched grass block. */
    public static boolean enterIsland(ServerPlayer player) {
        MinecraftServer server = player.server;
        ServerLevel island = server.getLevel(Nullspace.ISLAND);
        if (island == null || player.level().dimension() == Nullspace.ISLAND) {
            return false;
        }
        boolean inChain = Nullspace.isNullspace(player.level().dimension());
        Nullspace.ensureIslandBuilt(island);
        if (!inChain) {
            saveReturn(player);
        }
        player.teleportTo(island, 0.5D, Nullspace.GROUND_TOP, 0.5D, 0.0F, 0.0F);
        ENTERED.put(player.getUUID(), island.getGameTime());

        player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        player.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Nullspace 1")));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.literal("Island")));
        schedule(server, 20, () -> player.sendSystemMessage(Component.literal(MSG_1)));
        return true;
    }

    // ------------------------------ Village (Nullspace 2) ------------------------------
    private static void inVillage(ServerPlayer player, ServerLevel level, UUID id, long now) {
        if (tooLong(id, now)) {
            returnPlayer(player);
            return;
        }
        if (now < ROOF_COOLDOWN.getOrDefault(id, 0L) || !onRoof(player, level)) {
            return;
        }
        if (!level.getEntitiesOfClass(BipedalEntity.class, player.getBoundingBox().inflate(120.0D)).isEmpty()) {
            return;
        }
        if (startRoofEvent(player, level)) {
            ROOF_COOLDOWN.put(id, now + 1200L);
        }
    }

    private static boolean onRoof(ServerPlayer p, ServerLevel level) {
        if (!p.onGround()) {
            return false;
        }
        double y = p.getY();
        if (y < Nullspace.G + 4.9D || y > Nullspace.G + 5.4D) {
            return false;
        }
        BlockState below = level.getBlockState(p.blockPosition().below());
        return below.is(Blocks.OAK_PLANKS) || below.is(Blocks.OAK_LOG);
    }

    /** Teleports to Village (Nullspace 2): from the overworld (timer, command) or from the Island tower. */
    public static boolean enter(ServerPlayer player) {
        MinecraftServer server = player.server;
        ServerLevel ns = server.getLevel(Nullspace.DIM);
        if (ns == null || player.level().dimension() == Nullspace.DIM) {
            return false;
        }
        boolean fromIsland = player.level().dimension() == Nullspace.ISLAND;
        if (fromIsland) {
            ISLAND_CHASE.remove(player.getUUID());
            stopChaseMusic(player);
        }
        Nullspace.ensureBuilt(ns);
        if (!fromIsland && !Nullspace.isNullspace(player.level().dimension())) {
            saveReturn(player);
        }
        player.teleportTo(ns, 0.5D, Nullspace.GROUND_TOP, 2.5D, 0.0F, 0.0F);
        ENTERED.put(player.getUUID(), ns.getGameTime());

        player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
        player.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Nullspace 2")));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.literal("Village")));
        if (!fromIsland) {
            schedule(server, 20, () -> player.sendSystemMessage(Component.literal(MSG_1)));
            schedule(server, 60, () -> player.sendSystemMessage(Component.literal(MSG_2)));
        } else {
            schedule(server, 20, () -> player.sendSystemMessage(Component.literal(MSG_2)));
        }
        return true;
    }

    // ------------------------------ going back ------------------------------
    private static void saveReturn(ServerPlayer player) {
        CompoundTag ret = new CompoundTag();
        ret.putString("dim", player.level().dimension().location().toString());
        ret.putDouble("x", player.getX());
        ret.putDouble("y", player.getY());
        ret.putDouble("z", player.getZ());
        ret.putFloat("yaw", player.getYRot());
        ret.putFloat("pitch", player.getXRot());
        player.getPersistentData().put(RETURN_KEY, ret);
    }

    public static void returnPlayerIfInNullspace(ServerPlayer player) {
        if (player.isAlive() && Nullspace.isNullspace(player.level().dimension())) {
            returnPlayer(player);
        }
    }

    /** Sends the player back to where he was before the first jump (silently). */
    public static void returnPlayer(ServerPlayer player) {
        MinecraftServer server = player.server;
        CompoundTag ret = player.getPersistentData().getCompound(RETURN_KEY);
        ServerLevel target = null;
        if (ret.contains("dim")) {
            target = server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(ret.getString("dim"))));
        }
        double x;
        double y;
        double z;
        float yaw = 0.0F;
        float pitch = 0.0F;
        if (target == null || Nullspace.isNullspace(target.dimension())) {
            target = server.overworld();
            BlockPos sp = target.getSharedSpawnPos();
            x = sp.getX() + 0.5D;
            y = sp.getY();
            z = sp.getZ() + 0.5D;
        } else {
            x = ret.getDouble("x");
            y = ret.getDouble("y");
            z = ret.getDouble("z");
            yaw = ret.getFloat("yaw");
            pitch = ret.getFloat("pitch");
        }
        player.getPersistentData().remove(RETURN_KEY);
        ENTERED.remove(player.getUUID());
        ISLAND_CHASE.remove(player.getUUID());
        stopChaseMusic(player);
        player.teleportTo(target, x, y, z, yaw, pitch);
    }

    // ------------------------------ roof event (Village) ------------------------------
    /** The creature appears on a roof about five houses ahead. */
    public static boolean startRoofEvent(ServerPlayer p, ServerLevel level) {
        int dir = p.getLookAngle().z >= 0 ? 1 : -1;
        double[] spot = pickRoof(p, level, dir);
        if (spot == null) {
            spot = pickRoof(p, level, -dir);
        }
        if (spot == null) {
            return false;
        }
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return false;
        }
        e.setup(BipedalEntity.ROOF, p.getUUID());
        e.setPos(spot[0], Nullspace.G + 5.0D, spot[1]);
        level.addFreshEntity(e);
        return true;
    }

    private static double[] pickRoof(ServerPlayer p, ServerLevel level, int dir) {
        int best = -1;
        double bestScore = Double.MAX_VALUE;
        for (int i = 0; i < Nullspace.COUNT; i++) {
            double zc = Nullspace.FIRST_Z + Nullspace.STEP * i + 3.5D;
            double dz = dir * (zc - p.getZ());
            if (dz < 25.0D || dz > 65.0D) {
                continue;
            }
            double score = Math.abs(dz - 45.0D);
            if (score < bestScore) {
                bestScore = score;
                best = i;
            }
        }
        if (best < 0) {
            return null;
        }
        double zc = Nullspace.FIRST_Z + Nullspace.STEP * best + 3.5D;
        double x = level.random.nextBoolean() ? -6.5D : 7.5D;
        return new double[] {x, zc};
    }

    // ------------------------------ glitched grass (overworld) ------------------------------
    /** Puts a glitched grass block on the ground 8-16 blocks in front of the player. */
    public static boolean placeGlitchGrass(ServerPlayer p, ServerLevel level) {
        RandomSource r = level.random;
        for (int i = 0; i < 30; i++) {
            double dist = 8 + r.nextInt(9);
            double a = Math.toRadians(p.getYRot() + (r.nextDouble() - 0.5D) * 120.0D);
            int x = Mth.floor(p.getX() - Math.sin(a) * dist);
            int z = Mth.floor(p.getZ() + Math.cos(a) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
                continue;
            }
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, top - 1, z);
            if (Math.abs(pos.getY() - p.getY()) > 6) {
                continue;
            }
            if (level.getBlockState(pos).is(Blocks.GRASS_BLOCK) && level.getBlockState(pos.above()).isAir()) {
                level.setBlock(pos, ModBlocks.GLITCH_GRASS.get().defaultBlockState(), 3);
                return true;
            }
        }
        return false;
    }

    // ------------------------------ tree event ------------------------------
    /** The creature leans out from behind a tree trunk, on the player's right, and looks at him. */
    public static boolean spawnTree(ServerPlayer player, ServerLevel level) {
        BlockPos base = findTree(player, level);
        if (base == null) {
            return false;
        }
        double cx = base.getX() + 0.5D;
        double cz = base.getZ() + 0.5D;
        double dx = cx - player.getX();
        double dz = cz - player.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0D) {
            return false;
        }
        dx /= len;
        dz /= len;
        BipedalEntity e = ModEntities.BIPEDAL.get().create(level);
        if (e == null) {
            return false;
        }
        e.setup(BipedalEntity.TREE, player.getUUID());
        e.setSlide(dz, -dx); // to the player's left: it slides behind the trunk and disappears
        double side = 0.5D + BipedalEntity.TREE_W / 2.0D; // the flat left edge of the picture touches the trunk's right edge
        e.setPos(cx + dx * 0.9D + (-dz) * side, base.getY(), cz + dz * 0.9D + dx * side);
        level.addFreshEntity(e);
        return true;
    }

    private static BlockPos findTree(ServerPlayer p, ServerLevel level) {
        RandomSource r = level.random;
        for (int i = 0; i < 40; i++) {
            double dist = 12 + r.nextInt(14);
            double a = Math.toRadians(p.getYRot() + (r.nextDouble() - 0.5D) * 100.0D);
            int x = Mth.floor(p.getX() - Math.sin(a) * dist);
            int z = Mth.floor(p.getZ() + Math.cos(a) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
                continue;
            }
            int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
            for (int y = top; y >= top - 14 && y > level.getMinBuildHeight(); y--) {
                BlockPos pos = new BlockPos(x, y, z);
                BlockState st = level.getBlockState(pos);
                if (st.is(BlockTags.LOGS)) {
                    BlockPos base = pos;
                    while (level.getBlockState(base.below()).is(BlockTags.LOGS)) {
                        base = base.below();
                    }
                    if (!level.getBlockState(base.below()).is(BlockTags.DIRT)) {
                        break;
                    }
                    int h = 0;
                    BlockPos t = base;
                    while (level.getBlockState(t).is(BlockTags.LOGS)) {
                        h++;
                        t = t.above();
                    }
                    if (h >= 3) {
                        return base;
                    }
                    break;
                }
                if (!st.isAir() && !st.is(BlockTags.LEAVES)) {
                    break;
                }
            }
        }
        return null;
    }

    // ------------------------------ commands ------------------------------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        var village = Commands.literal("bipedalStalkerhouse").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!enter(p)) {
                ctx.getSource().sendFailure(Component.literal("Cannot enter Nullspace 2 (already there, or the dimension did not load)."));
                return 0;
            }
            return 1;
        });
        var villageAlias = Commands.literal("bipedalStalkerHouse").executes(village.getCommand());
        var island = Commands.literal("island").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!enterIsland(p)) {
                ctx.getSource().sendFailure(Component.literal("Cannot enter Nullspace 1 (already there, or the dimension did not load)."));
                return 0;
            }
            return 1;
        });
        var glitch = Commands.literal("glitchGrass").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!placeGlitchGrass(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No grass found in front of you."));
                return 0;
            }
            return 1;
        });
        var tree = Commands.literal("bipedalStalkerTree").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (!spawnTree(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("No tree found near you. Go to a forest."));
                return 0;
            }
            return 1;
        });
        var roof = Commands.literal("bipedalStalkerRoof").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            if (p.level().dimension() != Nullspace.DIM || !startRoofEvent(p, p.serverLevel())) {
                ctx.getSource().sendFailure(Component.literal("You must be in Nullspace 2 (Village)."));
                return 0;
            }
            return 1;
        });
        var back = Commands.literal("nullspaceReturn").executes(ctx -> {
            returnPlayer(ctx.getSource().getPlayerOrException());
            return 1;
        });
        event.getDispatcher().register(Commands.literal("goatstalker")
                .requires(source -> source.hasPermission(2))
                .then(village).then(villageAlias).then(island).then(glitch).then(tree).then(roof).then(back));
    }
}
