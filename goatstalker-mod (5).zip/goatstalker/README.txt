GOAT STALKER (Forge 1.20.1)

КАК СОБРАТЬ JAR
1. Скачай Forge MDK 1.20.1 (47.x): files.minecraftforge.net -> 1.20.1 -> Mdk. Распакуй.
2. В MDK удали папку src и файлы build.gradle, gradle.properties, settings.gradle.
3. Скопируй сюда всё из этого архива (src, build.gradle, gradle.properties, settings.gradle).
   Папки gradle/ и файлы gradlew, gradlew.bat остаются из MDK.
4. Нужна Java 17. Запусти в этой папке:  gradlew build
5. Готовый jar: build/libs/goatstalker-1.0.0.jar -> положи в папку mods.

ТЕСТ БЕЗ ОЖИДАНИЯ
В игре: /summon goatstalker:goat_stalker  или яйцо в творческом инвентаре (вкладка яиц).
Настройки: config/goatstalker-common.toml

НОВОЕ: ДВУНОГИЙ СТАЛКЕР И NULLSPACE 2
Команды (нужны права оператора):
  /goatstalker bipedalStalkerTree    - существо выглядывает из-за ближайшего дерева (нужен лес рядом)
  /goatstalker bipedalStalkerhouse   - телепорт в Nullspace 2 (деревня)
  /goatstalker bipedalStalkerRoof    - (в Nullspace 2) вызвать существо на крыше
  /goatstalker nullspaceReturn       - вернуться обратно
Блок выхода: "Nullspace Exit" (творческий режим, вкладка функциональных блоков).

ЦЕПОЧКА: трава -> Island -> Village -> назад
  Сбойная трава (светится, проходимая) иногда появляется рядом: коснулся -> Nullspace 1 (Island).
  Island: плоский мир, вдали башня. Подойдёшь ближе - "RUN, IT'S BEHIND YOU" и двуногий бежит за тобой.
  В башне по центру светящийся сбойный камень: наступил -> Nullspace 2 (Village).
  Из Village выход: блок Nullspace Exit (или тебя догонит двуногий).
Команды: /goatstalker island | glitchGrass | bipedalStalkerhouse | bipedalStalkerTree | bipedalStalkerRoof | nullspaceReturn

МУЗЫКА: когда убегаешь на Island, играет island_chase.ogg (повторяется, пока идёт погоня; громкость - ползунок "Музыка").
